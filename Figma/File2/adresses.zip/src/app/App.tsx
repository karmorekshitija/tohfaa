import { useState } from "react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";

const C = {
  primary: "#255338",
  surface: "#fff8f3",
  tertiary: "#573b81",
  onSurface: "#211b11",
  onSurfaceVariant: "#414942",
  outlineVariant: "#c1c9c0",
  secondary: "#49663f",
  surfaceContainerHigh: "#f3e6d6",
  surfaceContainerLow: "#fff2e1",
  onPrimary: "#ffffff",
};

function Icon({ name, size = 22, color = C.onSurface, fill = 0 }: { name: string; size?: number; color?: string; fill?: number }) {
  return (
    <span
      className="material-symbols-outlined select-none"
      style={{
        fontSize: size,
        color,
        lineHeight: 1,
        verticalAlign: "middle",
        fontVariationSettings: `'FILL' ${fill}, 'wght' 400, 'GRAD' 0, 'opsz' 24`,
      }}
    >
      {name}
    </span>
  );
}

export default function App() {
  const [tapped, setTapped] = useState(false);

  return (
    <div
      className="size-full flex items-center justify-center"
      style={{ background: "#d8cfc4" }}
    >
      {/* Phone frame */}
      <div
        className="relative flex flex-col overflow-hidden"
        style={{
          width: 390,
          height: 844,
          borderRadius: 50,
          boxShadow: "0 40px 100px rgba(0,0,0,0.38), 0 0 0 10px #1a1a1a, 0 0 0 12px #2e2e2e",
          background: C.surface,
          fontFamily: "'DM Sans', sans-serif",
        }}
      >
        {/* Status bar */}
        <div
          className="flex items-center justify-between px-8 shrink-0"
          style={{ paddingTop: 18, paddingBottom: 6, background: C.surface }}
        >
          <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 600, color: C.onSurface }}>9:41</span>
          <div
            style={{
              width: 120, height: 30, background: "#1a1a1a",
              borderRadius: 20, position: "absolute",
              left: "50%", transform: "translateX(-50%)", top: 10,
            }}
          />
          <div className="flex gap-1.5 items-center">
            <svg width="16" height="11" viewBox="0 0 16 11" fill={C.onSurface}>
              <rect x="0" y="5" width="2.5" height="6" rx="0.5"/>
              <rect x="4" y="3" width="2.5" height="8" rx="0.5"/>
              <rect x="8" y="1" width="2.5" height="10" rx="0.5"/>
              <rect x="12" y="0" width="2.5" height="11" rx="0.5" opacity="0.25"/>
            </svg>
            <svg width="15" height="11" viewBox="0 0 15 11" fill="none">
              <circle cx="7.5" cy="9.5" r="1.2" fill={C.onSurface}/>
              <path d="M4.5 7C5.5 5.9 6.4 5.3 7.5 5.3C8.6 5.3 9.5 5.9 10.5 7" stroke={C.onSurface} strokeWidth="1.4" strokeLinecap="round" fill="none"/>
              <path d="M2 4.5C3.7 2.6 5.5 1.5 7.5 1.5C9.5 1.5 11.3 2.6 13 4.5" stroke={C.onSurface} strokeWidth="1.4" strokeLinecap="round" fill="none" opacity="0.5"/>
            </svg>
            <svg width="25" height="12" viewBox="0 0 25 12" fill="none">
              <rect x="0.5" y="0.5" width="21" height="11" rx="3.5" stroke={C.onSurface} strokeOpacity="0.35"/>
              <rect x="2" y="2" width="17" height="8" rx="2" fill={C.onSurface}/>
              <path d="M23 4V8C23.8 7.7 24.5 7.1 24.5 6C24.5 4.9 23.8 4.3 23 4Z" fill={C.onSurface} fillOpacity="0.4"/>
            </svg>
          </div>
        </div>

        {/* Top nav */}
        <nav
          className="flex items-center justify-between px-5 py-3 shrink-0"
          style={{ background: C.surface }}
        >
          <span style={{ fontFamily: "'Playfair Display', serif", fontStyle: "italic", fontSize: 22, color: C.primary }}>
            Tofha<span style={{ color: C.tertiary }}>.</span>
          </span>
          <div className="flex items-center gap-1">
            {["search", "notifications", "favorite", "shopping_cart"].map((icon) => (
              <button
                key={icon}
                className="flex items-center justify-center w-10 h-10 rounded-full transition-colors active:scale-95"
                style={{ background: "transparent" }}
              >
                <Icon name={icon} size={22} color={C.onSurface} />
              </button>
            ))}
          </div>
        </nav>

        {/* Main content */}
        <div
          className="relative flex-1 flex flex-col items-center justify-center px-6 overflow-hidden"
          style={{ background: C.surface }}
        >
          {/* Atmosphere: ink splatter blobs */}
          <div
            style={{
              position: "absolute", top: -60, left: -60,
              width: 280, height: 280,
              background: C.tertiary,
              filter: "blur(50px)",
              opacity: 0.05,
              borderRadius: "50%",
              pointerEvents: "none",
            }}
          />
          <div
            style={{
              position: "absolute", bottom: 20, right: -40,
              width: 200, height: 200,
              background: C.tertiary,
              filter: "blur(50px)",
              opacity: 0.04,
              borderRadius: "50%",
              pointerEvents: "none",
            }}
          />

          {/* Botanical watermarks */}
          <div
            style={{
              position: "absolute", top: "18%", right: "8%",
              opacity: 0.07, transform: "rotate(12deg)", pointerEvents: "none",
            }}
          >
            <Icon name="eco" size={90} color={C.secondary} />
          </div>
          <div
            style={{
              position: "absolute", bottom: "18%", left: "4%",
              opacity: 0.07, transform: "rotate(-12deg)", pointerEvents: "none",
            }}
          >
            <Icon name="local_florist" size={64} color={C.secondary} />
          </div>

          {/* Content */}
          <div className="relative z-10 flex flex-col items-center text-center">
            {/* Mascot circle */}
            <div className="relative mb-6">
              <div
                className="overflow-hidden flex items-center justify-center"
                style={{
                  width: 220,
                  height: 220,
                  borderRadius: "50%",
                  background: C.surfaceContainerLow,
                  border: `1px solid rgba(193,201,192,0.4)`,
                  boxShadow: "0 4px 20px rgba(37,83,56,0.1)",
                }}
              >
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1753162657914-9a32f49edfe1?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&w=440&h=440"
                  alt="Tofha artisan at her studio desk"
                  className="w-full h-full object-cover"
                  style={{ filter: "grayscale(0.15) sepia(0.1)" }}
                />
              </div>

              {/* Floating location pin badge */}
              <div
                className="absolute -top-3 -right-3 p-2.5 rounded-xl shadow-md"
                style={{
                  background: C.surface,
                  border: `1px solid ${C.outlineVariant}`,
                  transform: "rotate(6deg)",
                }}
              >
                <Icon name="location_on" size={22} color={C.tertiary} fill={1} />
              </div>
            </div>

            {/* Text hierarchy */}
            <div className="space-y-2 mb-8">
              <h1
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontStyle: "italic",
                  fontSize: 26,
                  fontWeight: 400,
                  color: C.primary,
                  lineHeight: 1.3,
                }}
              >
                No addresses saved yet{" "}
                <span style={{ color: C.tertiary }}>✦</span>
              </h1>
              <p style={{ fontSize: 15, color: C.onSurfaceVariant, lineHeight: 1.5, maxWidth: 240, margin: "0 auto" }}>
                Add an address to checkout faster.
              </p>
            </div>

            {/* CTA button */}
            <button
              onPointerDown={() => setTapped(true)}
              onPointerUp={() => setTapped(false)}
              onPointerLeave={() => setTapped(false)}
              className="flex items-center gap-2 px-6 py-3.5 rounded-full transition-all duration-150"
              style={{
                background: C.primary,
                color: C.onPrimary,
                fontFamily: "'DM Sans', sans-serif",
                fontSize: 15,
                fontWeight: 700,
                boxShadow: "0 4px 16px rgba(37,83,56,0.3)",
                transform: tapped ? "scale(0.97)" : "scale(1)",
              }}
            >
              <Icon name="add" size={20} color={C.onPrimary} />
              Add your first address
            </button>
          </div>

          {/* Footer botanical motif */}
          <div
            className="absolute bottom-6 flex gap-6"
            style={{ opacity: 0.07, pointerEvents: "none", transform: "scale(1.3)" }}
          >
            <Icon name="psychology_alt" size={24} color={C.secondary} />
            <Icon name="spa" size={24} color={C.secondary} />
            <Icon name="filter_vintage" size={24} color={C.secondary} />
          </div>
        </div>
      </div>
    </div>
  );
}
