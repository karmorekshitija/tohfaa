import { useState, useEffect, useRef } from "react";
import { Heart, ShoppingCart, Bell, Search, Home, Grid3x3, Play, User, Star, ChevronLeft, ChevronRight, X } from "lucide-react";

// ── Palette ───────────────────────────────────────────────────────────────────
const GREEN = "#3D6B4F";
const GOLD  = "#C8973A";
const CREAM = "#F7F3EC";
const SAGE  = "#8FAF82";
const PLUM  = "#7B5EA7";

// ── Mock Data ─────────────────────────────────────────────────────────────────
const SLIDES = [
  { id: 1, url: "https://images.unsplash.com/photo-1576016770956-debb63d900bb?w=800&auto=format&fit=crop&q=80", alt: "Ceramic Bowls" },
  { id: 2, url: "https://images.unsplash.com/photo-1544816155-12df9643f363?w=800&auto=format&fit=crop&q=80", alt: "Linen Journal" },
  { id: 3, url: "https://images.unsplash.com/photo-1602872030219-c16779798575?w=800&auto=format&fit=crop&q=80", alt: "Incense Holder" },
  { id: 4, url: "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=800&auto=format&fit=crop&q=80", alt: "Stoneware Vase" },
];

const PRODUCTS = [
  { id: 1, name: "Handcrafted Ceramic Bowl", seller: "Earth & Clay Studio", price: 1850, rating: 4.8, reviews: 124, image: "https://images.unsplash.com/photo-1576016770956-debb63d900bb?w=400&auto=format&fit=crop&q=80", badge: "BEST SELLER", badgeColor: "#C85A32" },
  { id: 2, name: "Handmade Linen Journal", seller: "The Paper Loom", price: 950, rating: 4.6, reviews: 89, image: "https://images.unsplash.com/photo-1544816155-12df9643f363?w=400&auto=format&fit=crop&q=80", badge: "CUSTOM", badgeColor: PLUM },
  { id: 3, name: "Brass Incense Holder", seller: "Aura Metals", price: 1200, rating: 4.9, reviews: 203, image: "https://images.unsplash.com/photo-1602872030219-c16779798575?w=400&auto=format&fit=crop&q=80", badge: null, badgeColor: "" },
  { id: 4, name: "Minimalist Stoneware Vase", seller: "Nordic Craft Co.", price: 2400, rating: 4.7, reviews: 67, image: "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=400&auto=format&fit=crop&q=80", badge: "BEST SELLER", badgeColor: "#C85A32" },
  { id: 5, name: "Woven Rattan Tray", seller: "Boho Living", price: 750, rating: 4.5, reviews: 45, image: "https://images.unsplash.com/photo-1612965607446-25e1332775ae?w=400&auto=format&fit=crop&q=80", badge: null, badgeColor: "" },
  { id: 6, name: "Hand-Poured Soy Candle", seller: "Glow & Bloom", price: 550, rating: 4.8, reviews: 312, image: "https://images.unsplash.com/photo-1602607144535-12d7abde5b64?w=400&auto=format&fit=crop&q=80", badge: "CUSTOM", badgeColor: PLUM },
];

const SPONSORED = [
  { id: 101, name: "Artisan Tea Set", seller: "Kintsugi House", price: 3200, rating: 4.9, reviews: 58, image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&auto=format&fit=crop&q=80", badge: "Sponsored", badgeColor: GOLD },
  { id: 102, name: "Macramé Wall Hanging", seller: "Knot & Thread", price: 1650, rating: 4.7, reviews: 91, image: "https://images.unsplash.com/photo-1516455207990-7a41ce80f7ee?w=400&auto=format&fit=crop&q=80", badge: "Sponsored", badgeColor: GOLD },
  { id: 103, name: "Hand-Dyed Silk Scarf", seller: "Saffron Textiles", price: 1900, rating: 4.6, reviews: 44, image: "https://images.unsplash.com/photo-1519923041107-8bb0baa4e4a3?w=400&auto=format&fit=crop&q=80", badge: "Sponsored", badgeColor: GOLD },
  { id: 104, name: "Carved Wooden Bowl", seller: "Forest & Form", price: 2800, rating: 4.8, reviews: 77, image: "https://images.unsplash.com/photo-1556909172-54557c7e4fb7?w=400&auto=format&fit=crop&q=80", badge: "Sponsored", badgeColor: GOLD },
];

const CATEGORIES = [
  { name: "Ceramics", products: PRODUCTS.slice(0, 4) },
  { name: "Stationery", products: [...PRODUCTS].reverse().slice(0, 4) },
  { name: "Home Decor", products: [...PRODUCTS].slice(2, 6) },
];

// ── Sub-Components ─────────────────────────────────────────────────────────────

function Badge({ label, color }: { label: string; color: string }) {
  return (
    <span
      className="absolute top-2 left-2 text-white text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full z-10"
      style={{ backgroundColor: color }}
    >
      {label}
    </span>
  );
}

function WishlistBtn({ wishlisted, onToggle }: { wishlisted: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onToggle(); }}
      className="absolute top-2 right-2 w-7 h-7 bg-white/90 backdrop-blur rounded-full flex items-center justify-center shadow z-10 active:scale-90 transition-transform"
    >
      <Heart
        size={14}
        fill={wishlisted ? "#ef4444" : "none"}
        stroke={wishlisted ? "#ef4444" : "#605e57"}
        strokeWidth={2}
      />
    </button>
  );
}

function ProductCard({ product, compact = false }: { product: typeof PRODUCTS[0]; compact?: boolean }) {
  const [wishlisted, setWishlisted] = useState(false);
  const fmtPrice = `₹${product.price.toLocaleString("en-IN")}`;

  return (
    <div
      className={`bg-white rounded-xl border border-gray-200 shadow-sm active:scale-[0.98] transition-transform cursor-pointer flex flex-col ${compact ? "w-44 flex-shrink-0" : ""}`}
    >
      <div className="relative aspect-square overflow-hidden rounded-t-xl bg-[#F7F3EC]">
        {product.badge && <Badge label={product.badge} color={product.badgeColor} />}
        <WishlistBtn wishlisted={wishlisted} onToggle={() => setWishlisted(!wishlisted)} />
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </div>
      <div className="p-2.5 flex flex-col gap-0.5 flex-1">
        <span className="font-bold text-sm leading-none" style={{ color: GOLD }}>{fmtPrice}</span>
        <h4 className="font-semibold text-[12px] leading-tight text-gray-900 line-clamp-1" style={{ fontFamily: "'Playfair Display', serif" }}>
          {product.name}
        </h4>
        <div className="flex items-center gap-0.5">
          <Star size={10} fill={GOLD} stroke="none" />
          <span className="text-[10px] font-semibold text-gray-800">{product.rating}</span>
          <span className="text-[10px] text-gray-500">({product.reviews})</span>
        </div>
        <span className="text-[10px] text-gray-500 truncate">By {product.seller}</span>
      </div>
      <div className="px-2.5 pb-2.5">
        <button
          onClick={(e) => e.stopPropagation()}
          className="w-full py-1.5 rounded-lg text-white text-xs font-semibold active:opacity-80 transition-opacity"
          style={{ backgroundColor: GREEN }}
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}

function Carousel() {
  const [current, setCurrent] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const touchStart = useRef(0);

  const goTo = (idx: number) => {
    setCurrent((idx + SLIDES.length) % SLIDES.length);
  };

  useEffect(() => {
    timerRef.current = setInterval(() => setCurrent(c => (c + 1) % SLIDES.length), 4000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  return (
    <div
      className="relative w-full overflow-hidden select-none"
      style={{ aspectRatio: "4/3" }}
      onTouchStart={(e) => { touchStart.current = e.changedTouches[0].clientX; }}
      onTouchEnd={(e) => {
        const diff = touchStart.current - e.changedTouches[0].clientX;
        if (Math.abs(diff) > 40) goTo(current + (diff > 0 ? 1 : -1));
      }}
    >
      {SLIDES.map((slide, i) => (
        <img
          key={slide.id}
          src={slide.url}
          alt={slide.alt}
          className="absolute inset-0 w-full h-full object-cover transition-opacity duration-700"
          style={{ opacity: i === current ? 1 : 0 }}
        />
      ))}
      {/* Arrows */}
      <button
        onClick={() => goTo(current - 1)}
        className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1 shadow active:scale-90"
      >
        <ChevronLeft size={16} color={GREEN} />
      </button>
      <button
        onClick={() => goTo(current + 1)}
        className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1 shadow active:scale-90"
      >
        <ChevronRight size={16} color={GREEN} />
      </button>
    </div>
  );
}

function CarouselDots({ current, total, onChange }: { current: number; total: number; onChange: (i: number) => void }) {
  return (
    <div className="flex justify-center gap-1.5 py-2.5 bg-white">
      {Array.from({ length: total }).map((_, i) => (
        <button
          key={i}
          onClick={() => onChange(i)}
          className="rounded-full transition-all duration-300"
          style={{
            width: i === current ? 20 : 8,
            height: 8,
            backgroundColor: i === current ? GREEN : "#D1D5DB",
            padding: 0,
            minWidth: 0,
            minHeight: 0,
          }}
        />
      ))}
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [activeTab, setActiveTab] = useState("home");
  const [cartCount] = useState(2);
  const [wishlistCount] = useState(5);
  const [slideIndex, setSlideIndex] = useState(0);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    timerRef.current = setInterval(() => setSlideIndex(c => (c + 1) % SLIDES.length), 4000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  const goToSlide = (idx: number) => setSlideIndex((idx + SLIDES.length) % SLIDES.length);

  const tabs = [
    { id: "home",     Icon: Home,     label: "Home" },
    { id: "category", Icon: Grid3x3,  label: "Category" },
    { id: "reels",    Icon: Play,     label: "Reels" },
    { id: "profile",  Icon: User,     label: "Profile" },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: "#e8e3dc", fontFamily: "'DM Sans', sans-serif" }}>
      {/* Phone shell */}
      <div
        className="relative flex flex-col overflow-hidden shadow-2xl"
        style={{
          width: 390,
          height: 844,
          borderRadius: 44,
          backgroundColor: "#fff",
          border: "10px solid #1a1a1a",
          boxShadow: "0 0 0 2px #333, 0 40px 80px rgba(0,0,0,0.45)",
        }}
      >
        {/* Status bar */}
        <div className="flex items-center justify-between px-6 pt-3 pb-1 flex-shrink-0" style={{ backgroundColor: CREAM }}>
          <span className="text-[11px] font-semibold text-gray-700">9:41</span>
          <div className="w-24 h-5 bg-black rounded-full mx-auto" style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", top: 10, width: 80, height: 22 }} />
          <div className="flex items-center gap-1">
            <div className="flex gap-0.5 items-end">
              {[3, 4, 5, 6].map(h => <div key={h} className="w-0.5 bg-gray-700 rounded-sm" style={{ height: h }} />)}
            </div>
            <span className="text-[11px] font-semibold text-gray-700">100%</span>
          </div>
        </div>

        {/* Top Nav */}
        <header className="flex items-center justify-between px-4 py-2 flex-shrink-0 border-b" style={{ backgroundColor: CREAM, borderColor: SAGE + "55" }}>
          <a className="text-2xl italic font-semibold select-none" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>
            Tohfa<span style={{ color: GOLD }}>.</span>
          </a>
          <div className="flex items-center gap-1">
            <button onClick={() => setSearchOpen(true)} className="p-2 rounded-full active:scale-90 transition-transform relative" style={{ color: GREEN }}>
              <Search size={18} />
            </button>
            <button className="p-2 rounded-full active:scale-90 transition-transform relative" style={{ color: GREEN }}>
              <Heart size={18} fill={GREEN} />
              {wishlistCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 text-white text-[9px] w-3.5 h-3.5 rounded-full flex items-center justify-center font-bold" style={{ backgroundColor: GOLD, fontSize: 8 }}>
                  {wishlistCount}
                </span>
              )}
            </button>
            <button className="p-2 rounded-full active:scale-90 transition-transform relative" style={{ color: GREEN }}>
              <ShoppingCart size={18} />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 text-white text-[9px] w-3.5 h-3.5 rounded-full flex items-center justify-center font-bold" style={{ backgroundColor: GOLD, fontSize: 8 }}>
                  {cartCount}
                </span>
              )}
            </button>
            <button className="p-2 rounded-full active:scale-90 transition-transform relative" style={{ color: GREEN }}>
              <Bell size={18} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full" style={{ backgroundColor: GOLD }} />
            </button>
          </div>
        </header>

        {/* Scrollable content */}
        <main className="flex-1 overflow-y-auto" style={{ scrollbarWidth: "none" }}>

          {/* Hero Carousel */}
          <div
            className="relative w-full overflow-hidden select-none"
            style={{ aspectRatio: "4/3" }}
            onTouchStart={(e) => { (window as any)._tStart = e.changedTouches[0].clientX; }}
            onTouchEnd={(e) => {
              const diff = ((window as any)._tStart || 0) - e.changedTouches[0].clientX;
              if (Math.abs(diff) > 40) goToSlide(slideIndex + (diff > 0 ? 1 : -1));
            }}
          >
            {SLIDES.map((slide, i) => (
              <img
                key={slide.id}
                src={slide.url}
                alt={slide.alt}
                className="absolute inset-0 w-full h-full object-cover transition-opacity duration-700"
                style={{ opacity: i === slideIndex ? 1 : 0 }}
              />
            ))}
            <button onClick={() => goToSlide(slideIndex - 1)} className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1 shadow active:scale-90">
              <ChevronLeft size={16} color={GREEN} />
            </button>
            <button onClick={() => goToSlide(slideIndex + 1)} className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1 shadow active:scale-90">
              <ChevronRight size={16} color={GREEN} />
            </button>
          </div>

          {/* Carousel dots */}
          <div className="flex justify-center gap-1.5 py-2.5 bg-white">
            {SLIDES.map((_, i) => (
              <button
                key={i}
                onClick={() => goToSlide(i)}
                className="rounded-full transition-all duration-300"
                style={{ width: i === slideIndex ? 20 : 8, height: 8, backgroundColor: i === slideIndex ? GREEN : "#D1D5DB", padding: 0, minWidth: 0, minHeight: 0 }}
              />
            ))}
          </div>

          {/* Hero text block */}
          <div className="px-5 py-5 flex flex-col items-center text-center bg-white border-b" style={{ borderColor: "#e5e7eb" }}>
            <span className="text-[10px] tracking-widest font-bold uppercase mb-1.5" style={{ color: PLUM, fontFamily: "'DM Sans', sans-serif" }}>
              Est. 2024 • Handmade with Love
            </span>
            <h2 className="text-xl font-medium leading-tight mb-2" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>
              Artisan crafts for a <em>slower, intentional</em> life.
            </h2>
            <p className="text-xs text-gray-500 leading-relaxed max-w-xs mb-4">
              Discover hand-carved ceramics, sustainable textiles, and handcrafted stationery from local artisans.
            </p>
            <div className="flex gap-2.5 w-full max-w-[240px]">
              <button className="flex-1 py-2.5 rounded-xl text-white text-xs font-semibold active:opacity-80 transition-opacity" style={{ backgroundColor: GREEN }}>
                Explore
              </button>
              <button className="flex-1 py-2.5 rounded-xl text-xs font-semibold border active:bg-gray-50 transition-colors" style={{ color: GREEN, borderColor: "#74786f" }}>
                Our Story
              </button>
            </div>
          </div>

          {/* Sponsored */}
          <section className="px-4 pt-5 pb-2">
            <div className="rounded-2xl p-4" style={{ backgroundColor: CREAM }}>
              <div className="flex items-baseline justify-between mb-3">
                <div>
                  <div className="flex items-center gap-1">
                    <Star size={14} fill={GOLD} stroke="none" />
                    <h3 className="font-semibold text-sm" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>Sponsored</h3>
                  </div>
                  <p className="text-[11px] text-gray-500">Featured from our community</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {SPONSORED.map(p => <ProductCard key={p.id} product={p} />)}
              </div>
            </div>
          </section>

          {/* For You */}
          <section className="px-4 pt-5 pb-2">
            <div className="flex items-baseline justify-between mb-3">
              <div>
                <h3 className="font-semibold text-sm" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>For You</h3>
                <p className="text-[11px] text-gray-500">Handpicked treasures just for you</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {PRODUCTS.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </section>

          {/* Category Rows */}
          {CATEGORIES.map(cat => (
            <section key={cat.name} className="px-4 pt-5 pb-2">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-sm" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>{cat.name}</h3>
                <button className="text-[11px] font-semibold flex items-center gap-0.5" style={{ color: GREEN }}>
                  View All <ChevronRight size={12} />
                </button>
              </div>
              <div className="flex gap-3 overflow-x-auto pb-2" style={{ scrollbarWidth: "none" }}>
                {cat.products.map(p => <ProductCard key={p.id} product={p} compact />)}
              </div>
            </section>
          ))}

          {/* Footer mini */}
          <footer className="mx-4 my-5 rounded-2xl p-4 text-center" style={{ backgroundColor: CREAM }}>
            <p className="italic text-sm font-medium mb-1" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>
              Tohfa<span style={{ color: GOLD }}>.</span>
            </p>
            <p className="text-[10px] text-gray-500 mb-3">Cultivating a community of makers and dreamers.</p>
            <div className="flex gap-2 justify-center mb-3">
              {["New Arrivals", "Ceramics", "Stationery", "Home Decor"].map(l => (
                <button key={l} className="text-[10px] text-gray-500 hover:underline">{l}</button>
              ))}
            </div>
            <input
              placeholder="Your email address"
              className="w-full text-xs px-3 py-2 rounded-lg border mb-2 outline-none focus:ring-1"
              style={{ borderColor: "#c3c8c1", backgroundColor: "white" }}
            />
            <button className="w-full py-2 rounded-lg text-white text-[10px] font-bold uppercase tracking-widest" style={{ backgroundColor: GREEN }}>
              Subscribe
            </button>
            <p className="text-[9px] text-gray-400 mt-3">© 2024 Tohfa Artisan Studio. Handcrafted with intention.</p>
          </footer>

          {/* Bottom padding for nav bar */}
          <div className="h-16" />
        </main>

        {/* Bottom Navigation */}
        <nav className="absolute bottom-0 left-0 right-0 flex items-center justify-around py-2 border-t bg-white flex-shrink-0" style={{ borderColor: "#e5e7eb", paddingBottom: 20 }}>
          {tabs.map(({ id, Icon, label }) => {
            const active = activeTab === id;
            return (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className="flex flex-col items-center gap-0.5 px-3 active:scale-90 transition-transform"
              >
                <Icon size={22} stroke={active ? GREEN : "#9ca3af"} fill={active ? GREEN + "22" : "none"} strokeWidth={active ? 2 : 1.5} />
                <span className="text-[10px] font-medium" style={{ color: active ? GREEN : "#9ca3af" }}>{label}</span>
                {active && <div className="w-1 h-1 rounded-full" style={{ backgroundColor: GREEN }} />}
              </button>
            );
          })}
        </nav>

        {/* Search overlay */}
        {searchOpen && (
          <div className="absolute inset-0 z-50 flex flex-col" style={{ backgroundColor: "white" }}>
            <div className="flex items-center gap-3 px-4 py-3 border-b" style={{ backgroundColor: CREAM, borderColor: SAGE + "55" }}>
              <button onClick={() => setSearchOpen(false)} className="active:scale-90 transition-transform">
                <X size={20} color={GREEN} />
              </button>
              <input
                autoFocus
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search handcrafted goods…"
                className="flex-1 bg-transparent outline-none text-sm text-gray-800"
                style={{ fontFamily: "'DM Sans', sans-serif" }}
              />
            </div>
            <div className="flex-1 flex flex-col items-center justify-center gap-2 text-gray-400">
              <Search size={40} strokeWidth={1} />
              <p className="text-sm">Search for ceramics, textiles, stationery…</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
