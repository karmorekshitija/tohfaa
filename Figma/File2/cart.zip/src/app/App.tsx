import { useState } from "react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";

const c = {
  primary:    "#255338",
  forest:     "#3D6B4F",
  tertiary:   "#573b81",
  surface:    "#fff8f3",
  ivory:      "#FCFAF5",
  sageSoft:   "#C5D6BC",
  surfaceContainerLow: "#fff2e1",
  secondaryContainer: "#c8e9b8",
  errorContainer: "#ffdad6",
  terracotta: "#b14b3e",
  error:      "#ba1a1a",
  onSurface:  "#211b11",
  onSurfaceVariant: "#414942",
  outlineVariant: "#c1c9c0",
  outline:    "#717972",
  gold:       "#D4AF37",
  sage:       "#717972",
};

const f = {
  display: "'Playfair Display', Georgia, serif",
  serif:   "'Merriweather', Georgia, serif",
  sans:    "'DM Sans', system-ui, sans-serif",
  caps:    "'Cinzel', Georgia, serif",
  mono:    "'Space Mono', monospace",
};

function Icon({ name, filled = false, size = 22, color, style = {} }: {
  name: string; filled?: boolean; size?: number; color?: string; style?: React.CSSProperties;
}) {
  return (
    <span className="material-symbols-outlined" style={{ fontSize: size, color, fontVariationSettings: filled ? "'FILL' 1" : "'FILL' 0", lineHeight: 1, display: "inline-block", flexShrink: 0, ...style }}>
      {name}
    </span>
  );
}

type CartItem = {
  id: number;
  name: string;
  unitPrice: number;
  qty: number;
  img: string;
  warning?: string;
};

const INITIAL_ITEMS: CartItem[] = [
  {
    id: 1,
    name: "Hand-thrown Stoneware Mug",
    unitPrice: 32,
    qty: 1,
    img: "https://lh3.googleusercontent.com/aida-public/AB6AXuAVpwycJK2zhmumdgnLmSMnWnGn4YMnsMJxeWLrl5v2o_pT8HWw_ZDq3hwJoG3aa5yahYvHanjdLixFtH50-Wn6Llvxslv_hahGSxEx6Fdi7LsSrlAubdLQS2gx7CQdrrBsNC_vfzRnqGSjzC-SuNG1zmCcdhI885TKcVjX2biI2BWpMWBahXFXOOaMabvcUMX1bBIteveo3OKHcWuGNezD9cJB2gJcQ7Bv2H61k8CoRQCEEbY1WmwS7Nqb3Dk_-BESupKjL8DUr6o",
  },
  {
    id: 2,
    name: "Wildflower Soy Candle Set",
    unitPrice: 48,
    qty: 2,
    img: "https://lh3.googleusercontent.com/aida-public/AB6AXuDLg699NCrj_mrmJTazTY3zHTbT0dIuunRdM33fXDaqAp3tkY5NekMlfHKFxBPZB8QkO64yULvMH4NmejrbEWZgzJ2ICuY_mIj0PWJTIM_O0l0zxQ_lw1Xmj6XmsnqYdRBrmp101_Avan4jySm_Gozye-OAGQiBrVEKWTKmfQnRzV7no4TVRUX0VpFqZgL87_2cPUhAfK44J-LL8Kk_lUoDKLFN2X-0FfugvIzo03SS6mEejVA8tfDEuMrYdZb-hGUIqkb8d1BR1Xc",
    warning: "Only 2 left — adjust quantity",
  },
  {
    id: 3,
    name: "Loom-Woven Linen Scarf",
    unitPrice: 55,
    qty: 1,
    img: "https://lh3.googleusercontent.com/aida-public/AB6AXuAb-Ncg1LvTbCZwZd5t6XMYw_PVx4ItZXFwhRelwyC3pPRr8xitZElkezn7J_rmBKKnABYQ0saUTiTc0Xl4QvyfHup8zkZqmbNNC2U3q057ea9A46EUPZ4_a4VonfRMveSPpqmhNlWKvHUp_347j3Y73rMMeQa0HZAa0sGk-9KyAYN7N_w_9-xPe3VivpnrfnN0bLKKhNAASCfRtP8uishAEpt1gUSfUkF8RV9LDe9G4B7Jx3J7moAb4uxT70TZ6dVjXMAdRk8lIs8",
  },
];

const SHIPPING = 12.50;
const MASCOT_URL = "https://lh3.googleusercontent.com/aida-public/AB6AXuAwPPInqSnaA3uaZ5Yq70q9DNjARcp0RoLPwYRx6UNhE0vj4foTDhgdflxOKacn8lzJR2Vy5b3SZcjrJksiOCBYW85MYOmAYdVd02h-M-NOGD4cmHYxalB5dl5ncLyPY3TlvEy27jcDrhpRjytdxY6ZcYaumssfKvNkXQm3vm-PKvVu0EdB2KiEX6pBof_CUHTAqFkHf76Tl5aqODiTQNhcr3jV_e3za0itc0RvwvWc-4CasEPgi9zzAaBd8mqim-S4RfcFSx5cpcc";

export default function App() {
  const [activeTab, setActiveTab] = useState<"home"|"category"|"reels"|"profile">("home");
  const [items, setItems] = useState<CartItem[]>(INITIAL_ITEMS);

  const updateQty = (id: number, delta: number) => {
    setItems(prev => prev.map(item =>
      item.id === id ? { ...item, qty: Math.max(1, item.qty + delta) } : item
    ));
  };

  const removeItem = (id: number) => setItems(prev => prev.filter(i => i.id !== id));

  const subtotal = items.reduce((s, i) => s + i.unitPrice * i.qty, 0);
  const total = subtotal + SHIPPING;

  return (
    <div className="min-h-screen w-full flex items-center justify-center" style={{ background: "#ddd5c8" }}>
      <div style={{
        width: 390, height: 844, borderRadius: 48,
        boxShadow: "0 48px 96px rgba(0,0,0,0.38), 0 0 0 10px #1a1a1a, 0 0 0 12px #2e2e2e",
        background: "#fff", display: "flex", flexDirection: "column",
        overflow: "hidden", fontFamily: f.sans, position: "relative",
      }}>

        {/* ── Status bar ── */}
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"12px 24px 6px", position:"relative", zIndex:50, flexShrink:0, background:"#fff" }}>
          <span style={{ fontFamily:f.sans, fontSize:13, fontWeight:600, color:c.onSurface }}>9:41</span>
          <div style={{ width:126, height:32, borderRadius:20, background:"#111", position:"absolute", left:"50%", transform:"translateX(-50%)", top:8 }} />
          <div style={{ display:"flex", alignItems:"center", gap:4 }}>
            <Icon name="signal_cellular_alt" size={15} color={c.onSurface} />
            <Icon name="wifi"                size={15} color={c.onSurface} />
            <Icon name="battery_5_bar"       size={15} color={c.onSurface} />
          </div>
        </div>

        {/* ── Top nav ── */}
        <header style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 20px", height:52, background:"#fff", borderBottom:`1px solid ${c.outlineVariant}`, flexShrink:0, zIndex:40 }}>
          <div style={{ display:"flex", alignItems:"flex-end" }}>
            <span style={{ fontFamily:f.display, fontSize:22, fontStyle:"italic", fontWeight:400, color:c.primary, lineHeight:1 }}>Tohfa</span>
            <span style={{ width:5, height:5, borderRadius:"50%", background:c.gold, marginBottom:4, marginLeft:1 }} />
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:14 }}>
            <Icon name="search"        size={20} color={c.primary} />
            <div style={{ position:"relative" }}>
              <Icon name="shopping_cart" size={20} color={c.primary} />
              {items.length > 0 && (
                <span style={{ position:"absolute", top:-5, right:-5, width:15, height:15, borderRadius:"50%", background:c.gold, color:"#fff", fontSize:8, fontWeight:700, fontFamily:f.sans, display:"flex", alignItems:"center", justifyContent:"center" }}>
                  {items.reduce((s,i)=>s+i.qty,0)}
                </span>
              )}
            </div>
            <Icon name="notifications" size={20} color={c.primary} />
            <div style={{ width:30, height:30, borderRadius:"50%", background:c.forest, color:"#fff", fontSize:12, fontFamily:f.sans, fontWeight:700, display:"flex", alignItems:"center", justifyContent:"center", border:`1.5px solid ${c.outlineVariant}` }}>A</div>
          </div>
        </header>

        {/* ── Scrollable body ── */}
        <div style={{ flex:1, overflowY:"auto", background:"#fff", paddingBottom:80 }}>
          <div style={{ padding:"16px 16px 0" }}>

            {/* Page header */}
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16 }}>
              <div style={{ display:"flex", alignItems:"center", gap:4 }}>
                <button style={{ background:"none", border:"none", cursor:"pointer", display:"flex", alignItems:"center", padding:4, borderRadius:"50%" }}>
                  <Icon name="chevron_left" size={22} color={c.onSurface} />
                </button>
                <h1 style={{ fontFamily:f.display, fontSize:22, fontStyle:"italic", fontWeight:500, color:c.primary, margin:0, lineHeight:1 }}>
                  Your basket
                </h1>
              </div>
              <div style={{ background:`${c.gold}18`, borderRadius:9999, padding:"4px 12px" }}>
                <span style={{ fontFamily:f.mono, fontSize:11, fontWeight:700, color:c.gold }}>
                  {items.length} ITEMS
                </span>
              </div>
            </div>

            {/* ── Cart items ── */}
            <div style={{ display:"flex", flexDirection:"column", gap:10, marginBottom:16 }}>
              {items.map(item => (
                <div key={item.id} style={{ background:c.ivory, border:`1px solid ${c.outlineVariant}40`, borderRadius:18, padding:"12px 12px", overflow:"hidden" }}>
                  <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                    {/* Product image */}
                    <div style={{ width:60, height:60, borderRadius:10, overflow:"hidden", flexShrink:0, boxShadow:"0 2px 8px rgba(0,0,0,0.08)" }}>
                      <ImageWithFallback src={item.img} alt={item.name} style={{ width:"100%", height:"100%", objectFit:"cover" }} />
                    </div>

                    {/* Name + price */}
                    <div style={{ flex:1, minWidth:0 }}>
                      <p style={{ fontFamily:f.serif, fontSize:12, fontWeight:700, color:c.onSurface, margin:"0 0 3px", lineHeight:1.35, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>
                        {item.name}
                      </p>
                      <p style={{ fontFamily:f.mono, fontSize:11, color:c.gold, margin:0 }}>
                        ${item.unitPrice.toFixed(2)}
                      </p>
                    </div>

                    {/* Qty + total + remove */}
                    <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:6, flexShrink:0 }}>
                      {/* Qty stepper */}
                      <div style={{ display:"flex", alignItems:"center", background:c.ivory, border:`1px solid ${c.outlineVariant}60`, borderRadius:9999, padding:"2px 6px", gap:2 }}>
                        <button
                          onClick={() => updateQty(item.id, -1)}
                          style={{ width:22, height:22, display:"flex", alignItems:"center", justifyContent:"center", background:"none", border:"none", cursor:"pointer", color:c.sage, fontSize:16, fontFamily:f.sans, lineHeight:1 }}
                        >−</button>
                        <span style={{ fontFamily:f.mono, fontSize:11, color:c.onSurface, padding:"0 5px", minWidth:16, textAlign:"center" }}>{item.qty}</span>
                        <button
                          onClick={() => updateQty(item.id, 1)}
                          style={{ width:22, height:22, display:"flex", alignItems:"center", justifyContent:"center", background:"none", border:"none", cursor:"pointer", color:c.sage, fontSize:16, fontFamily:f.sans, lineHeight:1 }}
                        >+</button>
                      </div>
                      {/* Line total + remove */}
                      <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                        <span style={{ fontFamily:f.mono, fontSize:12, fontWeight:700, color:c.onSurface }}>
                          ${(item.unitPrice * item.qty).toFixed(2)}
                        </span>
                        <button
                          onClick={() => removeItem(item.id)}
                          style={{ background:"none", border:"none", cursor:"pointer", display:"flex", alignItems:"center", padding:2 }}
                        >
                          <Icon name="close" size={14} color={c.outline} />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Stock warning */}
                  {item.warning && (
                    <div style={{ display:"flex", alignItems:"center", gap:6, marginTop:8, background:`${c.errorContainer}33`, borderRadius:8, padding:"5px 8px" }}>
                      <Icon name="error" filled size={14} color={c.terracotta} />
                      <span style={{ fontFamily:f.sans, fontSize:11, color:c.terracotta }}>{item.warning}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* ── Ship to ── */}
            <div style={{ background:c.ivory, border:`1px solid ${c.outlineVariant}40`, borderRadius:18, padding:"14px 16px", marginBottom:12, position:"relative", overflow:"hidden" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
                <span style={{ fontFamily:f.caps, fontSize:9, fontWeight:700, color:c.sage, letterSpacing:"0.12em", textTransform:"uppercase" }}>SHIP TO</span>
                <button style={{ background:"none", border:"none", fontFamily:f.sans, fontSize:12, fontWeight:600, color:c.tertiary, cursor:"pointer", padding:0 }}>Edit</button>
              </div>
              <div style={{ display:"flex", gap:10, alignItems:"flex-start" }}>
                <Icon name="location_on" size={18} color={c.sage} style={{ marginTop:1 }} />
                <div style={{ fontFamily:f.sans, fontSize:13, color:c.onSurfaceVariant, lineHeight:1.6 }}>
                  <p style={{ fontWeight:700, color:c.onSurface, margin:"0 0 1px" }}>Amara Sterling</p>
                  <p style={{ margin:0 }}>128 Artisan Lane, Studio B</p>
                  <p style={{ margin:0 }}>Oak Creek, WI 53154</p>
                </div>
              </div>
            </div>

            {/* ── Order summary ── */}
            <div style={{ background:c.sageSoft, borderRadius:18, padding:"16px 16px", marginBottom:16, position:"relative", overflow:"hidden" }}>
              <p style={{ fontFamily:f.caps, fontSize:9, fontWeight:700, color:c.primary, letterSpacing:"0.12em", textTransform:"uppercase", margin:"0 0 14px" }}>ORDER SUMMARY</p>

              <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <span style={{ fontFamily:f.sans, fontSize:13, color:c.onSurfaceVariant }}>Subtotal</span>
                  <span style={{ fontFamily:f.mono, fontSize:13, color:c.onSurface }}>${subtotal.toFixed(2)}</span>
                </div>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <span style={{ fontFamily:f.sans, fontSize:13, color:c.onSurfaceVariant }}>Shipping</span>
                  <span style={{ fontFamily:f.mono, fontSize:13, color:c.onSurface }}>${SHIPPING.toFixed(2)}</span>
                </div>
                <div style={{ height:1, background:`${c.outlineVariant}40`, margin:"2px 0" }} />
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <span style={{ fontFamily:f.serif, fontSize:14, fontWeight:700, color:c.primary }}>Total</span>
                  <span style={{ fontFamily:f.mono, fontSize:18, fontWeight:700, color:c.gold }}>${total.toFixed(2)}</span>
                </div>
              </div>

              {/* Botanical star watermark */}
              <div style={{ position:"absolute", bottom:10, right:12, opacity:0.08, pointerEvents:"none" }}>
                <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke={c.primary} strokeWidth="1">
                  <path d="M12 22C12 22 12 18 15 15C18 12 22 12 22 12C22 12 18 12 15 9C12 6 12 2 12 2C12 2 12 6 9 9C6 12 2 12 2 12C2 12 6 12 9 15C12 18 12 22 12 22Z" />
                </svg>
              </div>
            </div>

            {/* ── Mascot sticker ── */}
            <div style={{ display:"flex", flexDirection:"column", alignItems:"center", paddingBottom:8, gap:6 }}>
              <div style={{ position:"relative" }}>
                <div style={{ position:"absolute", inset:-8, background:"rgba(255,255,255,0.6)", filter:"blur(8px)", borderRadius:"50%" }} />
                <div style={{ position:"relative", transform:"rotate(6deg)" }}>
                  <ImageWithFallback
                    src={MASCOT_URL}
                    alt="Tohfa mascot"
                    style={{ width:60, height:60, objectFit:"contain", filter:"drop-shadow(2px 4px 6px rgba(0,0,0,0.1))" }}
                  />
                </div>
              </div>
              <p style={{ fontFamily:f.serif, fontSize:11, fontStyle:"italic", color:c.sage, margin:0 }}>Almost yours!</p>
            </div>
          </div>
        </div>

        {/* ── Sticky Place Order bar ── */}
        <div style={{ position:"absolute", bottom:0, left:0, right:0, background:"#fff", borderTop:`1px solid ${c.outlineVariant}30`, padding:"12px 16px 16px", zIndex:50 }}>
          <button style={{
            width:"100%", height:52,
            background:c.primary, color:"#fff",
            border:"none", borderRadius:12,
            display:"flex", alignItems:"center", justifyContent:"center",
            gap:12, cursor:"pointer",
            fontFamily:f.sans, fontSize:15, fontWeight:700,
            boxShadow:`0 8px 24px ${c.primary}30`,
            transition:"opacity 0.15s",
          }}>
            <span>Place order</span>
            <span style={{ fontFamily:f.mono, fontSize:13, borderLeft:"1px solid rgba(255,255,255,0.25)", paddingLeft:12 }}>
              ${total.toFixed(2)}
            </span>
          </button>
        </div>

        {/* ── Bottom nav (hidden behind sticky bar — swapped to tabs for nav context) ── */}
        <div style={{ display:"none" }}>
          {([
            { id:"home",     icon:"home",        label:"Home" },
            { id:"category", icon:"category",    label:"Category" },
            { id:"reels",    icon:"play_circle", label:"Reels" },
            { id:"profile",  icon:"person",      label:"Profile" },
          ] as const).map(tab => {
            const active = activeTab === tab.id;
            return (
              <button key={tab.id} onClick={()=>setActiveTab(tab.id)} style={{ background:"none", border:"none", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:3, padding:"8px 12px", borderRadius:8 }}>
                <Icon name={tab.icon} filled={active} size={22} color={active ? c.primary : c.onSurfaceVariant} />
                <span style={{ fontFamily:f.caps, fontSize:9, fontWeight:active?700:400, letterSpacing:"0.06em", color:active ? c.primary : c.onSurfaceVariant, textTransform:"uppercase" }}>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
