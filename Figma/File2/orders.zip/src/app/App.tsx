import { useState } from "react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";

const c = {
  primary:    "#255338",
  forest:     "#3D6B4F",
  tertiary:   "#573b81",
  surface:    "#fff8f3",
  ivory:      "#FCFAF5",
  surfaceContainerLow: "#fff2e1",
  onSurface:  "#211b11",
  onSurfaceVariant: "#414942",
  outlineVariant: "#c1c9c0",
  outline:    "#717972",
  gold:       "#D4AF37",
};

const f = {
  display: "'Playfair Display', Georgia, serif",
  serif:   "'Merriweather', Georgia, serif",
  sans:    "'DM Sans', system-ui, sans-serif",
  caps:    "'Cinzel', Georgia, serif",
  mono:    "'Space Mono', monospace",
};

function Icon({ name, filled = false, size = 22, color, style = {} }: {
  name: string; filled?: boolean; size?: number; color?: string; style?: React.CSSProperties;
}) {
  return (
    <span
      className="material-symbols-outlined"
      style={{ fontSize: size, color, fontVariationSettings: filled ? "'FILL' 1" : "'FILL' 0", lineHeight: 1, display: "inline-block", ...style }}
    >
      {name}
    </span>
  );
}

type Filter = "All" | "Active" | "Delivered" | "Cancelled";

type Order = {
  id: string;
  date: string;
  name: string;
  status: string;
  statusColor: string;
  statusBg: string;
  statusBorder?: string;
  price: string;
  cancelled?: boolean;
  imgs: string[];
};

const orders: Order[] = [
  {
    id: "#TF-9821-H", date: "Oct 12, 2023",
    name: "Brass diya + 2 more",
    status: "Delivered",
    statusBg: c.primary, statusColor: "#fff",
    price: "₹2,450",
    imgs: [
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAGZTdej-6N2ACkR9IbVxd7gu5qSu4FNe5lwv6v4v7AAHKZVQT8l0T-jagUfLqaj8CHwt9pAzzdFl4hOZExk3jW0fVa9oZo_rMO88NobDArWYIp56eAjcmJdV8zdXtvmxdWy_zGewBperuB0lp4Ynf3ys4lLCs_YL3K8T2z_EXrA4hkD6op_BOcO3cYVr_LSMPqld7LybomupDic1cMndOuMjjvVYaxvxkhrw6UuXFj9wfkODiBps5YYmYjR1nmBgcQYpgFEPfqfNI",
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDfflqr1HA8RsAhKCuVQYAOrOCQOnWlQW1qUJRMdaobAwNjruPojQT3Uh0aTiZt0R5ML9GYfbUyn4xUKmmlGQHmZXz3pxixzHyKwx52yvaeq2KPQeOZjqVRFxeXhyUKEkYWsTGeySqIWhl-IonEvqO6-xEGLES485nj1QEji7Tvkxstks9tH-HBQCOJXI_6mz9YULg6R8rYviDHsFBnm6lmHw3Zj12HXANrEEiyMP5YSxyfWEUn_WoX5AY9o68TUT190idUOzOXFSU",
      "https://lh3.googleusercontent.com/aida-public/AB6AXuBbwwcf-5ckNTw4ZxjW7LP6NNf92qUTiyAhQWV05l2fE4JkpI-HMJmpqxJAancNw1R_FuKz0OJYotJi8dicor7mFGLDSfr6rrplrfHsXMb8vc7MfTmkY3_Bw69kXOD4irSN5koCAdAeNwyLW4Bt0xlOSXIN9KtbhcssyLfhu7IACe2j3SYqN-4FyxQ0IMdzgVwjsg9mK595UdfVak6AAxGIj6uNTh7eKLg7RmTwNHJMVET-hK9hS9GKhaUhOx8aXvN4cHgdTDdyMLE",
    ],
  },
  {
    id: "#TF-1044-K", date: "Yesterday, 4:15 PM",
    name: "Journal Set + Artisan Honey",
    status: "Processing",
    statusBg: "#f5f0ff", statusColor: "#4c1d95", statusBorder: "#c4b5fd",
    price: "₹1,890",
    imgs: [
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDeV6DpSwa6o--bazf396FgJi8KaEySRDUjEit3VL0RNVnh-2x2yztp4RvJgIdHLVer35_RGvbiBH1v50gaz5-qaJ0Pgb7JWva2KpyL28T3MeUMqyPjZ0T7zzK34s0VnCkrfxFCKcs8-3EvzEhtQIGRiJOBJ20FoIfGJYrrf3tJhcRVkQ7CWYusLczHVabKMWJTWTr6cpzUcYN-gWjxQkRq7sbPAkKHoHoBYkky21rSUNSp8ossjfbrvFlYEEdjCeHoxLCu74a1mZI",
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAP5mPtpBt8gEY5BmmOUpnG99R-Nlxo4vjzc9twyE43FT92sWInW69k2ryFIJmSslPMIc0exyjOT4hwt3dIFRCZ6q1gyJxjwBFLRf8Op9ZY-SyOuT-i5jzd3nBw3tahTmhCJQ39NyuI7FE8-mo61KSmHaEVwCtBg_zOi_TDc4T16C4FCt01afBpEYsAAW4aDkjP6RP2xObV8oJHf-kdadDdSfINKYl5hwUZYFkyu7B2vAV2kP0u4lAvs7DMToKcoqcgKzFtxmF32ck",
    ],
  },
  {
    id: "#TF-0552-S", date: "Nov 2, 2023",
    name: "Hand-carved Teak Spoon",
    status: "Shipped",
    statusBg: "#C8D7BF", statusColor: c.primary, statusBorder: c.outlineVariant,
    price: "₹950",
    imgs: [
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAcwboXKmTGAQ-o49D-9V7iinL2yT9A2qzjh1mGCYxMERdPdNLEvJAZXMP5oKWsNaKWmcnySoAyV450zEngfcUp31oDywX-fSwLosvT35uZABvf3tvj2UFw0Etoi7c8SbR3w-DZWmcDRlSMtmFsZAgjPAVkuGr5xLAgPkCotih3s3T9W3ZRGU-qAhZT6xzgoojgqk88Wt_o26BZyMndzKxCyY7M4UU5thQQg03kKVsS1dJrh5sn-2D4EORB1NyH-smsfzSXKKO4y6U",
    ],
  },
  {
    id: "#TF-3391-P", date: "Nov 5, 2023",
    name: "Noir Soy Candle",
    status: "Awaiting Payment",
    statusBg: "#F9ECDC", statusColor: "#B8860B",
    price: "₹1,200",
    imgs: [
      "https://lh3.googleusercontent.com/aida-public/AB6AXuC4qxn7mSNjfTqnEhhj1UfImRq5LnttNlzDT6pDsNA2o3kgsS4ezlmvO1IyVMKQq7Q8_t2ZPJraMWXAL2rlEkozOjgmINz8F6-AgNXJoxdrs58PNkBs1APxsrmLRrDF4aEN-oMDO_H1pJS2S8BJZyA6F11Z3EgFk2K8JiOylnd3BDJrD10EmKtLioxPK-aRi_OpeBJR98C9a_A8Ob9xVmhkKQPasosuTnUFzAe7Br4m0lpqHVVtOv6Hubnr78Cit3eu5FV4d86XZrE",
    ],
  },
  {
    id: "#TF-0012-C", date: "Sep 28, 2023",
    name: "Ceramic Bowl",
    status: "Cancelled",
    statusBg: "#F9ECDC", statusColor: "#A64B2A",
    price: "₹450",
    cancelled: true,
    imgs: [
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDNTVyg7J9H2GhS-l6WwTmYZdo4kDBtRotDa6Oaly_5CPSn36tnyD16IReVBJHdJswJK-OxftBP22jmC-kYzMb1Puc9rAT9ThAyZGyStD607x6n8c3Cc6bFltlTwOKl1XWSc-aD8n3RPngS--TStVQjOMHXwyyAUAkFPk-IecfAffqtoiWJTFQpSprcIMbEteH90_m17isQ8ngyErDGClUZkKqzaMG2w1kZ5I9HAgnPVtk-2vNfphiLVQ1iTzxZsHgmapSPoT9C8XY",
    ],
  },
];

const filters: Filter[] = ["All", "Active", "Delivered", "Cancelled"];

function statusMatchesFilter(status: string, filter: Filter): boolean {
  if (filter === "All") return true;
  if (filter === "Active") return status === "Processing" || status === "Shipped" || status === "Awaiting Payment";
  if (filter === "Delivered") return status === "Delivered";
  if (filter === "Cancelled") return status === "Cancelled";
  return true;
}

function OrderCard({ order }: { order: Order }) {
  return (
    <div
      style={{
        background: c.ivory,
        border: `1px solid ${c.outlineVariant}`,
        borderRadius: 14,
        padding: "12px 12px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        boxShadow: "0 2px 8px rgba(58,51,40,0.05)",
        opacity: order.cancelled ? 0.72 : 1,
      }}
    >
      {/* Left: thumbs + info */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, flex: 1, minWidth: 0 }}>
        {/* Overlapping thumbnails */}
        <div style={{ position: "relative", width: 48, height: 40, flexShrink: 0 }}>
          {order.imgs.slice(0, 3).map((url, i) => (
            <div
              key={i}
              style={{
                position: "absolute",
                left: i * 12,
                top: i === 1 ? 0 : 4,
                width: 30, height: 30,
                borderRadius: 8,
                border: "2px solid #fff",
                overflow: "hidden",
                zIndex: order.imgs.length - i,
                boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
                filter: order.cancelled ? "grayscale(1)" : "none",
                opacity: i === 2 ? 0.6 : 1,
              }}
            >
              <ImageWithFallback
                src={url}
                alt=""
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
            </div>
          ))}
        </div>

        {/* Text */}
        <div style={{ minWidth: 0 }}>
          <p style={{ fontFamily: f.mono, fontSize: 9, color: c.outline, textTransform: "uppercase", letterSpacing: "0.08em", margin: 0 }}>
            {order.id}
          </p>
          <p style={{ fontFamily: f.sans, fontSize: 10, color: c.onSurfaceVariant, margin: "1px 0 3px" }}>
            {order.date}
          </p>
          <p style={{
            fontFamily: f.serif, fontSize: 12, fontWeight: 700, color: c.onSurface,
            margin: 0, lineHeight: 1.3, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
            maxWidth: 140,
            textDecoration: order.cancelled ? "line-through" : "none",
          }}>
            {order.name}
          </p>
          {/* Status pill — below name on mobile */}
          <span
            style={{
              display: "inline-block",
              marginTop: 5,
              fontFamily: f.caps,
              fontSize: 8,
              fontWeight: 700,
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              background: order.statusBg,
              color: order.statusColor,
              border: order.statusBorder ? `1px solid ${order.statusBorder}` : "none",
              borderRadius: 9999,
              padding: "3px 8px",
            }}
          >
            {order.status}
          </span>
        </div>
      </div>

      {/* Right: price + chevron */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6, flexShrink: 0, paddingLeft: 8 }}>
        <span style={{
          fontFamily: f.mono,
          fontSize: 13, fontWeight: 700,
          color: order.cancelled ? c.outline : c.tertiary,
          textDecoration: order.cancelled ? "line-through" : "none",
        }}>
          {order.price}
        </span>
        <Icon name="chevron_right" size={18} color={c.outline} />
      </div>
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<"home" | "category" | "reels" | "profile">("profile");
  const [filter, setFilter] = useState<Filter>("All");

  const visible = orders.filter((o) => statusMatchesFilter(o.status, filter));

  return (
    <div className="min-h-screen w-full flex items-center justify-center" style={{ background: "#ddd5c8" }}>
      <div style={{
        width: 390, height: 844,
        borderRadius: 48,
        boxShadow: "0 48px 96px rgba(0,0,0,0.38), 0 0 0 10px #1a1a1a, 0 0 0 12px #2e2e2e",
        background: c.surface,
        display: "flex", flexDirection: "column",
        overflow: "hidden",
        fontFamily: f.sans,
        position: "relative",
      }}>

        {/* ── Status bar ── */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 24px 6px", position: "relative", zIndex: 50, flexShrink: 0 }}>
          <span style={{ fontFamily: f.sans, fontSize: 13, fontWeight: 600, color: c.onSurface }}>9:41</span>
          <div style={{ width: 126, height: 32, borderRadius: 20, background: "#111", position: "absolute", left: "50%", transform: "translateX(-50%)", top: 8 }} />
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <Icon name="signal_cellular_alt" size={15} color={c.onSurface} />
            <Icon name="wifi"                size={15} color={c.onSurface} />
            <Icon name="battery_5_bar"       size={15} color={c.onSurface} />
          </div>
        </div>

        {/* ── Top nav ── */}
        <header style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "0 20px", height: 52,
          background: "#fff",
          borderBottom: `1px solid ${c.outlineVariant}`,
          flexShrink: 0, zIndex: 40,
        }}>
          <div style={{ display: "flex", alignItems: "flex-end" }}>
            <span style={{ fontFamily: f.display, fontSize: 23, fontStyle: "italic", fontWeight: 400, color: c.primary, lineHeight: 1 }}>Tohfa</span>
            <span style={{ width: 5, height: 5, borderRadius: "50%", background: c.gold, marginBottom: 5, marginLeft: 1, flexShrink: 0 }} />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <Icon name="search"        size={20} color={c.primary} />
            <Icon name="shopping_bag"  size={20} color={c.primary} />
            <Icon name="notifications" size={20} color={c.primary} />
            <div style={{ width: 30, height: 30, borderRadius: "50%", background: c.forest, color: "#fff", fontSize: 12, fontFamily: f.sans, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", border: `1.5px solid ${c.outlineVariant}` }}>
              A
            </div>
          </div>
        </header>

        {/* ── Scrollable body ── */}
        <div style={{ flex: 1, overflowY: "auto", padding: "0 0 88px" }}>

          {/* Page header */}
          <div style={{ padding: "22px 20px 14px" }}>
            <h1 style={{
              fontFamily: f.display,
              fontSize: 28, fontWeight: 500, fontStyle: "italic",
              color: c.onSurface, margin: 0, lineHeight: 1.2,
            }}>
              Your orders
            </h1>
          </div>

          {/* Filter pills */}
          <div style={{ display: "flex", gap: 8, padding: "0 20px 18px", overflowX: "auto" }}>
            {filters.map((fil) => {
              const active = filter === fil;
              return (
                <button
                  key={fil}
                  onClick={() => setFilter(fil)}
                  style={{
                    flexShrink: 0,
                    padding: "6px 16px",
                    borderRadius: 9999,
                    border: active ? "none" : `1px solid ${c.outlineVariant}`,
                    background: active ? c.primary : c.ivory,
                    color: active ? "#fff" : c.primary,
                    fontFamily: f.caps,
                    fontSize: 9,
                    fontWeight: 700,
                    letterSpacing: "0.1em",
                    textTransform: "uppercase",
                    cursor: "pointer",
                    transition: "all 0.15s",
                  }}
                >
                  {fil}
                </button>
              );
            })}
          </div>

          {/* Orders list */}
          <div style={{ padding: "0 16px", display: "flex", flexDirection: "column", gap: 10 }}>
            {visible.length === 0 ? (
              <div style={{ textAlign: "center", padding: "48px 0", color: c.outline }}>
                <Icon name="inventory_2" size={40} color={c.outlineVariant} style={{ display: "block", margin: "0 auto 12px" }} />
                <p style={{ fontFamily: f.sans, fontSize: 13, fontStyle: "italic", opacity: 0.7 }}>No orders here yet.</p>
              </div>
            ) : (
              visible.map((order) => <OrderCard key={order.id} order={order} />)
            )}
          </div>

          {/* Footer nudge */}
          <div style={{ textAlign: "center", padding: "28px 20px 0" }}>
            <p style={{ fontFamily: f.sans, fontSize: 12, fontStyle: "italic", color: c.onSurfaceVariant, opacity: 0.6, margin: "0 0 8px" }}>
              Looking for something special? Our artisans are always creating.
            </p>
            <button style={{ background: "none", border: "none", fontFamily: f.sans, fontSize: 12, fontWeight: 700, color: c.tertiary, cursor: "pointer", borderBottom: `1px solid ${c.tertiary}44`, paddingBottom: 2 }}>
              Browse the Studio
            </button>
          </div>

          {/* Footer rule */}
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 10, padding: "24px 0 4px", opacity: 0.2 }}>
            <div style={{ width: 36, height: 1, background: c.outline }} />
            <Icon name="eco" size={13} color={c.outline} />
            <div style={{ width: 36, height: 1, background: c.outline }} />
          </div>
        </div>

        {/* ── Bottom nav ── */}
        <nav style={{
          display: "flex", alignItems: "center", justifyContent: "space-around",
          borderTop: `1px solid ${c.outlineVariant}`,
          background: c.surface,
          height: 72,
          position: "absolute", bottom: 0, left: 0, right: 0,
          zIndex: 40,
        }}>
          {([
            { id: "home",     icon: "home",        label: "Home" },
            { id: "category", icon: "category",    label: "Category" },
            { id: "reels",    icon: "play_circle", label: "Reels" },
            { id: "profile",  icon: "person",      label: "Profile" },
          ] as const).map((tab) => {
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{ background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "8px 12px", borderRadius: 8 }}
              >
                <Icon name={tab.icon} filled={active} size={22} color={active ? c.primary : c.onSurfaceVariant} />
                <span style={{ fontFamily: f.caps, fontSize: 9, fontWeight: active ? 700 : 400, letterSpacing: "0.06em", color: active ? c.primary : c.onSurfaceVariant, textTransform: "uppercase" }}>
                  {tab.label}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
