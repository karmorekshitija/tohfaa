import { useState, useEffect } from "react";

const colors = {
  primary: "#255338",
  forest: "#3D6B4F",
  sageSoft: "#C5D6BC",
  sage: "#8FAF82",
  gold: "#C8973A",
  ink: "#3A3328",
  muted: "#6E6453",
  mutedLight: "#9A8F7A",
  surface: "#fff8f3",
  outlineVariant: "#c1c9c0",
  onSurfaceVariant: "#414942",
  tertiary: "#573b81",
};

function MaterialIcon({ name, filled = false, style = {}, className = "" }: {
  name: string;
  filled?: boolean;
  style?: React.CSSProperties;
  className?: string;
}) {
  return (
    <span
      className={`material-symbols-outlined ${className}`}
      style={{
        fontFamily: "'Material Symbols Outlined'",
        fontVariationSettings: filled ? "'FILL' 1" : "'FILL' 0",
        ...style,
      }}
    >
      {name}
    </span>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<"home" | "category" | "reels" | "profile">("home");
  const [dots, setDots] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setDots((d) => (d + 1) % 4), 600);
    return () => clearInterval(id);
  }, []);

  const dotStr = ".".repeat(dots);

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center"
      style={{ background: "#e8e0d8" }}
    >
      {/* Phone frame */}
      <div
        className="relative flex flex-col overflow-hidden"
        style={{
          width: 390,
          height: 844,
          borderRadius: 48,
          boxShadow: "0 40px 80px rgba(0,0,0,0.35), 0 0 0 10px #1a1a1a, 0 0 0 12px #333",
          background: "#ffffff",
          fontFamily: "'DM Sans', sans-serif",
        }}
      >
        {/* Status bar */}
        <div
          className="flex items-center justify-between px-6 pt-3 pb-1 shrink-0"
          style={{ background: "#ffffff", zIndex: 50, position: "relative" }}
        >
          <span style={{ fontSize: 13, fontWeight: 600, color: colors.ink }}>9:41</span>
          <div
            style={{
              width: 120,
              height: 30,
              borderRadius: 20,
              background: "#1a1a1a",
              position: "absolute",
              left: "50%",
              transform: "translateX(-50%)",
              top: 10,
            }}
          />
          <div className="flex items-center gap-1">
            <MaterialIcon name="signal_cellular_alt" style={{ fontSize: 16, color: colors.ink }} />
            <MaterialIcon name="wifi" style={{ fontSize: 16, color: colors.ink }} />
            <MaterialIcon name="battery_5_bar" style={{ fontSize: 16, color: colors.ink }} />
          </div>
        </div>

        {/* Top nav */}
        <header
          className="shrink-0 flex items-center justify-between px-5 py-3 border-b"
          style={{
            background: "#ffffff",
            borderColor: colors.sage,
            boxShadow: "0 4px 20px -2px rgba(58,51,40,0.08)",
            zIndex: 40,
          }}
        >
          <span
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: 22,
              fontStyle: "italic",
              color: colors.forest,
              fontWeight: 400,
              lineHeight: 1,
            }}
          >
            Tofha<span style={{ color: colors.gold }}>.</span>
          </span>
          <div className="flex items-center gap-3">
            <MaterialIcon name="search" style={{ fontSize: 22, color: colors.ink, cursor: "pointer" }} />
            <MaterialIcon name="notifications" style={{ fontSize: 22, color: colors.ink, cursor: "pointer" }} />
            <MaterialIcon name="favorite" style={{ fontSize: 22, color: colors.ink, cursor: "pointer" }} />
            <MaterialIcon name="shopping_bag" style={{ fontSize: 22, color: colors.ink, cursor: "pointer" }} />
          </div>
        </header>

        {/* Main content */}
        <main
          className="flex-1 flex flex-col items-center justify-center relative overflow-hidden"
          style={{ background: "#ffffff", paddingBottom: 72 }}
        >
          {/* Atmospheric watermarks */}
          <div
            className="absolute pointer-events-none select-none"
            style={{ top: 24, left: 16, opacity: 0.07, transform: "rotate(-12deg)" }}
          >
            <div
              style={{
                width: 80,
                height: 24,
                borderRadius: 4,
                background: "linear-gradient(90deg, #d4c9b0, #e8dfc8)",
              }}
            />
          </div>
          <div
            className="absolute pointer-events-none select-none"
            style={{ bottom: 80, right: 16, opacity: 0.07 }}
          >
            <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
              <ellipse cx="40" cy="40" rx="18" ry="30" stroke="#8FAF82" strokeWidth="1.5" fill="none" />
              <line x1="40" y1="10" x2="40" y2="70" stroke="#8FAF82" strokeWidth="1" />
              <line x1="22" y1="30" x2="58" y2="30" stroke="#8FAF82" strokeWidth="0.8" />
              <line x1="22" y1="50" x2="58" y2="50" stroke="#8FAF82" strokeWidth="0.8" />
              <line x1="27" y1="20" x2="53" y2="20" stroke="#8FAF82" strokeWidth="0.6" />
              <line x1="24" y1="60" x2="56" y2="60" stroke="#8FAF82" strokeWidth="0.6" />
            </svg>
          </div>

          {/* Main card */}
          <div className="flex flex-col items-center text-center z-10 px-6" style={{ maxWidth: 340 }}>

            {/* Circular loader */}
            <div
              className="relative flex items-center justify-center"
              style={{ width: 96, height: 96 }}
            >
              {/* Outer glow */}
              <div
                style={{
                  position: "absolute",
                  inset: -24,
                  borderRadius: "50%",
                  background: "radial-gradient(circle, rgba(61,107,79,0.08) 0%, transparent 70%)",
                }}
              />
              <svg
                width="96"
                height="96"
                viewBox="0 0 96 96"
                style={{
                  transform: "rotate(-90deg)",
                  animation: "spin-slow 2s linear infinite",
                }}
              >
                <style>{`@keyframes spin-slow { from { transform: rotate(-90deg); } to { transform: rotate(270deg); } }`}</style>
                <circle
                  cx="48" cy="48" r="42"
                  fill="transparent"
                  stroke="#C5D6BC"
                  strokeWidth="6"
                />
                <circle
                  cx="48" cy="48" r="42"
                  fill="transparent"
                  stroke="#3D6B4F"
                  strokeWidth="6"
                  strokeDasharray="198"
                  strokeDashoffset="50"
                  strokeLinecap="round"
                />
              </svg>
            </div>

            {/* Status text */}
            <div style={{ marginTop: 32 }}>
              <h1
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: 22,
                  fontStyle: "italic",
                  color: colors.ink,
                  fontWeight: 400,
                  lineHeight: "30px",
                }}
              >
                Processing your payment
                <span style={{ display: "inline-block", width: 16, textAlign: "left" }}>{dotStr}</span>
              </h1>
              <p
                style={{
                  marginTop: 8,
                  fontSize: 13,
                  color: colors.muted,
                  lineHeight: "20px",
                  fontFamily: "'DM Sans', sans-serif",
                }}
              >
                Please do not press back or close the app.
              </p>
            </div>

            {/* Amount */}
            <div style={{ marginTop: 24 }}>
              <p
                style={{
                  fontFamily: "'Space Mono', monospace",
                  fontSize: 28,
                  color: colors.gold,
                  letterSpacing: "-0.02em",
                  fontWeight: 500,
                }}
              >
                ₹1,248
              </p>
              <p
                style={{
                  marginTop: 6,
                  fontFamily: "'Cinzel', serif",
                  fontSize: 10,
                  color: colors.mutedLight,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                  fontWeight: 700,
                }}
              >
                AMOUNT BEING PROCESSED
              </p>
            </div>

            {/* Gift sketch watermark */}
            <div style={{ marginTop: 32, opacity: 0.1 }}>
              <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
                <rect x="15" y="32" width="50" height="36" rx="2" stroke={colors.ink} strokeWidth="1.5" fill="none" />
                <rect x="15" y="22" width="50" height="12" rx="2" stroke={colors.ink} strokeWidth="1.5" fill="none" />
                <line x1="40" y1="22" x2="40" y2="68" stroke={colors.ink} strokeWidth="1.5" />
                <path d="M40 22 C40 22 30 16 25 20 C20 24 30 28 40 22Z" stroke={colors.ink} strokeWidth="1.2" fill="none" />
                <path d="M40 22 C40 22 50 16 55 20 C60 24 50 28 40 22Z" stroke={colors.ink} strokeWidth="1.2" fill="none" />
              </svg>
            </div>

            {/* Security badge */}
            <div className="flex items-center justify-center gap-2" style={{ marginTop: 24 }}>
              <MaterialIcon name="lock" filled style={{ fontSize: 15, color: colors.mutedLight }} />
              <span
                style={{
                  fontFamily: "'DM Sans', sans-serif",
                  fontSize: 11,
                  color: colors.mutedLight,
                  letterSpacing: "0.03em",
                }}
              >
                100% secure · Powered by Razorpay
              </span>
            </div>
          </div>
        </main>

        {/* Bottom nav */}
        <nav
          className="shrink-0 flex items-center justify-around border-t"
          style={{
            background: "#ffffff",
            borderColor: colors.outlineVariant,
            height: 72,
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            zIndex: 40,
          }}
        >
          {(
            [
              { id: "home", icon: "home", label: "Home" },
              { id: "category", icon: "category", label: "Category" },
              { id: "reels", icon: "play_circle", label: "Reels" },
              { id: "profile", icon: "person", label: "Profile" },
            ] as const
          ).map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="flex flex-col items-center gap-0.5"
                style={{ background: "none", border: "none", cursor: "pointer", padding: "8px 12px", borderRadius: 8 }}
              >
                <MaterialIcon
                  name={tab.icon}
                  filled={isActive}
                  style={{
                    fontSize: 22,
                    color: isActive ? colors.forest : colors.onSurfaceVariant,
                  }}
                />
                <span
                  style={{
                    fontSize: 10,
                    fontFamily: "'Cinzel', serif",
                    letterSpacing: "0.05em",
                    color: isActive ? colors.forest : colors.onSurfaceVariant,
                    fontWeight: isActive ? 700 : 400,
                  }}
                >
                  {tab.label}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
