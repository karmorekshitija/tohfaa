import { useState } from "react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";

const colors = {
  primary: "#255338",
  primaryContainer: "#3d6b4f",
  secondaryContainer: "#c8e9b8",
  tertiary: "#573b81",
  surface: "#fff8f3",
  surfaceContainer: "#f9ecdc",
  ivory: "#FCFAF5",
  onSurface: "#211b11",
  onSurfaceVariant: "#414942",
  outlineVariant: "#c1c9c0",
  outline: "#717972",
  gold: "#D4AF37",
};

function MaterialIcon({
  name,
  filled = false,
  style = {},
}: {
  name: string;
  filled?: boolean;
  style?: React.CSSProperties;
}) {
  return (
    <span
      className="material-symbols-outlined"
      style={{
        fontFamily: "'Material Symbols Outlined'",
        fontVariationSettings: filled ? "'FILL' 1, 'wght' 400" : "'FILL' 0, 'wght' 400",
        ...style,
      }}
    >
      {name}
    </span>
  );
}

const mascotUrl =
  "https://lh3.googleusercontent.com/aida-public/AB6AXuCDhrM4xk8-gCt9PzjnvroMgPcNJxQLe-5VZ5G1WJEt8jmTdgXy2JZVWNwwhZouBzxg1DmqPnIHbBq2gg4iSfnDK-5e6P8XT8VfYrOFPcAQWPQFeJ_Ky51X1MeJXARP-Q1PenUS57xADeDGBZEgFmj-dEF-6tUqZ8EcMV1gY8JHk7q1sWP94zkVu3J4hpaZILw6Mb8pVW-eXkYifB3VFMHm0uksomGwkh1p-SOu4dW6xKrIiCvb99piq7ZDfpA1IuqQor8jlcGVlo0";

const productImages = [
  "https://lh3.googleusercontent.com/aida-public/AB6AXuBdsDk9RXyoHDtnQgGLpf5RCs3uhzh4itxVYNo_9l5IhT1btAEWn8mBkD-94dK-ajYheukstMPrGrZQ6vv5xCtq4PuW8qTgc_Scc8VyjguLb2rj183K_TYjP_zYCA4wY3mRvY4Eu6nh1u316SaHDHEhSZUR96ap2hyzjSGgdr6YzthQKV8WN99JrqhfTM9dxoIVF54g2FKz1g43PG-1_ZFX100iiiHCFQ5PhjDqbQgr_fk0lMRGTFfpTHB0kFpZ95NZqtoVRalH-cM",
  "https://lh3.googleusercontent.com/aida-public/AB6AXuCBhBk54lj4pgF8bJJGN8ySUm9JjHoNRmIyi5MqlTRiBi55GBez_5HqTw2VNt9ypAt7FjtqgUtX64hdkT_31I4sgDTeKwDNmRwXXzruJUFBgIaGcV31625TBTYXQnahvcR5-eIVdPoOVvdKmq5aUfL1Nl47ACdZ4S_2zxfypQf8J0GEuL5pwtVC4aj6wf1ErOPoJwRhX6SAjgn4KGj897f20HtxBqTZ2_XvnM-bIL1BHJc_3t04RFzcxHtbpptT42PogmE10WNCRGQ",
  "https://lh3.googleusercontent.com/aida-public/AB6AXuBtZ1CsuFy_TLfifSZBX0nUnxQRlxdv4NN8d8B-AjKnYtybA0wqlN_4VCR1-JW5v7IJkbaVUh_9kGtoSwkoe0asschIvC2djslvSINh_eQLaCIFvWY0SHIUvaxS9r_PtH4MKqL8oqsd5kHElfgN6NUKCVUpulUHIier1VViI_ou3SoIPuXeC7eg2iKYrw2QYJzvmUK5NqcsFJ4HnwRyqz0-FIWTVuARtHVzZs7Y0Y_VsLRHv5AenjXnmIx1jwul3sHSVD-UJ8tzTGk",
];

export default function App() {
  const [activeTab, setActiveTab] = useState<"home" | "category" | "reels" | "profile">("home");
  const [tracking, setTracking] = useState(false);

  const handleTrack = () => {
    setTracking(true);
    setTimeout(() => setTracking(false), 1500);
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center"
      style={{ background: "#e8e0d8" }}
    >
      {/* Phone frame */}
      <div
        className="relative flex flex-col overflow-hidden"
        style={{
          width: 390,
          height: 844,
          borderRadius: 48,
          boxShadow: "0 40px 80px rgba(0,0,0,0.35), 0 0 0 10px #1a1a1a, 0 0 0 12px #333",
          background: "#ffffff",
          fontFamily: "'DM Sans', sans-serif",
        }}
      >
        {/* Confetti dot pattern */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            backgroundImage: `
              radial-gradient(circle at 10% 20%, rgba(73,102,63,0.07) 1px, transparent 1px),
              radial-gradient(circle at 90% 80%, rgba(87,59,129,0.07) 2px, transparent 2px),
              radial-gradient(circle at 50% 50%, rgba(186,26,26,0.05) 1px, transparent 1px)
            `,
            backgroundSize: "120px 120px",
            zIndex: 0,
          }}
        />

        {/* Status bar */}
        <div
          className="flex items-center justify-between px-6 pt-3 pb-1 shrink-0"
          style={{ background: "transparent", zIndex: 50, position: "relative" }}
        >
          <span style={{ fontSize: 13, fontWeight: 600, color: colors.onSurface }}>9:41</span>
          <div
            style={{
              width: 120,
              height: 30,
              borderRadius: 20,
              background: "#1a1a1a",
              position: "absolute",
              left: "50%",
              transform: "translateX(-50%)",
              top: 10,
            }}
          />
          <div className="flex items-center gap-1">
            <MaterialIcon name="signal_cellular_alt" style={{ fontSize: 16, color: colors.onSurface }} />
            <MaterialIcon name="wifi" style={{ fontSize: 16, color: colors.onSurface }} />
            <MaterialIcon name="battery_5_bar" style={{ fontSize: 16, color: colors.onSurface }} />
          </div>
        </div>

        {/* Top nav */}
        <header
          className="shrink-0 flex items-center justify-between px-5 py-3 border-b"
          style={{
            background: "rgba(255,248,243,0.85)",
            backdropFilter: "blur(8px)",
            borderColor: colors.outlineVariant,
            zIndex: 40,
            position: "relative",
          }}
        >
          <div className="flex items-center" style={{ gap: 2 }}>
            <span
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: 22,
                fontStyle: "italic",
                color: colors.primary,
                fontWeight: 400,
                lineHeight: 1,
              }}
            >
              Tohfa
            </span>
            <span
              style={{
                width: 6,
                height: 6,
                borderRadius: "50%",
                background: "#D4AF37",
                display: "inline-block",
                marginTop: 14,
                marginLeft: -3,
              }}
            />
          </div>
          <button style={{ background: "none", border: "none", cursor: "pointer" }}>
            <MaterialIcon name="shopping_bag" style={{ fontSize: 22, color: colors.onSurfaceVariant }} />
          </button>
        </header>

        {/* Main scrollable content */}
        <main
          className="flex-1 overflow-y-auto flex flex-col items-center"
          style={{ background: "transparent", paddingBottom: 80, position: "relative", zIndex: 10 }}
        >
          <div className="flex flex-col items-center w-full px-5 py-7 gap-4 text-center">

            {/* Success icon */}
            <div className="relative flex items-center justify-center" style={{ width: 80, height: 80 }}>
              <div
                style={{
                  position: "absolute",
                  inset: -16,
                  borderRadius: "50%",
                  background: "rgba(61,107,79,0.1)",
                  filter: "blur(12px)",
                }}
              />
              <div
                className="flex items-center justify-center relative z-10"
                style={{
                  width: 72,
                  height: 72,
                  borderRadius: "50%",
                  background: colors.secondaryContainer,
                }}
              >
                <MaterialIcon
                  name="check_circle"
                  filled
                  style={{ fontSize: 40, color: colors.primary }}
                />
              </div>
            </div>

            {/* Headline */}
            <div className="flex flex-col gap-1">
              <h1
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: 24,
                  fontStyle: "italic",
                  color: colors.primary,
                  fontWeight: 400,
                  lineHeight: "32px",
                }}
              >
                Order confirmed! ✦
              </h1>
              <p style={{ fontSize: 13, color: colors.onSurfaceVariant }}>
                Your payment of ₹1,248 was successful.
              </p>
              <p
                style={{
                  fontFamily: "'Space Mono', monospace",
                  fontSize: 10,
                  color: colors.outline,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  marginTop: 2,
                }}
              >
                ORDER #TH-20847 · PAID VIA GPAY
              </p>
            </div>

            {/* Card + mascot group */}
            <div className="relative w-full" style={{ paddingTop: 12 }}>
              {/* Mascot */}
              <div
                style={{
                  position: "absolute",
                  right: -8,
                  top: -40,
                  width: 88,
                  height: 88,
                  zIndex: 20,
                  pointerEvents: "none",
                }}
              >
                <ImageWithFallback
                  src={mascotUrl}
                  alt="Tohfa mascot holding a gift"
                  style={{ width: "100%", height: "100%", objectFit: "contain" }}
                />
              </div>

              {/* Summary card */}
              <div
                style={{
                  background: colors.ivory,
                  border: `1px solid ${colors.secondaryContainer}`,
                  borderRadius: 12,
                  padding: 16,
                  boxShadow: "0 8px 30px rgba(58,51,40,0.08)",
                  textAlign: "left",
                  position: "relative",
                  overflow: "hidden",
                }}
              >
                {/* Botanical watermark */}
                <div
                  className="absolute inset-0 flex items-center justify-center pointer-events-none"
                  style={{ opacity: 0.07 }}
                >
                  <MaterialIcon name="potted_plant" style={{ fontSize: 110, color: colors.onSurface }} />
                </div>

                <div style={{ position: "relative", zIndex: 10 }}>
                  <span
                    style={{
                      fontFamily: "'Cinzel', serif",
                      fontSize: 10,
                      color: colors.gold,
                      letterSpacing: "0.1em",
                      fontWeight: 700,
                      textTransform: "uppercase",
                      display: "block",
                      marginBottom: 12,
                    }}
                  >
                    ORDER SUMMARY
                  </span>

                  {/* Products row */}
                  <div className="flex items-center gap-3" style={{ marginBottom: 16 }}>
                    <div className="flex" style={{ gap: -12 }}>
                      {productImages.map((url, i) => (
                        <div
                          key={i}
                          style={{
                            marginLeft: i > 0 ? -10 : 0,
                            zIndex: productImages.length - i,
                            position: "relative",
                          }}
                        >
                          <ImageWithFallback
                            src={url}
                            alt={`Product ${i + 1}`}
                            style={{
                              width: 48,
                              height: 48,
                              borderRadius: 8,
                              objectFit: "cover",
                              border: `2px solid ${colors.ivory}`,
                              boxShadow: "0 1px 4px rgba(0,0,0,0.1)",
                              display: "block",
                            }}
                          />
                        </div>
                      ))}
                    </div>
                    <div className="flex flex-col gap-1">
                      <span style={{ fontSize: 13, color: colors.onSurface }}>3 items from 2 studios</span>
                      <span
                        style={{
                          fontFamily: "'Space Mono', monospace",
                          fontSize: 13,
                          color: colors.gold,
                          fontWeight: 500,
                        }}
                      >
                        ₹1,248 paid
                      </span>
                    </div>
                  </div>

                  {/* Delivery row */}
                  <div
                    className="flex items-center gap-2 pt-3"
                    style={{ borderTop: `1px solid rgba(193,201,192,0.3)` }}
                  >
                    <MaterialIcon name="local_shipping" style={{ fontSize: 15, color: colors.outline }} />
                    <span
                      style={{
                        fontFamily: "'Cinzel', serif",
                        fontSize: 10,
                        color: colors.outline,
                        letterSpacing: "0.08em",
                        textTransform: "uppercase",
                        fontWeight: 700,
                      }}
                    >
                      ESTIMATED DELIVERY: 5–7 DAYS
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col gap-3 w-full" style={{ marginTop: 4 }}>
              <button
                onClick={handleTrack}
                style={{
                  width: "100%",
                  height: 48,
                  background: colors.primary,
                  color: "#ffffff",
                  border: "none",
                  borderRadius: 12,
                  fontFamily: "'DM Sans', sans-serif",
                  fontSize: 15,
                  fontWeight: 700,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 8,
                  transition: "opacity 0.15s",
                  boxShadow: "0 2px 8px rgba(37,83,56,0.2)",
                }}
              >
                {tracking ? (
                  <>
                    <MaterialIcon
                      name="sync"
                      style={{
                        fontSize: 18,
                        color: "#fff",
                        animation: "spin 1s linear infinite",
                      }}
                    />
                    <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
                    Loading...
                  </>
                ) : (
                  "Track my order"
                )}
              </button>
              <a
                href="#"
                style={{
                  color: colors.tertiary,
                  fontFamily: "'DM Sans', sans-serif",
                  fontSize: 14,
                  textDecoration: "none",
                  textAlign: "center",
                }}
              >
                Continue shopping →
              </a>
            </div>
          </div>
        </main>

        {/* Bottom nav */}
        <nav
          className="flex items-center justify-around border-t"
          style={{
            background: colors.surface,
            borderColor: colors.outlineVariant,
            height: 72,
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            zIndex: 40,
          }}
        >
          {(
            [
              { id: "home", icon: "home", label: "Home" },
              { id: "category", icon: "category", label: "Category" },
              { id: "reels", icon: "play_circle", label: "Reels" },
              { id: "profile", icon: "person", label: "Profile" },
            ] as const
          ).map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="flex flex-col items-center gap-0.5"
                style={{ background: "none", border: "none", cursor: "pointer", padding: "8px 12px", borderRadius: 8 }}
              >
                <MaterialIcon
                  name={tab.icon}
                  filled={isActive}
                  style={{ fontSize: 22, color: isActive ? colors.primary : colors.onSurfaceVariant }}
                />
                <span
                  style={{
                    fontSize: 10,
                    fontFamily: "'Cinzel', serif",
                    letterSpacing: "0.05em",
                    color: isActive ? colors.primary : colors.onSurfaceVariant,
                    fontWeight: isActive ? 700 : 400,
                  }}
                >
                  {tab.label}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
