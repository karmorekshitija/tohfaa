import { useState, useEffect, useRef } from "react";
import { Heart, ShoppingCart, Bell, Search, Home, Grid3x3, Play, User, Star, ChevronLeft, ChevronRight, X, ArrowLeft, Users } from "lucide-react";

// ── Palette ───────────────────────────────────────────────────────────────────
const GREEN      = "#3D6B4F";
const GOLD       = "#C8973A";
const CREAM      = "#F7F3EC";
const SAGE       = "#8FAF82";
const PLUM       = "#7B5EA7";
const TERRACOTTA = "#C4784A";
const SAND       = "#E8DDD0";
const FOREST     = "#2D4A35";

// ── Mock Data ─────────────────────────────────────────────────────────────────
const SLIDES = [
  { id: 1, url: "https://images.unsplash.com/photo-1576016770956-debb63d900bb?w=800&auto=format&fit=crop&q=80", alt: "Ceramic Bowls" },
  { id: 2, url: "https://images.unsplash.com/photo-1544816155-12df9643f363?w=800&auto=format&fit=crop&q=80", alt: "Linen Journal" },
  { id: 3, url: "https://images.unsplash.com/photo-1602872030219-c16779798575?w=800&auto=format&fit=crop&q=80", alt: "Incense Holder" },
  { id: 4, url: "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=800&auto=format&fit=crop&q=80", alt: "Stoneware Vase" },
];

const PRODUCTS = [
  { id: 1, name: "Handcrafted Ceramic Bowl", seller: "Earth & Clay Studio", price: 1850, rating: 4.8, reviews: 124, image: "https://images.unsplash.com/photo-1576016770956-debb63d900bb?w=400&auto=format&fit=crop&q=80", badge: "BEST SELLER", badgeColor: "#C85A32" },
  { id: 2, name: "Handmade Linen Journal", seller: "The Paper Loom", price: 950, rating: 4.6, reviews: 89, image: "https://images.unsplash.com/photo-1544816155-12df9643f363?w=400&auto=format&fit=crop&q=80", badge: "CUSTOM", badgeColor: PLUM },
  { id: 3, name: "Brass Incense Holder", seller: "Aura Metals", price: 1200, rating: 4.9, reviews: 203, image: "https://images.unsplash.com/photo-1602872030219-c16779798575?w=400&auto=format&fit=crop&q=80", badge: null, badgeColor: "" },
  { id: 4, name: "Minimalist Stoneware Vase", seller: "Nordic Craft Co.", price: 2400, rating: 4.7, reviews: 67, image: "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=400&auto=format&fit=crop&q=80", badge: "BEST SELLER", badgeColor: "#C85A32" },
  { id: 5, name: "Woven Rattan Tray", seller: "Boho Living", price: 750, rating: 4.5, reviews: 45, image: "https://images.unsplash.com/photo-1612965607446-25e1332775ae?w=400&auto=format&fit=crop&q=80", badge: null, badgeColor: "" },
  { id: 6, name: "Hand-Poured Soy Candle", seller: "Glow & Bloom", price: 550, rating: 4.8, reviews: 312, image: "https://images.unsplash.com/photo-1602607144535-12d7abde5b64?w=400&auto=format&fit=crop&q=80", badge: "CUSTOM", badgeColor: PLUM },
];

const SPONSORED = [
  { id: 101, name: "Artisan Tea Set", seller: "Kintsugi House", price: 3200, rating: 4.9, reviews: 58, image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&auto=format&fit=crop&q=80", badge: "Sponsored", badgeColor: GOLD },
  { id: 102, name: "Macramé Wall Hanging", seller: "Knot & Thread", price: 1650, rating: 4.7, reviews: 91, image: "https://images.unsplash.com/photo-1516455207990-7a41ce80f7ee?w=400&auto=format&fit=crop&q=80", badge: "Sponsored", badgeColor: GOLD },
  { id: 103, name: "Hand-Dyed Silk Scarf", seller: "Saffron Textiles", price: 1900, rating: 4.6, reviews: 44, image: "https://images.unsplash.com/photo-1519923041107-8bb0baa4e4a3?w=400&auto=format&fit=crop&q=80", badge: "Sponsored", badgeColor: GOLD },
  { id: 104, name: "Carved Wooden Bowl", seller: "Forest & Form", price: 2800, rating: 4.8, reviews: 77, image: "https://images.unsplash.com/photo-1556909172-54557c7e4fb7?w=400&auto=format&fit=crop&q=80", badge: "Sponsored", badgeColor: GOLD },
];

const CATEGORIES = [
  { name: "Ceramics", products: PRODUCTS.slice(0, 4) },
  { name: "Stationery", products: [...PRODUCTS].reverse().slice(0, 4) },
  { name: "Home Decor", products: [...PRODUCTS].slice(2, 6) },
];

const ARTISANS = [
  {
    id: 1,
    name: "Meera Iyer",
    craft: "Ceramics",
    location: "Jaipur",
    followers: 1240,
    quote: "Each bowl I throw carries a conversation between clay and water. I never make the same piece twice.",
    avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=200&auto=format&fit=crop&q=80",
    products: [
      "https://images.unsplash.com/photo-1576016770956-debb63d900bb?w=120&auto=format&fit=crop&q=70",
      "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=120&auto=format&fit=crop&q=70",
      "https://images.unsplash.com/photo-1602872030219-c16779798575?w=120&auto=format&fit=crop&q=70",
      "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=120&auto=format&fit=crop&q=70",
    ],
    dark: true,
  },
  {
    id: 2,
    name: "Arjun Nair",
    craft: "Textiles",
    location: "Varanasi",
    followers: 890,
    quote: "A handwoven thread holds more stories than any machine could ever replicate.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
    products: [
      "https://images.unsplash.com/photo-1519923041107-8bb0baa4e4a3?w=120&auto=format&fit=crop&q=70",
      "https://images.unsplash.com/photo-1516455207990-7a41ce80f7ee?w=120&auto=format&fit=crop&q=70",
      "https://images.unsplash.com/photo-1544816155-12df9643f363?w=120&auto=format&fit=crop&q=70",
      "https://images.unsplash.com/photo-1612965607446-25e1332775ae?w=120&auto=format&fit=crop&q=70",
    ],
    dark: false,
  },
  {
    id: 3,
    name: "Priya Sharma",
    craft: "Stationery",
    location: "Pune",
    followers: 2100,
    quote: "Paper is patience. Every journal I make is an invitation to slow down and listen.",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&auto=format&fit=crop&q=80",
    products: [
      "https://images.unsplash.com/photo-1544816155-12df9643f363?w=120&auto=format&fit=crop&q=70",
      "https://images.unsplash.com/photo-1602607144535-12d7abde5b64?w=120&auto=format&fit=crop&q=70",
      "https://images.unsplash.com/photo-1556909172-54557c7e4fb7?w=120&auto=format&fit=crop&q=70",
      "https://images.unsplash.com/photo-1576016770956-debb63d900bb?w=120&auto=format&fit=crop&q=70",
    ],
    dark: true,
  },
];

// ── Shared components ─────────────────────────────────────────────────────────

function TopBar({
  onBack, title, cartCount, wishlistCount,
  onSearchOpen,
}: {
  onBack?: () => void;
  title?: string;
  cartCount: number;
  wishlistCount: number;
  onSearchOpen: () => void;
}) {
  return (
    <header
      className="flex items-center justify-between px-4 py-2 flex-shrink-0 border-b"
      style={{ backgroundColor: CREAM, borderColor: SAGE + "55" }}
    >
      {onBack ? (
        <button onClick={onBack} className="p-1.5 rounded-full active:scale-90 transition-transform" style={{ color: GREEN }}>
          <ArrowLeft size={20} />
        </button>
      ) : (
        <span className="text-2xl italic font-semibold select-none" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>
          Tohfa<span style={{ color: GOLD }}>.</span>
        </span>
      )}

      {title && (
        <span className="absolute left-1/2 -translate-x-1/2 text-sm font-semibold" style={{ color: GREEN, fontFamily: "'Playfair Display', serif" }}>
          {title}
        </span>
      )}

      <div className="flex items-center gap-0.5">
        <button onClick={onSearchOpen} className="p-2 rounded-full active:scale-90" style={{ color: GREEN }}>
          <Search size={18} />
        </button>
        <button className="p-2 rounded-full active:scale-90 relative" style={{ color: GREEN }}>
          <Heart size={18} fill={GREEN} />
          {wishlistCount > 0 && <Dot count={wishlistCount} />}
        </button>
        <button className="p-2 rounded-full active:scale-90 relative" style={{ color: GREEN }}>
          <ShoppingCart size={18} />
          {cartCount > 0 && <Dot count={cartCount} />}
        </button>
        <button className="p-2 rounded-full active:scale-90 relative" style={{ color: GREEN }}>
          <Bell size={18} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full" style={{ backgroundColor: GOLD }} />
        </button>
      </div>
    </header>
  );
}

function Dot({ count }: { count: number }) {
  return (
    <span
      className="absolute -top-0.5 -right-0.5 text-white rounded-full flex items-center justify-center font-bold"
      style={{ backgroundColor: GOLD, fontSize: 8, width: 14, height: 14 }}
    >
      {count}
    </span>
  );
}

function BottomNav({ active, onChange }: { active: string; onChange: (t: string) => void }) {
  const tabs = [
    { id: "home",     Icon: Home,    label: "Home" },
    { id: "category", Icon: Grid3x3, label: "Category" },
    { id: "reels",    Icon: Play,    label: "Reels" },
    { id: "profile",  Icon: User,    label: "Profile" },
  ];
  return (
    <nav
      className="absolute bottom-0 left-0 right-0 flex items-center justify-around py-2 border-t bg-white flex-shrink-0"
      style={{ borderColor: "#e5e7eb", paddingBottom: 20 }}
    >
      {tabs.map(({ id, Icon, label }) => {
        const on = active === id;
        return (
          <button key={id} onClick={() => onChange(id)} className="flex flex-col items-center gap-0.5 px-3 active:scale-90 transition-transform">
            <Icon size={22} stroke={on ? GREEN : "#9ca3af"} fill={on ? GREEN + "22" : "none"} strokeWidth={on ? 2 : 1.5} />
            <span className="text-[10px] font-medium" style={{ color: on ? GREEN : "#9ca3af" }}>{label}</span>
            {on && <div className="w-1 h-1 rounded-full" style={{ backgroundColor: GREEN }} />}
          </button>
        );
      })}
    </nav>
  );
}

function SearchOverlay({ onClose }: { onClose: () => void }) {
  const [q, setQ] = useState("");
  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-white">
      <div className="flex items-center gap-3 px-4 py-3 border-b" style={{ backgroundColor: CREAM, borderColor: SAGE + "55" }}>
        <button onClick={onClose} className="active:scale-90 transition-transform"><X size={20} color={GREEN} /></button>
        <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Search handcrafted goods…" className="flex-1 bg-transparent outline-none text-sm text-gray-800" style={{ fontFamily: "'DM Sans', sans-serif" }} />
      </div>
      <div className="flex-1 flex flex-col items-center justify-center gap-2 text-gray-400">
        <Search size={40} strokeWidth={1} />
        <p className="text-sm">Search for ceramics, textiles, stationery…</p>
      </div>
    </div>
  );
}

// ── Product Card ──────────────────────────────────────────────────────────────

function ProductCard({ product, compact = false }: { product: typeof PRODUCTS[0]; compact?: boolean }) {
  const [wishlisted, setWishlisted] = useState(false);
  const fmtPrice = `₹${product.price.toLocaleString("en-IN")}`;
  return (
    <div className={`bg-white rounded-xl border border-gray-200 shadow-sm active:scale-[0.98] transition-transform cursor-pointer flex flex-col ${compact ? "w-44 flex-shrink-0" : ""}`}>
      <div className="relative aspect-square overflow-hidden rounded-t-xl bg-[#F7F3EC]">
        {product.badge && (
          <span className="absolute top-2 left-2 text-white text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full z-10" style={{ backgroundColor: product.badgeColor }}>
            {product.badge}
          </span>
        )}
        <button onClick={e => { e.stopPropagation(); setWishlisted(!wishlisted); }} className="absolute top-2 right-2 w-7 h-7 bg-white/90 backdrop-blur rounded-full flex items-center justify-center shadow z-10 active:scale-90">
          <Heart size={14} fill={wishlisted ? "#ef4444" : "none"} stroke={wishlisted ? "#ef4444" : "#605e57"} strokeWidth={2} />
        </button>
        <img src={product.image} alt={product.name} className="w-full h-full object-cover" loading="lazy" />
      </div>
      <div className="p-2.5 flex flex-col gap-0.5 flex-1">
        <span className="font-bold text-sm leading-none" style={{ color: GOLD }}>{fmtPrice}</span>
        <h4 className="font-semibold text-[12px] leading-tight text-gray-900 line-clamp-1" style={{ fontFamily: "'Playfair Display', serif" }}>{product.name}</h4>
        <div className="flex items-center gap-0.5">
          <Star size={10} fill={GOLD} stroke="none" />
          <span className="text-[10px] font-semibold text-gray-800">{product.rating}</span>
          <span className="text-[10px] text-gray-500">({product.reviews})</span>
        </div>
        <span className="text-[10px] text-gray-500 truncate">By {product.seller}</span>
      </div>
      <div className="px-2.5 pb-2.5">
        <button onClick={e => e.stopPropagation()} className="w-full py-1.5 rounded-lg text-white text-xs font-semibold active:opacity-80" style={{ backgroundColor: GREEN }}>
          Add to Cart
        </button>
      </div>
    </div>
  );
}

// ── Home Screen ───────────────────────────────────────────────────────────────

function HomeScreen({ onOurStory }: { onOurStory: () => void }) {
  const [slideIndex, setSlideIndex] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const touchRef = useRef(0);

  useEffect(() => {
    timerRef.current = setInterval(() => setSlideIndex(c => (c + 1) % SLIDES.length), 4000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  const goTo = (idx: number) => setSlideIndex((idx + SLIDES.length) % SLIDES.length);

  return (
    <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
      {/* Hero Carousel */}
      <div
        className="relative w-full overflow-hidden select-none"
        style={{ aspectRatio: "4/3" }}
        onTouchStart={e => { touchRef.current = e.changedTouches[0].clientX; }}
        onTouchEnd={e => {
          const diff = touchRef.current - e.changedTouches[0].clientX;
          if (Math.abs(diff) > 40) goTo(slideIndex + (diff > 0 ? 1 : -1));
        }}
      >
        {SLIDES.map((s, i) => (
          <img key={s.id} src={s.url} alt={s.alt} className="absolute inset-0 w-full h-full object-cover transition-opacity duration-700" style={{ opacity: i === slideIndex ? 1 : 0 }} />
        ))}
        <button onClick={() => goTo(slideIndex - 1)} className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1 shadow active:scale-90"><ChevronLeft size={16} color={GREEN} /></button>
        <button onClick={() => goTo(slideIndex + 1)} className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1 shadow active:scale-90"><ChevronRight size={16} color={GREEN} /></button>
      </div>

      {/* Dots */}
      <div className="flex justify-center gap-1.5 py-2.5 bg-white">
        {SLIDES.map((_, i) => (
          <button key={i} onClick={() => goTo(i)} style={{ width: i === slideIndex ? 20 : 8, height: 8, borderRadius: 9999, backgroundColor: i === slideIndex ? GREEN : "#D1D5DB", padding: 0, minWidth: 0, minHeight: 0, transition: "all 0.3s" }} />
        ))}
      </div>

      {/* Hero text */}
      <div className="px-5 py-5 flex flex-col items-center text-center bg-white border-b" style={{ borderColor: "#e5e7eb" }}>
        <span className="text-[10px] tracking-widest font-bold uppercase mb-1.5" style={{ color: PLUM }}>Est. 2024 • Handmade with Love</span>
        <h2 className="text-xl font-medium leading-tight mb-2" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>
          Artisan crafts for a <em>slower, intentional</em> life.
        </h2>
        <p className="text-xs text-gray-500 leading-relaxed max-w-xs mb-4">Discover hand-carved ceramics, sustainable textiles, and handcrafted stationery from local artisans.</p>
        <div className="flex gap-2.5 w-full max-w-[240px]">
          <button className="flex-1 py-2.5 rounded-xl text-white text-xs font-semibold active:opacity-80" style={{ backgroundColor: GREEN }}>Explore</button>
          <button onClick={onOurStory} className="flex-1 py-2.5 rounded-xl text-xs font-semibold border active:bg-gray-50" style={{ color: GREEN, borderColor: "#74786f" }}>Our Story</button>
        </div>
      </div>

      {/* Sponsored */}
      <section className="px-4 pt-5 pb-2">
        <div className="rounded-2xl p-4" style={{ backgroundColor: CREAM }}>
          <div className="flex items-baseline gap-1.5 mb-1">
            <Star size={13} fill={GOLD} stroke="none" />
            <h3 className="font-semibold text-sm" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>Sponsored</h3>
          </div>
          <p className="text-[11px] text-gray-500 mb-3">Featured from our community</p>
          <div className="grid grid-cols-2 gap-3">
            {SPONSORED.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      </section>

      {/* For You */}
      <section className="px-4 pt-5 pb-2">
        <h3 className="font-semibold text-sm mb-0.5" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>For You</h3>
        <p className="text-[11px] text-gray-500 mb-3">Handpicked treasures just for you</p>
        <div className="grid grid-cols-2 gap-3">
          {PRODUCTS.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      {/* Category rows */}
      {CATEGORIES.map(cat => (
        <section key={cat.name} className="px-4 pt-5 pb-2">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>{cat.name}</h3>
            <button className="text-[11px] font-semibold flex items-center gap-0.5" style={{ color: GREEN }}>View All <ChevronRight size={12} /></button>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2" style={{ scrollbarWidth: "none" }}>
            {cat.products.map(p => <ProductCard key={p.id} product={p} compact />)}
          </div>
        </section>
      ))}

      {/* Mini footer */}
      <footer className="mx-4 my-5 rounded-2xl p-4 text-center" style={{ backgroundColor: CREAM }}>
        <p className="italic text-sm font-medium mb-1" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>Tohfa<span style={{ color: GOLD }}>.</span></p>
        <p className="text-[10px] text-gray-500 mb-3">Cultivating a community of makers and dreamers.</p>
        <input placeholder="Your email address" className="w-full text-xs px-3 py-2 rounded-lg border mb-2 outline-none" style={{ borderColor: "#c3c8c1", backgroundColor: "white" }} />
        <button className="w-full py-2 rounded-lg text-white text-[10px] font-bold uppercase tracking-widest" style={{ backgroundColor: GREEN }}>Subscribe</button>
        <p className="text-[9px] text-gray-400 mt-3">© 2024 Tohfa Artisan Studio. Handcrafted with intention.</p>
      </footer>
      <div className="h-20" />
    </div>
  );
}

// ── Artisan Card ──────────────────────────────────────────────────────────────

function ArtisanCard({ artisan }: { artisan: typeof ARTISANS[0] }) {
  const [followed, setFollowed] = useState(false);
  const [count, setCount] = useState(artisan.followers);

  return (
    <div className="rounded-2xl overflow-hidden shadow-md" style={{ backgroundColor: artisan.dark ? GREEN : CREAM }}>
      {/* Top image strip */}
      <div className="relative h-36 overflow-hidden">
        <img src={artisan.products[0]} alt="" className="w-full h-full object-cover opacity-60" />
        <div className="absolute inset-0" style={{ background: artisan.dark ? "linear-gradient(to bottom, transparent 30%, " + GREEN + ")" : "linear-gradient(to bottom, transparent 30%, " + CREAM + ")" }} />
        {/* Avatar */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-16 h-16 rounded-full overflow-hidden border-2 shadow-lg" style={{ borderColor: artisan.dark ? "#fff" : GREEN }}>
          <img src={artisan.avatar} alt={artisan.name} className="w-full h-full object-cover" />
        </div>
      </div>

      <div className="pt-10 pb-4 px-4 flex flex-col items-center text-center">
        {/* Tag */}
        <span className="text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full mb-2 text-white" style={{ backgroundColor: TERRACOTTA }}>
          {artisan.craft} · {artisan.location}
        </span>
        <h3 className="font-semibold text-base mb-2" style={{ fontFamily: "'Playfair Display', serif", color: artisan.dark ? "#fff" : FOREST }}>{artisan.name}</h3>

        {/* Quote */}
        <div className="relative mb-3 px-3">
          <span className="absolute -top-2 -left-1 text-3xl font-serif opacity-40" style={{ color: TERRACOTTA }}>"</span>
          <p className="text-[11px] leading-relaxed italic" style={{ color: artisan.dark ? "rgba(255,255,255,0.85)" : "#444840" }}>{artisan.quote}</p>
        </div>

        {/* Follow */}
        <button
          onClick={() => { setFollowed(!followed); setCount(c => c + (followed ? -1 : 1)); }}
          className="border rounded-full px-5 py-1.5 text-[10px] font-bold uppercase tracking-widest mb-4 transition-all active:scale-95"
          style={{
            borderColor: artisan.dark ? "rgba(255,255,255,0.6)" : GREEN,
            color: followed ? "#fff" : (artisan.dark ? "#fff" : GREEN),
            backgroundColor: followed ? (artisan.dark ? "rgba(255,255,255,0.2)" : GREEN) : "transparent",
          }}
        >
          {followed ? "Following" : "Follow"} ({count.toLocaleString()})
        </button>

        {/* Product thumbnails */}
        <div className="grid grid-cols-4 gap-1.5 w-full">
          {artisan.products.map((url, i) => (
            <div key={i} className="aspect-square rounded-lg overflow-hidden">
              <img src={url} alt="" className="w-full h-full object-cover" loading="lazy" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Our Story Screen ──────────────────────────────────────────────────────────

function OurStoryScreen({ onBack }: { onBack: () => void }) {
  const philosophyRef = useRef<HTMLDivElement>(null);

  const scrollToArtisans = () => {
    document.getElementById("artisans-mobile")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: "none" }}>

      {/* Philosophy Hero */}
      <section style={{ backgroundColor: CREAM, backgroundImage: "url('https://www.transparenttextures.com/patterns/linen.png')" }}>

        {/* Text block */}
        <div className="px-5 pt-8 pb-6" ref={philosophyRef}>
          <div className="border-l-4 pl-4 mb-5" style={{ borderColor: TERRACOTTA }}>
            <span className="text-[10px] font-bold uppercase tracking-[0.18em] block mb-2" style={{ color: FOREST }}>Our Philosophy</span>
            <h1 className="text-2xl font-semibold leading-tight mb-3" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>
              Every gift holds the hands that made it.
            </h1>
            <p className="text-sm italic leading-relaxed" style={{ color: "#444840" }}>
              "At Tohfa, every gift tells a story. We bring you hand-selected, sustainably crafted treasures made by real artisans — not factories."
            </p>
          </div>

          {/* Divider */}
          <div className="flex items-center gap-3 mb-5">
            <div className="flex-1 h-px" style={{ backgroundColor: FOREST + "33" }} />
            <span style={{ fontSize: 20 }}>🌿</span>
            <div className="flex-1 h-px" style={{ backgroundColor: FOREST + "33" }} />
          </div>

          {/* CTA buttons */}
          <div className="flex flex-col gap-2.5">
            <button className="w-full py-3 rounded-xl text-white text-sm font-bold uppercase tracking-widest active:opacity-80" style={{ backgroundColor: GREEN }}>
              Explore Collection
            </button>
            <button onClick={scrollToArtisans} className="w-full py-3 rounded-xl text-sm font-bold uppercase tracking-widest border active:bg-gray-50" style={{ color: GREEN, borderColor: GREEN }}>
              Meet Our Artisans
            </button>
          </div>
        </div>
      </section>

      {/* USP Pills */}
      <section className="px-4 py-5" style={{ backgroundColor: "#fff" }}>
        <div className="grid grid-cols-3 gap-3">
          {[
            { icon: "🌱", label: "Sustainably Sourced" },
            { icon: "🤲", label: "Handmade Always" },
            { icon: "❤️", label: "Artisan First" },
          ].map(({ icon, label }) => (
            <div key={label} className="flex flex-col items-center gap-1.5 py-4 px-2 rounded-2xl text-center" style={{ backgroundColor: CREAM }}>
              <span style={{ fontSize: 22 }}>{icon}</span>
              <span className="text-[10px] font-semibold leading-tight" style={{ color: FOREST }}>{label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Artisans section */}
      <section id="artisans-mobile" className="px-4 pt-5 pb-4" style={{ backgroundColor: SAND }}>
        <div className="text-center mb-6">
          <h2 className="text-xl font-semibold mb-1" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>Hands Behind Tohfa</h2>
          <div className="flex justify-center mb-1"><span style={{ fontSize: 18 }}>🌸</span></div>
          <p className="text-xs italic text-gray-500">Meet the makers who craft every piece with love.</p>
        </div>
        <div className="flex flex-col gap-5">
          {ARTISANS.map(a => <ArtisanCard key={a.id} artisan={a} />)}
        </div>
      </section>

      {/* Join Community */}
      <section className="relative overflow-hidden flex items-center justify-center" style={{ height: 300 }}>
        <img
          src="https://images.unsplash.com/photo-1604634071577-a1d6f0b0f2f5?w=800&auto=format&fit=crop&q=80"
          alt="Craftsman workshop"
          className="absolute inset-0 w-full h-full object-cover"
          style={{ transform: "scale(1.08)" }}
        />
        <div className="absolute inset-0" style={{ backgroundColor: GREEN + "99", backdropFilter: "blur(2px)" }} />
        <div className="relative z-10 px-6 flex flex-col items-center text-center gap-5">
          <h2 className="text-xl font-medium italic leading-snug text-white" style={{ fontFamily: "'Playfair Display', serif" }}>
            'Craftsmanship is not a transaction. It's a relationship.'
          </h2>
          <button className="border-2 border-white text-white px-7 py-2.5 text-[11px] font-bold uppercase tracking-widest rounded-lg active:bg-white/20 transition-all">
            Join the Tohfa Community
          </button>
        </div>
      </section>

      {/* Mini footer */}
      <footer className="mx-4 mb-5 rounded-2xl p-4 text-center" style={{ backgroundColor: CREAM }}>
        <p className="italic text-sm font-medium mb-1" style={{ fontFamily: "'Playfair Display', serif", color: GREEN }}>Tohfa<span style={{ color: GOLD }}>.</span></p>
        <p className="text-[10px] text-gray-500 mb-3">Subscribe for artisan stories and exclusive collections.</p>
        <input placeholder="Your email address" className="w-full text-xs px-3 py-2 rounded-lg border mb-2 outline-none" style={{ borderColor: "#c3c8c1", backgroundColor: "white" }} />
        <button className="w-full py-2 rounded-lg text-white text-[10px] font-bold uppercase tracking-widest" style={{ backgroundColor: GREEN }}>Subscribe</button>
        <div className="flex justify-center gap-4 mt-3">
          {["Privacy Policy", "Terms", "Sustainability"].map(l => (
            <button key={l} className="text-[9px] text-gray-400">{l}</button>
          ))}
        </div>
        <p className="text-[9px] text-gray-400 mt-2">© 2024 Tohfa Artisan Studio.</p>
      </footer>
      <div className="h-20" />
    </div>
  );
}

// ── Placeholder screens ───────────────────────────────────────────────────────

function PlaceholderScreen({ icon, label }: { icon: string; label: string }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center gap-3 text-gray-400" style={{ backgroundColor: CREAM }}>
      <span style={{ fontSize: 52 }}>{icon}</span>
      <p className="text-base font-medium" style={{ color: GREEN, fontFamily: "'Playfair Display', serif" }}>{label}</p>
      <p className="text-xs text-gray-500">Coming soon…</p>
    </div>
  );
}

// ── Root App ──────────────────────────────────────────────────────────────────

export default function App() {
  const [tab, setTab] = useState("home");
  const [screen, setScreen] = useState("home"); // "home" | "our-story"
  const [searchOpen, setSearchOpen] = useState(false);

  const cartCount = 2;
  const wishlistCount = 5;

  const handleTabChange = (t: string) => {
    setTab(t);
    setScreen(t === "home" ? "home" : t);
  };

  const topBarTitle = screen === "our-story" ? "Our Story" : undefined;

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: "#d6cfc5", fontFamily: "'DM Sans', sans-serif" }}>
      {/* Phone shell */}
      <div
        className="relative flex flex-col overflow-hidden"
        style={{
          width: 390,
          height: 844,
          borderRadius: 44,
          backgroundColor: "#fff",
          border: "10px solid #1a1a1a",
          boxShadow: "0 0 0 2px #333, 0 50px 100px rgba(0,0,0,0.5)",
        }}
      >
        {/* Status bar */}
        <div className="flex items-center justify-between px-6 pt-3 pb-1 flex-shrink-0 relative" style={{ backgroundColor: CREAM }}>
          <span className="text-[11px] font-semibold text-gray-700">9:41</span>
          <div style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", top: 10, width: 90, height: 24, backgroundColor: "#111", borderRadius: 9999 }} />
          <div className="flex items-center gap-1.5">
            <div className="flex gap-0.5 items-end">{[3, 4, 5, 6].map(h => <div key={h} className="w-0.5 bg-gray-700 rounded-sm" style={{ height: h }} />)}</div>
            <span className="text-[11px] font-semibold text-gray-700">100%</span>
          </div>
        </div>

        {/* Top nav bar */}
        <TopBar
          onBack={screen === "our-story" ? () => { setScreen("home"); setTab("home"); } : undefined}
          title={topBarTitle}
          cartCount={cartCount}
          wishlistCount={wishlistCount}
          onSearchOpen={() => setSearchOpen(true)}
        />

        {/* Screen content */}
        {screen === "home" && <HomeScreen onOurStory={() => setScreen("our-story")} />}
        {screen === "our-story" && <OurStoryScreen onBack={() => { setScreen("home"); setTab("home"); }} />}
        {screen === "category" && <PlaceholderScreen icon="🗂️" label="Browse Categories" />}
        {screen === "reels" && <PlaceholderScreen icon="🎬" label="Artisan Reels" />}
        {screen === "profile" && <PlaceholderScreen icon="👤" label="Your Profile" />}

        {/* Bottom nav */}
        <BottomNav active={tab} onChange={handleTabChange} />

        {/* Search overlay */}
        {searchOpen && <SearchOverlay onClose={() => setSearchOpen(false)} />}
      </div>
    </div>
  );
}
