import { useState } from "react";
import { Search, ShoppingBag, Home, Briefcase, MoreHorizontal, X, MapPin, Save } from "lucide-react";
import * as Switch from "@radix-ui/react-switch";

const PALETTE = {
  bg: "#f0e6d8",
  green: "#2c5530",
  greenLight: "#a8c5a0",
  white: "#ffffff",
  inputBorder: "#e0d8cf",
  inputFocusBorder: "#6366f1",
  textMuted: "#7a6f65",
  textDark: "#2a2118",
  cardBorder: "#e8ddd3",
};

type AddressType = "Home" | "Work" | "Other";

export default function App() {
  const [sheetOpen, setSheetOpen] = useState(true);
  const [addressType, setAddressType] = useState<AddressType>("Home");
  const [isDefault, setIsDefault] = useState(true);
  const [fullName, setFullName] = useState("Amara Khan");
  const [phone, setPhone] = useState("+1 (555) 000-0000");
  const [street, setStreet] = useState("Building, Street, Area");
  const [city, setCity] = useState("London");
  const [postal, setPostal] = useState("E1 6AN");
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const addressTypes: { label: AddressType; icon: React.ReactNode }[] = [
    { label: "Home", icon: <Home size={14} /> },
    { label: "Work", icon: <Briefcase size={14} /> },
    { label: "Other", icon: <MoreHorizontal size={14} /> },
  ];

  return (
    <div
      className="size-full flex items-center justify-center"
      style={{ background: "#e8ddd3" }}
    >
      {/* Phone frame */}
      <div
        className="relative flex flex-col overflow-hidden"
        style={{
          width: 390,
          height: 844,
          borderRadius: 50,
          background: PALETTE.bg,
          boxShadow: "0 40px 100px rgba(0,0,0,0.35), 0 0 0 10px #1a1a1a, 0 0 0 12px #333",
        }}
      >
        {/* Status bar */}
        <div className="flex items-center justify-between px-8 pt-4 pb-1 shrink-0" style={{ paddingTop: 16 }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: PALETTE.textDark }}>9:41</span>
          <div
            style={{
              width: 120,
              height: 30,
              background: "#1a1a1a",
              borderRadius: 20,
              position: "absolute",
              left: "50%",
              transform: "translateX(-50%)",
              top: 10,
            }}
          />
          <div className="flex gap-1 items-center">
            <svg width="16" height="12" viewBox="0 0 16 12" fill={PALETTE.textDark}><rect x="0" y="4" width="3" height="8" rx="1"/><rect x="4.5" y="2.5" width="3" height="9.5" rx="1"/><rect x="9" y="1" width="3" height="11" rx="1"/><rect x="13.5" y="0" width="2.5" height="12" rx="1" opacity="0.3"/></svg>
            <svg width="16" height="12" viewBox="0 0 16 12" fill="none" stroke={PALETTE.textDark} strokeWidth="1.5"><path d="M8 2.5C10.5 2.5 12.8 3.7 14.2 5.5"/><path d="M1.8 5.5C3.2 3.7 5.5 2.5 8 2.5"/><path d="M5.5 8C6.3 7.1 7.1 6.5 8 6.5C8.9 6.5 9.7 7.1 10.5 8"/><circle cx="8" cy="10.5" r="1" fill={PALETTE.textDark}/></svg>
            <svg width="24" height="12" viewBox="0 0 24 12" fill="none"><rect x="0.5" y="0.5" width="20" height="11" rx="3.5" stroke={PALETTE.textDark} strokeOpacity="0.35"/><rect x="2" y="2" width="16" height="8" rx="2" fill={PALETTE.textDark}/><path d="M22 4.5V7.5C22.8 7.2 23.5 6.7 23.5 6C23.5 5.3 22.8 4.8 22 4.5Z" fill={PALETTE.textDark} fillOpacity="0.4"/></svg>
          </div>
        </div>

        {/* App header */}
        <div className="flex items-center justify-between px-5 py-3 shrink-0">
          <span style={{ fontFamily: "'Georgia', serif", fontStyle: "italic", fontSize: 26, color: PALETTE.green, fontWeight: 400 }}>
            Tohfa.
          </span>
          <div className="flex gap-3 items-center">
            <button className="p-1.5 rounded-full hover:bg-black/5 transition-colors">
              <Search size={20} color={PALETTE.green} />
            </button>
            <button className="p-1.5 rounded-full hover:bg-black/5 transition-colors">
              <ShoppingBag size={20} color={PALETTE.green} />
            </button>
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 overflow-hidden px-4 pb-4">
          <h2 style={{ color: PALETTE.textDark, marginBottom: 16, paddingLeft: 4 }}>Saved Addresses</h2>

          {/* Address cards */}
          <div className="flex flex-col gap-3">
            {[
              { icon: <Home size={18} />, label: "Home", addr: "123 Artisan Lane, Craft Village, 3020" },
              { icon: <Briefcase size={18} />, label: "Work", addr: "456 Studio Road, Design District, 8071" },
            ].map(({ icon, label, addr }) => (
              <div
                key={label}
                className="flex items-center gap-4 px-4 py-4 rounded-2xl"
                style={{
                  background: PALETTE.white,
                  border: `1px solid ${PALETTE.cardBorder}`,
                  boxShadow: "0 1px 4px rgba(0,0,0,0.05)",
                }}
              >
                <div
                  className="flex items-center justify-center rounded-full shrink-0"
                  style={{ width: 38, height: 38, background: PALETTE.bg, color: PALETTE.textMuted }}
                >
                  {icon}
                </div>
                <div>
                  <div style={{ color: PALETTE.textDark, fontWeight: 500, fontSize: 15 }}>{label}</div>
                  <div style={{ color: PALETTE.textMuted, fontSize: 13, marginTop: 1 }}>{addr}</div>
                </div>
              </div>
            ))}
          </div>

          <button
            className="w-full mt-4 py-3.5 rounded-2xl flex items-center justify-center gap-2 transition-opacity active:opacity-70"
            style={{ background: PALETTE.green, color: PALETTE.white }}
            onClick={() => setSheetOpen(true)}
          >
            <MapPin size={16} />
            <span style={{ fontSize: 15, fontWeight: 500 }}>Add New Address</span>
          </button>
        </div>

        {/* Bottom sheet overlay */}
        {sheetOpen && (
          <div
            className="absolute inset-0 flex flex-col justify-end"
            style={{ background: "rgba(0,0,0,0.35)" }}
            onClick={(e) => { if (e.target === e.currentTarget) setSheetOpen(false); }}
          >
            <div
              className="flex flex-col"
              style={{
                background: PALETTE.white,
                borderRadius: "28px 28px 0 0",
                maxHeight: "90%",
                overflow: "hidden",
              }}
            >
              {/* Drag handle */}
              <div className="flex justify-center pt-3 pb-1 shrink-0">
                <div style={{ width: 36, height: 4, borderRadius: 2, background: "#d1c9c0" }} />
              </div>

              {/* Sheet header */}
              <div className="flex items-center justify-between px-5 pt-2 pb-4 shrink-0">
                <span style={{ fontFamily: "'Georgia', serif", fontStyle: "italic", fontSize: 22, color: PALETTE.green }}>
                  Add New Address
                </span>
                <button
                  onClick={() => setSheetOpen(false)}
                  className="p-1.5 rounded-full hover:bg-black/5 transition-colors"
                >
                  <X size={20} color={PALETTE.textMuted} />
                </button>
              </div>

              {/* Scrollable form content */}
              <div className="overflow-y-auto px-5 pb-6 flex flex-col gap-5" style={{ scrollbarWidth: "none" }}>
                {/* Address type */}
                <div>
                  <label style={{ fontSize: 11, letterSpacing: "0.08em", color: PALETTE.textMuted, fontWeight: 600, textTransform: "uppercase" }}>
                    Address Type
                  </label>
                  <div className="flex gap-2 mt-2">
                    {addressTypes.map(({ label, icon }) => (
                      <button
                        key={label}
                        onClick={() => setAddressType(label)}
                        className="flex items-center gap-1.5 px-4 py-2 rounded-full transition-all"
                        style={{
                          background: addressType === label ? PALETTE.green : "transparent",
                          color: addressType === label ? PALETTE.white : PALETTE.textDark,
                          border: `1.5px solid ${addressType === label ? PALETTE.green : PALETTE.inputBorder}`,
                          fontSize: 14,
                        }}
                      >
                        {icon}
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Full Name */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label style={{ fontSize: 11, letterSpacing: "0.08em", color: PALETTE.textMuted, fontWeight: 600, textTransform: "uppercase" }}>
                      Full Name
                    </label>
                    <span style={{ fontSize: 10, letterSpacing: "0.06em", color: PALETTE.textMuted, fontWeight: 600, textTransform: "uppercase" }}>
                      Required
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      onFocus={() => setFocusedField("name")}
                      onBlur={() => setFocusedField(null)}
                      className="w-full px-4 py-3 rounded-xl outline-none transition-all"
                      style={{
                        border: `1.5px solid ${focusedField === "name" ? PALETTE.inputFocusBorder : PALETTE.inputBorder}`,
                        fontSize: 15,
                        color: PALETTE.textDark,
                        background: PALETTE.white,
                      }}
                    />
                    {focusedField === "name" && (
                      <div
                        className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full"
                        style={{ width: 8, height: 8, background: PALETTE.inputFocusBorder }}
                      />
                    )}
                  </div>
                </div>

                {/* Phone Number */}
                <div>
                  <label style={{ fontSize: 11, letterSpacing: "0.08em", color: PALETTE.textMuted, fontWeight: 600, textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                    Phone Number
                  </label>
                  <input
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    onFocus={() => setFocusedField("phone")}
                    onBlur={() => setFocusedField(null)}
                    className="w-full px-4 py-3 rounded-xl outline-none transition-all"
                    style={{
                      border: `1.5px solid ${focusedField === "phone" ? PALETTE.inputFocusBorder : PALETTE.inputBorder}`,
                      fontSize: 15,
                      color: PALETTE.textMuted,
                      background: PALETTE.white,
                    }}
                  />
                </div>

                {/* Street Address */}
                <div>
                  <label style={{ fontSize: 11, letterSpacing: "0.08em", color: PALETTE.textMuted, fontWeight: 600, textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                    Street Address
                  </label>
                  <textarea
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                    onFocus={() => setFocusedField("street")}
                    onBlur={() => setFocusedField(null)}
                    rows={3}
                    className="w-full px-4 py-3 rounded-xl outline-none transition-all resize-none"
                    style={{
                      border: `1.5px solid ${focusedField === "street" ? PALETTE.inputFocusBorder : PALETTE.inputBorder}`,
                      fontSize: 15,
                      color: PALETTE.textMuted,
                      background: PALETTE.white,
                    }}
                  />
                </div>

                {/* City + Postal */}
                <div className="flex gap-3">
                  <div className="flex-1">
                    <label style={{ fontSize: 11, letterSpacing: "0.08em", color: PALETTE.textMuted, fontWeight: 600, textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                      City
                    </label>
                    <input
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      onFocus={() => setFocusedField("city")}
                      onBlur={() => setFocusedField(null)}
                      className="w-full px-4 py-3 rounded-xl outline-none transition-all"
                      style={{
                        border: `1.5px solid ${focusedField === "city" ? PALETTE.inputFocusBorder : PALETTE.inputBorder}`,
                        fontSize: 15,
                        color: PALETTE.textDark,
                        background: PALETTE.white,
                      }}
                    />
                  </div>
                  <div className="flex-1">
                    <label style={{ fontSize: 11, letterSpacing: "0.08em", color: PALETTE.textMuted, fontWeight: 600, textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                      Postal Code
                    </label>
                    <input
                      value={postal}
                      onChange={(e) => setPostal(e.target.value)}
                      onFocus={() => setFocusedField("postal")}
                      onBlur={() => setFocusedField(null)}
                      className="w-full px-4 py-3 rounded-xl outline-none transition-all"
                      style={{
                        border: `1.5px solid ${focusedField === "postal" ? PALETTE.inputFocusBorder : PALETTE.inputBorder}`,
                        fontSize: 15,
                        color: PALETTE.textDark,
                        background: PALETTE.white,
                      }}
                    />
                  </div>
                </div>

                {/* Default address toggle */}
                <div className="flex items-center justify-between py-1">
                  <div>
                    <div style={{ fontSize: 15, color: PALETTE.textDark, fontWeight: 500 }}>Set as default address</div>
                    <div style={{ fontSize: 13, color: PALETTE.textMuted, marginTop: 2 }}>This will be used for your future orders.</div>
                  </div>
                  <Switch.Root
                    checked={isDefault}
                    onCheckedChange={setIsDefault}
                    className="relative inline-flex items-center rounded-full cursor-pointer transition-colors shrink-0"
                    style={{
                      width: 50,
                      height: 28,
                      background: isDefault ? PALETTE.greenLight : "#d1c9c0",
                      border: "none",
                      outline: "none",
                    }}
                  >
                    <Switch.Thumb
                      className="block rounded-full shadow-sm transition-transform"
                      style={{
                        width: 22,
                        height: 22,
                        background: isDefault ? PALETTE.green : PALETTE.white,
                        transform: isDefault ? "translateX(24px)" : "translateX(3px)",
                      }}
                    />
                  </Switch.Root>
                </div>

                {/* Save button */}
                <button
                  className="w-full py-4 rounded-2xl flex items-center justify-center gap-2 transition-opacity active:opacity-80 mt-1"
                  style={{ background: PALETTE.green, color: PALETTE.white }}
                >
                  <Save size={17} />
                  <span style={{ fontSize: 16, fontWeight: 500 }}>Save Address</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
