import { useState } from "react";

const C = {
  primary: "#255338",
  primaryContainer: "#3d6b4f",
  onPrimary: "#ffffff",
  surface: "#fff8f3",
  ivory: "#FCFAF5",
  sage: "#8FAF82",
  gold: "#C8973A",
  violet: "#7B5EA7",
  terracotta: "#B14B3E",
  onSurface: "#211b11",
  onSurfaceVariant: "#414942",
  outlineVariant: "#c1c9c0",
  secondary: "#49663f",
  secondaryContainer: "#c8e9b8",
  surfaceContainerLow: "#fff2e1",
  background: "#ffffff",
};

const addresses = [
  {
    id: 1,
    type: "HOME",
    isDefault: true,
    title: "Residence",
    lines: ["42, Lotus Apartments,", "Jayanagar, Bengaluru,", "KA 560041"],
    phone: "+91 98450 12345",
  },
  {
    id: 2,
    type: "WORK",
    isDefault: false,
    title: "The Creative Studio",
    lines: ["1209 East 6th St,", "Studio 4, Austin, TX"],
    phone: "+1 512-555-0198",
  },
  {
    id: 3,
    type: "OTHER",
    isDefault: false,
    title: "Mountain Retreat",
    lines: ["Oak Ridge Cabin #12,", "Shimla, Himachal Pradesh"],
    phone: "+91 88765 43210",
  },
];

function PhoneIcon({ name, size = 20, color = C.primary }: { name: string; size?: number; color?: string }) {
  return (
    <span
      className="material-symbols-outlined select-none"
      style={{ fontSize: size, color, lineHeight: 1, verticalAlign: "middle" }}
    >
      {name}
    </span>
  );
}

function DeleteModal({ onClose, onConfirm }: { onClose: () => void; onConfirm: () => void }) {
  return (
    <div
      className="absolute inset-0 z-50 flex items-center justify-center px-6"
      style={{ background: "rgba(33,27,17,0.45)", backdropFilter: "blur(2px)" }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        className="w-full max-w-[280px] rounded-2xl p-6 text-center"
        style={{ background: C.ivory, border: `1px solid ${C.sage}`, boxShadow: "0 16px 48px rgba(33,27,17,0.18)" }}
      >
        <PhoneIcon name="warning" size={36} color={C.terracotta} />
        <h4 style={{ fontFamily: "'Lora', serif", fontSize: 17, fontWeight: 700, color: C.onSurface, margin: "10px 0 6px" }}>
          Remove address?
        </h4>
        <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: C.onSurfaceVariant, lineHeight: 1.5, marginBottom: 18 }}>
          This action will permanently delete this address from your studio journal.
        </p>
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-2 rounded-full transition-all active:scale-95"
            style={{ border: `1px solid ${C.outlineVariant}`, fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 700, color: C.onSurface, background: "transparent" }}
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 py-2 rounded-full transition-all active:scale-95"
            style={{ background: C.terracotta, color: "#fff", fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 700, border: "none", boxShadow: "0 2px 8px rgba(177,75,62,0.3)" }}
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

function AddressCard({
  addr,
  onDelete,
  onSetDefault,
}: {
  addr: typeof addresses[0];
  onDelete: (id: number) => void;
  onSetDefault: (id: number) => void;
}) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="rounded-xl p-4 transition-all duration-300"
      style={{
        background: C.ivory,
        border: `1px solid ${hovered ? C.gold : C.sage}`,
        boxShadow: "0 8px 24px -4px rgba(58,51,40,0.12)",
        transform: hovered ? "translateY(-2px)" : "translateY(0)",
      }}
    >
      {/* Badges */}
      <div className="flex gap-2 mb-3">
        <span
          className="px-3 py-0.5 rounded-full"
          style={{
            fontFamily: "'Cinzel', serif",
            fontSize: 10,
            fontWeight: 700,
            letterSpacing: "0.1em",
            color: C.gold,
            background: "rgba(200,151,58,0.1)",
            border: "1px solid rgba(200,151,58,0.3)",
          }}
        >
          {addr.type}
        </span>
        {addr.isDefault && (
          <span
            className="px-3 py-0.5 rounded-full"
            style={{
              fontFamily: "'Cinzel', serif",
              fontSize: 10,
              fontWeight: 700,
              letterSpacing: "0.1em",
              color: C.secondary,
              background: "rgba(73,102,63,0.1)",
              border: "1px solid rgba(73,102,63,0.3)",
            }}
          >
            DEFAULT
          </span>
        )}
      </div>

      {/* Title */}
      <h3 style={{ fontFamily: "'Lora', serif", fontSize: 16, fontWeight: 700, color: C.onSurface, marginBottom: 4 }}>
        {addr.title}
      </h3>

      {/* Address lines */}
      <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 14, color: C.onSurfaceVariant, lineHeight: 1.6, marginBottom: 8 }}>
        {addr.lines.map((l, i) => (
          <span key={i}>{l}{i < addr.lines.length - 1 && <br />}</span>
        ))}
      </p>

      {/* Phone */}
      <div className="flex items-center gap-1.5 mb-4">
        <PhoneIcon name="call" size={14} color={C.onSurfaceVariant} />
        <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 12, color: C.onSurface }}>
          {addr.phone}
        </span>
      </div>

      {/* Actions */}
      <div className="flex gap-4 pt-3" style={{ borderTop: `1px solid ${C.outlineVariant}` }}>
        {!addr.isDefault && (
          <button
            onClick={() => onSetDefault(addr.id)}
            className="hover:underline transition-all active:scale-95"
            style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 700, color: C.secondary }}
          >
            Set as default
          </button>
        )}
        <button
          className="flex items-center gap-1 hover:underline transition-all active:scale-95"
          style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 700, color: C.violet }}
        >
          <PhoneIcon name="edit" size={14} color={C.violet} /> Edit
        </button>
        <button
          onClick={() => onDelete(addr.id)}
          className="flex items-center gap-1 hover:underline transition-all active:scale-95"
          style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 700, color: C.terracotta }}
        >
          <PhoneIcon name="delete" size={14} color={C.terracotta} /> Delete
        </button>
      </div>
    </div>
  );
}

export default function App() {
  const [cards, setCards] = useState(addresses);
  const [deleteTarget, setDeleteTarget] = useState<number | null>(null);

  const handleSetDefault = (id: number) => {
    setCards((prev) => prev.map((a) => ({ ...a, isDefault: a.id === id })));
  };

  const handleDelete = (id: number) => {
    setCards((prev) => prev.filter((a) => a.id !== id));
    setDeleteTarget(null);
  };

  return (
    <div
      className="size-full flex items-center justify-center"
      style={{ background: "#d8cfc4" }}
    >
      {/* Phone frame */}
      <div
        className="relative flex flex-col overflow-hidden"
        style={{
          width: 390,
          height: 844,
          borderRadius: 50,
          boxShadow: "0 40px 100px rgba(0,0,0,0.38), 0 0 0 10px #1a1a1a, 0 0 0 12px #2e2e2e",
          background: C.surface,
          backgroundImage: "url('https://www.transparenttextures.com/patterns/natural-paper.png')",
        }}
      >
        {/* Status bar */}
        <div className="flex items-center justify-between px-8 shrink-0" style={{ paddingTop: 18, paddingBottom: 6 }}>
          <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 600, color: C.onSurface }}>9:41</span>
          <div
            style={{
              width: 120, height: 30, background: "#1a1a1a",
              borderRadius: 20, position: "absolute",
              left: "50%", transform: "translateX(-50%)", top: 10,
            }}
          />
          <div className="flex gap-1.5 items-center">
            {/* Signal */}
            <svg width="16" height="11" viewBox="0 0 16 11" fill={C.onSurface}>
              <rect x="0" y="5" width="2.5" height="6" rx="0.5"/>
              <rect x="4" y="3" width="2.5" height="8" rx="0.5"/>
              <rect x="8" y="1" width="2.5" height="10" rx="0.5"/>
              <rect x="12" y="0" width="2.5" height="11" rx="0.5" opacity="0.25"/>
            </svg>
            {/* Wifi */}
            <svg width="15" height="11" viewBox="0 0 15 11" fill="none" stroke={C.onSurface} strokeWidth="1.5" strokeLinecap="round">
              <path d="M7.5 8.5L7.5 8.5" strokeWidth="2"/>
              <path d="M5 6.5C5.8 5.6 6.6 5 7.5 5C8.4 5 9.2 5.6 10 6.5"/>
              <path d="M2.5 4C4 2.4 5.7 1.5 7.5 1.5C9.3 1.5 11 2.4 12.5 4"/>
              <path d="M0 1.5C2 -0.2 4.6-1 7.5 1C10.4-1 13 -0.2 15 1.5" opacity="0.4"/>
            </svg>
            {/* Battery */}
            <svg width="25" height="12" viewBox="0 0 25 12" fill="none">
              <rect x="0.5" y="0.5" width="21" height="11" rx="3.5" stroke={C.onSurface} strokeOpacity="0.35"/>
              <rect x="2" y="2" width="17" height="8" rx="2" fill={C.onSurface}/>
              <path d="M23 4V8C23.8 7.7 24.5 7.1 24.5 6C24.5 4.9 23.8 4.3 23 4Z" fill={C.onSurface} fillOpacity="0.4"/>
            </svg>
          </div>
        </div>

        {/* Top nav */}
        <nav
          className="flex items-center justify-between px-5 py-3 shrink-0"
          style={{ background: C.surface, borderBottom: `1px solid ${C.outlineVariant}` }}
        >
          <span style={{ fontFamily: "'Playfair Display', serif", fontStyle: "italic", fontSize: 22, color: C.primary }}>
            Tofha<span style={{ color: C.gold }}>.</span>
          </span>
          <div className="flex items-center gap-3">
            {[
              { icon: "search" },
              { icon: "notifications", dot: true },
              { icon: "favorite" },
              { icon: "shopping_cart" },
            ].map(({ icon, dot }) => (
              <button key={icon} className="relative p-1 active:scale-95 transition-transform">
                <PhoneIcon name={icon} size={22} />
                {dot && (
                  <span
                    className="absolute top-0.5 right-0.5 rounded-full"
                    style={{ width: 7, height: 7, background: C.terracotta }}
                  />
                )}
              </button>
            ))}
          </div>
        </nav>

        {/* Scrollable content */}
        <div
          className="flex-1 overflow-y-auto px-5 pt-5 pb-8 relative"
          style={{ scrollbarWidth: "none" }}
        >
          {/* Watermark decorations */}
          <div style={{ position: "absolute", top: 120, left: -16, opacity: 0.06, transform: "rotate(-12deg)", pointerEvents: "none" }}>
            <PhoneIcon name="nest_multi_room" size={100} color={C.onSurface} />
          </div>
          <div style={{ position: "absolute", bottom: 80, right: -20, opacity: 0.06, transform: "rotate(45deg)", pointerEvents: "none" }}>
            <PhoneIcon name="local_florist" size={120} color={C.onSurface} />
          </div>

          {/* Header */}
          <header className="mb-4 relative z-10">
            <p
              style={{
                fontFamily: "'Cinzel', serif",
                fontSize: 11,
                fontWeight: 700,
                letterSpacing: "0.12em",
                color: C.gold,
                textTransform: "uppercase",
                marginBottom: 4,
              }}
            >
              My Account
            </p>
            <h1
              style={{
                fontFamily: "'Playfair Display', serif",
                fontStyle: "italic",
                fontSize: 26,
                fontWeight: 400,
                color: C.primary,
                lineHeight: 1.25,
              }}
            >
              Saved Addresses{" "}
              <span style={{ color: C.gold, fontWeight: 300, opacity: 0.7 }}>✦</span>
            </h1>
          </header>

          {/* Add address button */}
          <button
            className="w-full mb-5 py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all duration-300 group active:scale-[0.98]"
            style={{
              background: C.background,
              border: `1px solid ${C.sage}`,
              color: C.secondary,
              fontFamily: "'DM Sans', sans-serif",
              fontSize: 15,
            }}
          >
            <PhoneIcon name="add" size={20} color={C.secondary} />
            Add a new address
          </button>

          {/* Address cards */}
          <div className="flex flex-col gap-4 relative z-10">
            {cards.map((addr) => (
              <AddressCard
                key={addr.id}
                addr={addr}
                onDelete={(id) => setDeleteTarget(id)}
                onSetDefault={handleSetDefault}
              />
            ))}
          </div>

          {/* Footer */}
          <footer className="mt-6 text-center">
            <div
              className="inline-flex items-center justify-center p-3 rounded-full mb-3"
              style={{ border: `1px dashed ${C.outlineVariant}` }}
            >
              <PhoneIcon name="handyman" size={20} color={C.sage} />
            </div>
            <p style={{ fontFamily: "'Lora', serif", fontStyle: "italic", fontSize: 13, color: C.primary, opacity: 0.65 }}>
              "Crafting a space for your gifts to travel."
            </p>
          </footer>
        </div>

        {/* Delete modal */}
        {deleteTarget !== null && (
          <DeleteModal
            onClose={() => setDeleteTarget(null)}
            onConfirm={() => handleDelete(deleteTarget)}
          />
        )}
      </div>
    </div>
  );
}
