import { useState } from "react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";

const c = {
  primary: "#255338",
  forest: "#3D6B4F",
  tertiary: "#573b81",
  tertiaryFixed: "#ecdcff",
  onTertiaryFixed: "#270550",
  onTertiaryFixedVariant: "#54387e",
  secondary: "#49663f",
  surface: "#fff8f3",
  surfaceContainer: "#f9ecdc",
  surfaceContainerLow: "#fff2e1",
  surfaceContainerLowest: "#ffffff",
  onSurface: "#211b11",
  onSurfaceVariant: "#414942",
  outlineVariant: "#c1c9c0",
  outline: "#717972",
  error: "#ba1a1a",
  errorContainer: "#ffdad6",
  primaryFixed: "#bceecb",
  gold: "#D4AF37",
  ivory: "#FCFAF5",
};

// Font shorthands
const f = {
  display: "'Playfair Display', Georgia, serif",
  serif: "'Merriweather', Georgia, serif",
  sans: "'DM Sans', system-ui, sans-serif",
  caps: "'Cinzel', Georgia, serif",
  mono: "'Space Mono', 'Courier New', monospace",
};

function Icon({
  name,
  filled = false,
  size = 22,
  color,
  style = {},
}: {
  name: string;
  filled?: boolean;
  size?: number;
  color?: string;
  style?: React.CSSProperties;
}) {
  return (
    <span
      className="material-symbols-outlined"
      style={{
        fontSize: size,
        color,
        fontVariationSettings: filled ? "'FILL' 1, 'wght' 400" : "'FILL' 0, 'wght' 400",
        lineHeight: 1,
        display: "inline-block",
        ...style,
      }}
    >
      {name}
    </span>
  );
}

const avatarUrl =
  "https://lh3.googleusercontent.com/aida-public/AB6AXuA1MlCvGNVC5kb3_0adXisBIXKR2kO5rDi5REC7Ws_jdqAl-d9k85WtM1zhT8kPt7miefUL2zB7ZWlht6gOBoOFf_yaM44xEDS_XDmP2CC3-O2XtWEbyNWU5d0aYrxHES2zAVOb4to55ZXc0JuEuYUxljiCZtgqH9k3hGJLepqGwKKZZmnmigxFXREVk5a9jUDkeBzDkZX8Z9jT_im_tJi4_Y8YVc3tbxMsxYFYLwpSOJOXUuN4y3YO7VUkGCQmkVDabJ6ip82gLbE";

const activityItems = [
  { icon: "package_2",     label: "Orders",        sub: "2 active",       color: c.primary },
  { icon: "favorite",      label: "Wishlist",       sub: "15 items",       color: c.tertiary },
  { icon: "video_library", label: "Saved Reels",    sub: "Process & BTS",  color: c.secondary },
  { icon: "receipt_long",  label: "Payments",       sub: "Tax invoices",   color: c.primary },
  { icon: "location_on",   label: "Addresses",      sub: "3 locations",    color: c.tertiary },
  { icon: "notifications", label: "Notifications",  sub: "Recent alerts",  color: c.secondary },
];

const prefItems = [
  { icon: "notifications_active", label: "Notifications" },
  { icon: "help_center",          label: "Help & Support" },
  { icon: "info",                 label: "About Tohfa" },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<"home" | "category" | "reels" | "profile">("profile");

  return (
    <div className="min-h-screen w-full flex items-center justify-center" style={{ background: "#ddd5c8" }}>
      {/* ── Phone shell ── */}
      <div
        style={{
          width: 390, height: 844,
          borderRadius: 48,
          boxShadow: "0 48px 96px rgba(0,0,0,0.38), 0 0 0 10px #1a1a1a, 0 0 0 12px #2e2e2e",
          background: c.surface,
          display: "flex", flexDirection: "column",
          overflow: "hidden",
          fontFamily: f.sans,
        }}
      >

        {/* Status bar */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 24px 6px", position: "relative", zIndex: 50 }}>
          <span style={{ fontFamily: f.sans, fontSize: 13, fontWeight: 600, color: c.onSurface }}>9:41</span>
          <div style={{ width: 126, height: 32, borderRadius: 20, background: "#111", position: "absolute", left: "50%", transform: "translateX(-50%)", top: 8 }} />
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <Icon name="signal_cellular_alt" size={15} color={c.onSurface} />
            <Icon name="wifi" size={15} color={c.onSurface} />
            <Icon name="battery_5_bar" size={15} color={c.onSurface} />
          </div>
        </div>

        {/* Top nav */}
        <header style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "0 20px", height: 52,
          background: "#fff",
          borderBottom: `1px solid ${c.outlineVariant}`,
          flexShrink: 0, zIndex: 40,
        }}>
          {/* Logo */}
          <div style={{ display: "flex", alignItems: "flex-end", gap: 0 }}>
            <span style={{ fontFamily: f.display, fontSize: 23, fontStyle: "italic", fontWeight: 400, color: c.primary, lineHeight: 1 }}>
              Tohfa
            </span>
            <span style={{ width: 5, height: 5, borderRadius: "50%", background: c.gold, marginBottom: 5, marginLeft: 1, flexShrink: 0 }} />
          </div>
          {/* Right icons */}
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <Icon name="search"        size={20} color={c.primary} />
            <Icon name="favorite"      size={20} color={c.primary} />
            <Icon name="notifications" size={20} color={c.primary} />
            <div style={{ width: 30, height: 30, borderRadius: "50%", background: c.forest, color: "#fff", fontSize: 12, fontFamily: f.sans, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", border: `1.5px solid ${c.outlineVariant}`, cursor: "pointer" }}>
              E
            </div>
          </div>
        </header>

        {/* ── Scrollable body ── */}
        <div style={{ flex: 1, overflowY: "auto", background: c.surface, paddingBottom: 80 }}>

          {/* Banner */}
          <div style={{ height: 82, background: `linear-gradient(130deg, #2d5e42 0%, #255338 45%, #4a3270 100%)`, position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", inset: 0, opacity: 0.1, backgroundImage: "radial-gradient(circle at 2px 2px, rgba(255,255,255,0.8) 1px, transparent 0)", backgroundSize: "18px 18px" }} />
            <div style={{ position: "absolute", right: 10, bottom: -10, opacity: 0.1 }}>
              <Icon name="brush" size={72} color="#fff" />
            </div>
          </div>

          {/* Avatar + name */}
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: -38 }}>
            <div style={{ position: "relative" }}>
              <div style={{ width: 76, height: 76, borderRadius: "50%", border: `3px solid ${c.primary}`, overflow: "hidden", background: c.surfaceContainer, boxShadow: "0 4px 16px rgba(0,0,0,0.18)" }}>
                <ImageWithFallback src={avatarUrl} alt="Elias Thorne" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              </div>
              <button style={{ position: "absolute", bottom: 1, right: 1, width: 22, height: 22, borderRadius: "50%", background: c.primary, border: `2px solid ${c.surface}`, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
                <Icon name="edit" size={11} color="#fff" />
              </button>
            </div>

            <h2 style={{ fontFamily: f.display, fontSize: 21, fontWeight: 500, fontStyle: "italic", color: c.onSurface, marginTop: 10, marginBottom: 0, lineHeight: 1.2 }}>
              Elias Thorne
            </h2>

            <div style={{ display: "flex", gap: 20, marginTop: 6, fontFamily: f.sans, fontSize: 12, color: c.outline, letterSpacing: "0.01em" }}>
              <button style={{ background: "none", border: "none", cursor: "pointer", color: "inherit", fontFamily: "inherit", fontSize: "inherit", padding: 0 }}>
                <span style={{ fontWeight: 700, color: c.onSurface, fontFamily: f.sans }}>124</span> Following
              </button>
              <button style={{ background: "none", border: "none", cursor: "pointer", color: "inherit", fontFamily: "inherit", fontSize: "inherit", padding: 0 }}>
                <span style={{ fontWeight: 700, color: c.onSurface, fontFamily: f.sans }}>892</span> Followers
              </button>
            </div>

            <button style={{ marginTop: 10, padding: "5px 22px", border: `1.5px solid ${c.outlineVariant}`, borderRadius: 9999, background: "transparent", fontFamily: f.caps, fontSize: 9, fontWeight: 700, letterSpacing: "0.12em", color: c.onSurface, cursor: "pointer", textTransform: "uppercase" }}>
              Edit Profile
            </button>
          </div>

          {/* Activity Hub */}
          <div style={{ padding: "18px 16px 0" }}>
            <p style={{ fontFamily: f.serif, fontSize: 13, fontWeight: 700, color: c.onSurface, marginBottom: 10, letterSpacing: "0.01em" }}>
              Activity Hub
            </p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
              {activityItems.map((item) => (
                <button
                  key={item.label}
                  style={{ background: c.surfaceContainerLow, border: "1px solid transparent", borderRadius: 12, padding: "11px 10px", textAlign: "left", cursor: "pointer" }}
                >
                  <Icon name={item.icon} size={19} color={item.color} style={{ display: "block", marginBottom: 7 }} />
                  <p style={{ fontFamily: f.sans, fontSize: 12, fontWeight: 600, color: c.onSurface, margin: 0, lineHeight: 1.3 }}>{item.label}</p>
                  <p style={{ fontFamily: f.sans, fontSize: 10, color: c.outline, marginTop: 2, lineHeight: 1.3 }}>{item.sub}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Shipping & Payment */}
          <div style={{ padding: "12px 16px 0", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {/* Shipping */}
            <div style={{ border: `1px solid ${c.outlineVariant}`, borderRadius: 12, padding: "12px 12px", background: c.surfaceContainerLowest, position: "relative", overflow: "hidden" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                <span style={{ fontFamily: f.caps, fontSize: 8, fontWeight: 600, color: c.outline, textTransform: "uppercase", letterSpacing: "0.1em" }}>Shipping</span>
                <button style={{ background: "none", border: "none", fontFamily: f.sans, fontSize: 11, fontWeight: 700, color: c.primary, cursor: "pointer", padding: 0 }}>Edit</button>
              </div>
              <p style={{ fontFamily: f.serif, fontSize: 11, fontWeight: 700, color: c.onSurface, lineHeight: 1.4, margin: 0 }}>Studio 4B, The Grains</p>
              <p style={{ fontFamily: f.sans, fontSize: 10, color: c.onSurfaceVariant, marginTop: 3, lineHeight: 1.5 }}>Artisan Quarter, Kyoto 604-8021, Japan</p>
              <div style={{ position: "absolute", bottom: -8, right: -8, width: 36, height: 36, background: `${c.primaryFixed}50`, filter: "blur(10px)", borderRadius: "50%" }} />
            </div>
            {/* Payment */}
            <div style={{ border: `1px solid ${c.outlineVariant}`, borderRadius: 12, padding: "12px 12px", background: c.surfaceContainerLowest, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
              <div>
                <span style={{ fontFamily: f.caps, fontSize: 8, fontWeight: 600, color: c.outline, textTransform: "uppercase", letterSpacing: "0.1em", display: "block", marginBottom: 8 }}>Payment</span>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <Icon name="credit_card" size={17} color={c.onSurfaceVariant} />
                  <span style={{ fontFamily: f.mono, fontSize: 10, color: c.onSurface }}>•••• 4291</span>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 10 }}>
                <span style={{ fontFamily: f.sans, fontSize: 10, color: c.outline }}>Expires 09/27</span>
                <Icon name="settings" size={14} color={`${c.onSurfaceVariant}88`} />
              </div>
            </div>
          </div>

          {/* Preferences */}
          <div style={{ padding: "12px 16px 0" }}>
            <div style={{ background: `${c.ivory}`, border: `1px solid ${c.outlineVariant}`, borderRadius: 14, overflow: "hidden" }}>
              <p style={{ fontFamily: f.serif, fontSize: 13, fontWeight: 700, color: c.onSurface, padding: "13px 14px 8px", margin: 0 }}>
                Preferences
              </p>
              {prefItems.map((item, i) => (
                <button
                  key={item.label}
                  style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "11px 14px", background: "none", border: "none", borderTop: i === 0 ? `1px solid ${c.outlineVariant}33` : `1px solid ${c.outlineVariant}33`, cursor: "pointer", textAlign: "left" }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <Icon name={item.icon} size={18} color={c.onSurfaceVariant} />
                    <span style={{ fontFamily: f.sans, fontSize: 13.5, color: c.onSurface }}>{item.label}</span>
                  </div>
                  <Icon name="chevron_right" size={17} color={c.outline} />
                </button>
              ))}
              <button
                style={{ width: "100%", display: "flex", alignItems: "center", gap: 12, padding: "11px 14px", background: "none", border: "none", borderTop: `1px solid ${c.outlineVariant}`, cursor: "pointer" }}
              >
                <Icon name="logout" size={18} color={c.error} />
                <span style={{ fontFamily: f.sans, fontSize: 13.5, fontWeight: 600, color: c.error }}>Log out</span>
              </button>
            </div>
          </div>

          {/* Join the Studio */}
          <div style={{ padding: "12px 16px 0" }}>
            <div style={{ background: c.tertiaryFixed, borderRadius: 14, padding: "16px 16px", position: "relative", overflow: "hidden", cursor: "pointer" }}>
              <div style={{ position: "relative", zIndex: 1 }}>
                <p style={{ fontFamily: f.display, fontSize: 17, fontWeight: 500, fontStyle: "italic", color: c.onTertiaryFixed, margin: 0, lineHeight: 1.3 }}>
                  Join the Studio
                </p>
                <p style={{ fontFamily: f.sans, fontSize: 12, color: c.onTertiaryFixedVariant, marginTop: 5, lineHeight: 1.6 }}>
                  Become a certified Tohfa Artisan and share your craft with the world.
                </p>
                <button style={{ marginTop: 11, background: c.onTertiaryFixed, color: c.surface, border: "none", borderRadius: 9999, padding: "5px 16px", fontFamily: f.caps, fontSize: 9, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", cursor: "pointer" }}>
                  Apply Now
                </button>
              </div>
              <div style={{ position: "absolute", right: -10, bottom: -10, opacity: 0.1 }}>
                <Icon name="palette" size={88} color={c.onTertiaryFixed} />
              </div>
            </div>
          </div>

          {/* Footer rule */}
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 10, padding: "20px 0 4px", opacity: 0.22 }}>
            <div style={{ width: 36, height: 1, background: c.outline }} />
            <Icon name="eco" size={13} color={c.outline} />
            <div style={{ width: 36, height: 1, background: c.outline }} />
          </div>
        </div>

        {/* Bottom nav */}
        <nav style={{ display: "flex", alignItems: "center", justifyContent: "space-around", borderTop: `1px solid ${c.outlineVariant}`, background: c.surface, height: 72, position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 40 }}>
          {(
            [
              { id: "home",     icon: "home",        label: "Home" },
              { id: "category", icon: "category",    label: "Category" },
              { id: "reels",    icon: "play_circle", label: "Reels" },
              { id: "profile",  icon: "person",      label: "Profile" },
            ] as const
          ).map((tab) => {
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{ background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "8px 12px", borderRadius: 8 }}
              >
                <Icon name={tab.icon} filled={active} size={22} color={active ? c.primary : c.onSurfaceVariant} />
                <span style={{ fontFamily: f.caps, fontSize: 9, fontWeight: active ? 700 : 400, letterSpacing: "0.06em", color: active ? c.primary : c.onSurfaceVariant, textTransform: "uppercase" }}>
                  {tab.label}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
