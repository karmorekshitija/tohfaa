import { useState } from "react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";

const c = {
  primary:    "#255338",
  secondary:  "#49663f",
  tertiary:   "#573b81",
  surface:    "#fff8f3",
  ivory:      "#FCFAF5",
  surfaceContainerLow: "#fff2e1",
  surfaceDim: "#e5d8c8",
  secondaryContainer: "#c8e9b8",
  secondaryFixed: "#caecbb",
  errorContainer: "#ffdad6",
  error:      "#ba1a1a",
  onSurface:  "#211b11",
  onSurfaceVariant: "#414942",
  outlineVariant: "#c1c9c0",
  outline:    "#717972",
  gold:       "#A68942",
  sage:       "#717972",
};

const f = {
  display: "'Playfair Display', Georgia, serif",
  serif:   "'Merriweather', Georgia, serif",
  sans:    "'DM Sans', system-ui, sans-serif",
  caps:    "'Cinzel', Georgia, serif",
  mono:    "'Space Mono', monospace",
};

function Icon({ name, filled = false, size = 22, color, style = {} }: {
  name: string; filled?: boolean; size?: number; color?: string; style?: React.CSSProperties;
}) {
  return (
    <span
      className="material-symbols-outlined"
      style={{ fontSize: size, color, fontVariationSettings: filled ? "'FILL' 1, 'wght' 300" : "'FILL' 0, 'wght' 300", lineHeight: 1, display: "inline-block", flexShrink: 0, ...style }}
    >
      {name}
    </span>
  );
}

// ── Avatar ──────────────────────────────────────────
function Avatar({ src, initials, bg, size = 48 }: { src?: string; initials?: string; bg?: string; size?: number }) {
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", overflow: "hidden", background: bg ?? c.primary, border: `1px solid ${c.outlineVariant}`, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
      {src
        ? <ImageWithFallback src={src} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        : <span style={{ fontFamily: f.sans, fontWeight: 700, fontSize: size * 0.36, color: "#fff" }}>{initials}</span>
      }
    </div>
  );
}

// ── Badge ────────────────────────────────────────────
function Badge({ text, bg, color, pulse }: { text: string; bg: string; color: string; pulse?: boolean }) {
  return (
    <span style={{
      background: bg, color, borderRadius: 9999,
      padding: "3px 10px",
      fontFamily: f.caps, fontSize: 8, fontWeight: 700, letterSpacing: "0.08em",
      textTransform: "uppercase", whiteSpace: "nowrap",
      animation: pulse ? "pulse 1.8s ease-in-out infinite" : "none",
    }}>
      {text}
    </span>
  );
}

// ── Birthday card ────────────────────────────────────
type Person = {
  name: string; relation: string; date: string; badge: string;
  badgeBg: string; badgeColor: string; badgePulse?: boolean;
  avatarSrc?: string; avatarInitial?: string; avatarBg?: string;
  hasAddress: boolean; addressMissing?: boolean;
  action: string;
};

const people: Person[] = [
  {
    name: "Riya", relation: "SISTER", date: "15 AUG",
    badge: "IN 3 DAYS", badgeBg: c.secondaryContainer, badgeColor: c.primary,
    avatarSrc: "https://lh3.googleusercontent.com/aida-public/AB6AXuBMirHrVJL4jncWBzc6sQoRRfunhcr_OZ7xqTu1xPNxTQ6bjpxnv6u9Ay15MbS58k22kigEJl_cSyUCGYElPSBaQ9vg85S4i-bOGO1J1C7Qu4isZRxvzo_aKFP0BgQgJ7wgl__5JhofM7Sctce3oe7sk1uExm3CGnY9oqfnW8D-lC5QcJc1cQtqZ2KtRLHCAFd3bgbdYgE3nwen6fm1XNjZHxuWJgTbOck9ki0aeCln0RhcrGaGY4TSqJ_txm7H9WW52C8IPmvDkEA",
    hasAddress: true, action: "Shop gift",
  },
  {
    name: "Aditya", relation: "BEST FRIEND", date: "08 JUN",
    badge: "BIRTHDAY TODAY 🎂", badgeBg: c.secondaryContainer, badgeColor: c.primary, badgePulse: true,
    avatarInitial: "A", avatarBg: c.gold,
    hasAddress: false, addressMissing: true, action: "Shop gift",
  },
  {
    name: "Maa", relation: "MOM", date: "22 SEP",
    badge: "IN 106 DAYS", badgeBg: c.surfaceDim, badgeColor: c.onSurfaceVariant,
    avatarInitial: "M", avatarBg: c.secondaryFixed,
    hasAddress: true, action: "View wishlist",
  },
];

// chip avatars
const chipRiyaSrc = "https://lh3.googleusercontent.com/aida-public/AB6AXuD-RlBrElEmAe_7nOI5MBJlkmaIYkE8KHoRI0fJiJ7G7tozJS_mMQHepWpRAL_N1n4jANfATfLe-otjb6Yea8HL6mqm246a-NlPZRYBFryFXWrKL7SSZHk5Po7egdrxcTpBN3m8blXftv_vV75nGS1p-MVG_thAwTavGOJ0VN8dFbpRZLXTMSMr1gyStYwX7zXpJlB8WD6oR5up1SyOx2bNvmRvlTYmisHbZLPDbmupRJDD__gdfKc5XnyPxendPROZ06Rq5_0rPSs";

export default function App() {
  const [activeTab, setActiveTab] = useState<"home" | "category" | "reels" | "profile">("profile");

  return (
    <>
      <style>{`
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.6} }
        .bday-scroll::-webkit-scrollbar { display:none }
        .bday-scroll { -ms-overflow-style:none; scrollbar-width:none }
      `}</style>

      <div className="min-h-screen w-full flex items-center justify-center" style={{ background: "#ddd5c8" }}>
        <div style={{
          width: 390, height: 844, borderRadius: 48,
          boxShadow: "0 48px 96px rgba(0,0,0,0.38), 0 0 0 10px #1a1a1a, 0 0 0 12px #2e2e2e",
          background: "#fff",
          display: "flex", flexDirection: "column",
          overflow: "hidden", fontFamily: f.sans, position: "relative",
        }}>

          {/* Status bar */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 24px 6px", position: "relative", zIndex: 50, flexShrink: 0, background: "#fff" }}>
            <span style={{ fontFamily: f.sans, fontSize: 13, fontWeight: 600, color: c.onSurface }}>9:41</span>
            <div style={{ width: 126, height: 32, borderRadius: 20, background: "#111", position: "absolute", left: "50%", transform: "translateX(-50%)", top: 8 }} />
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <Icon name="signal_cellular_alt" size={15} color={c.onSurface} />
              <Icon name="wifi"                size={15} color={c.onSurface} />
              <Icon name="battery_5_bar"       size={15} color={c.onSurface} />
            </div>
          </div>

          {/* Top nav */}
          <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 20px", height: 52, background: "#fff", borderBottom: `1px solid ${c.outlineVariant}`, flexShrink: 0, zIndex: 40 }}>
            <div style={{ display: "flex", alignItems: "flex-end" }}>
              <span style={{ fontFamily: f.display, fontSize: 22, fontStyle: "italic", fontWeight: 400, color: c.primary, lineHeight: 1 }}>Tofha</span>
              <span style={{ width: 5, height: 5, borderRadius: "50%", background: c.gold, marginBottom: 4, marginLeft: 1 }} />
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <Icon name="search"        size={20} color={c.onSurfaceVariant} />
              <Icon name="notifications" size={20} color={c.onSurfaceVariant} />
              <Icon name="favorite"      size={20} color={c.onSurfaceVariant} />
              <div style={{ position: "relative" }}>
                <Icon name="shopping_cart" size={20} color={c.onSurfaceVariant} />
                <span style={{ position: "absolute", top: -4, right: -4, width: 14, height: 14, borderRadius: "50%", background: c.gold, color: "#fff", fontSize: 8, fontWeight: 700, fontFamily: f.sans, display: "flex", alignItems: "center", justifyContent: "center" }}>2</span>
              </div>
            </div>
          </header>

          {/* ── Scrollable body ── */}
          <div style={{ flex: 1, overflowY: "auto", background: "#fff", paddingBottom: 80 }}>

            {/* Section 1 – Page header */}
            <div style={{ padding: "20px 20px 16px", position: "relative", overflow: "hidden", background: "#fff" }}>
              <p style={{ fontFamily: f.caps, fontSize: 9, fontWeight: 700, color: c.gold, letterSpacing: "0.12em", textTransform: "uppercase", margin: "0 0 6px" }}>
                NEVER FORGET A BIRTHDAY ✦
              </p>
              <h1 style={{ fontFamily: f.display, fontSize: 24, fontStyle: "italic", fontWeight: 400, color: c.onSurface, margin: "0 0 6px", lineHeight: 1.25 }}>
                Birthday Reminders
              </h1>
              <p style={{ fontFamily: f.sans, fontSize: 12, color: "#6E6453", margin: 0, maxWidth: 240 }}>
                We'll remind you 7 days before so you never miss a moment.
              </p>
              {/* cake watermark */}
              <div style={{ position: "absolute", right: -8, top: "50%", transform: "translateY(-50%)", opacity: 0.08, pointerEvents: "none" }}>
                <Icon name="cake" size={72} color={c.onSurface} />
              </div>
            </div>

            {/* Section 2 – Hero strip */}
            <div style={{ margin: "0 0 20px", background: "#F1EADD", padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div>
                <h2 style={{ fontFamily: f.display, fontSize: 16, fontStyle: "italic", color: c.primary, margin: "0 0 3px" }}>
                  Upcoming birthdays ✦
                </h2>
                <p style={{ fontFamily: f.sans, fontSize: 12, color: c.onSurfaceVariant, margin: 0 }}>
                  You have 2 birthdays in the next 30 days.
                </p>
              </div>
              <div style={{ position: "relative", flexShrink: 0 }}>
                <Icon name="cake" size={40} color={c.gold} style={{ opacity: 0.7 }} />
              </div>
            </div>

            {/* Section 3 – Upcoming chips */}
            <div style={{ padding: "0 20px 20px" }}>
              <p style={{ fontFamily: f.caps, fontSize: 9, fontWeight: 700, color: c.gold, letterSpacing: "0.12em", textTransform: "uppercase", margin: "0 0 12px" }}>
                COMING SOON
              </p>
              <div className="bday-scroll" style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 4 }}>
                {/* Riya chip */}
                <div style={{ flexShrink: 0, width: 80, background: c.ivory, border: `1px solid ${c.sage}`, borderRadius: 14, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "10px 4px", gap: 3, boxShadow: "4px 4px 10px rgba(58,51,40,0.08)" }}>
                  <Avatar src={chipRiyaSrc} size={36} />
                  <span style={{ fontFamily: f.serif, fontSize: 11, fontWeight: 700, color: c.onSurface }}>Riya</span>
                  <span style={{ fontFamily: f.mono, fontSize: 9, color: c.gold }}>15 Aug</span>
                  <span style={{ background: c.secondaryContainer, borderRadius: 9999, padding: "2px 6px", fontFamily: f.caps, fontSize: 7, fontWeight: 700, color: c.primary, letterSpacing: "0.06em" }}>IN 3 DAYS</span>
                </div>
                {/* Aditya chip — highlighted */}
                <div style={{ flexShrink: 0, width: 80, background: c.ivory, border: `1.5px solid ${c.gold}`, borderRadius: 14, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "10px 4px", gap: 3, boxShadow: "4px 4px 12px rgba(166,137,66,0.18)", transform: "scale(1.05)" }}>
                  <div style={{ width: 36, height: 36, borderRadius: "50%", background: c.gold, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <span style={{ fontFamily: f.sans, fontWeight: 700, fontSize: 14, color: "#fff" }}>A</span>
                  </div>
                  <span style={{ fontFamily: f.serif, fontSize: 11, fontWeight: 700, color: c.onSurface }}>Aditya</span>
                  <span style={{ fontFamily: f.mono, fontSize: 9, color: c.gold }}>08 Jun</span>
                  <span style={{ background: c.secondaryContainer, borderRadius: 9999, padding: "2px 6px", fontFamily: f.caps, fontSize: 7, fontWeight: 700, color: c.primary, letterSpacing: "0.06em" }}>TODAY 🎂</span>
                </div>
                {/* Maa chip */}
                <div style={{ flexShrink: 0, width: 80, background: c.ivory, border: `1px solid ${c.sage}`, borderRadius: 14, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "10px 4px", gap: 3, boxShadow: "4px 4px 10px rgba(58,51,40,0.08)" }}>
                  <div style={{ width: 36, height: 36, borderRadius: "50%", background: c.secondaryFixed, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <span style={{ fontFamily: f.sans, fontWeight: 700, fontSize: 14, color: c.primary }}>M</span>
                  </div>
                  <span style={{ fontFamily: f.serif, fontSize: 11, fontWeight: 700, color: c.onSurface }}>Maa</span>
                  <span style={{ fontFamily: f.mono, fontSize: 9, color: c.gold }}>22 Sep</span>
                  <span style={{ background: c.errorContainer, borderRadius: 9999, padding: "2px 6px", fontFamily: f.caps, fontSize: 7, fontWeight: 700, color: c.error, letterSpacing: "0.06em" }}>IN 2 DAYS</span>
                </div>
                {/* Add chip */}
                <div style={{ flexShrink: 0, width: 80, background: "#fff", border: `1.5px dashed ${c.outlineVariant}`, borderRadius: 14, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, padding: "10px 4px" }}>
                  <Icon name="add" size={22} color={c.outlineVariant} />
                  <span style={{ fontFamily: f.sans, fontSize: 9, color: c.outline, textAlign: "center" }}>Add</span>
                </div>
              </div>
            </div>

            {/* Section 4 – Add button */}
            <div style={{ padding: "0 20px 20px" }}>
              <button style={{ width: "100%", height: 46, background: "#fff", border: `1px solid ${c.sage}`, borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, cursor: "pointer", transition: "background 0.15s" }}>
                <Icon name="add" size={19} color={c.primary} />
                <span style={{ fontFamily: f.sans, fontSize: 14, fontWeight: 600, color: c.primary }}>Add a birthday</span>
              </button>
            </div>

            {/* Section 5 – All birthdays */}
            <div style={{ padding: "0 20px 20px" }}>
              <p style={{ fontFamily: f.caps, fontSize: 9, fontWeight: 700, color: c.gold, letterSpacing: "0.12em", textTransform: "uppercase", margin: "0 0 12px" }}>
                ALL BIRTHDAYS
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {people.map((p) => (
                  <div key={p.name} style={{ background: c.ivory, border: `1px solid ${c.sage}`, borderRadius: 16, padding: "14px 14px 12px", boxShadow: "4px 4px 12px rgba(58,51,40,0.07)", position: "relative", overflow: "hidden" }}>

                    {/* Top row */}
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                      <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                        <Avatar
                          src={p.avatarSrc}
                          initials={p.avatarInitial}
                          bg={p.avatarBg ?? c.primary}
                          size={44}
                        />
                        <div>
                          <h3 style={{ fontFamily: f.serif, fontSize: 14, fontWeight: 700, color: c.onSurface, margin: 0, lineHeight: 1.3 }}>{p.name}</h3>
                          <p style={{ fontFamily: f.caps, fontSize: 9, fontWeight: 700, color: c.onSurfaceVariant, letterSpacing: "0.08em", margin: "3px 0 0", textTransform: "uppercase" }}>
                            {p.relation} • {p.date}
                          </p>
                        </div>
                      </div>
                      <Badge text={p.badge} bg={p.badgeBg} color={p.badgeColor} pulse={p.badgePulse} />
                    </div>

                    {/* Address row */}
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 0", borderTop: `1px dashed ${c.outlineVariant}`, marginTop: 2 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <Icon
                          name={p.addressMissing ? "location_off" : "home"}
                          size={15}
                          color={p.addressMissing ? c.error : c.primary}
                        />
                        <span style={{ fontFamily: f.sans, fontSize: 12, color: c.onSurfaceVariant, fontStyle: p.addressMissing ? "italic" : "normal" }}>
                          {p.addressMissing ? "No address provided" : "Address saved"}
                        </span>
                      </div>
                      {p.addressMissing && (
                        <button style={{ background: "none", border: "none", fontFamily: f.sans, fontSize: 12, fontWeight: 700, color: c.primary, cursor: "pointer", padding: 0 }}>
                          + Add address
                        </button>
                      )}
                      {!p.addressMissing && p.name === "Riya" && (
                        <button style={{ background: "none", border: "none", fontFamily: f.sans, fontSize: 12, color: c.secondary, cursor: "pointer", padding: 0 }}>
                          Change →
                        </button>
                      )}
                    </div>

                    {/* Actions row */}
                    <div style={{ display: "flex", alignItems: "center", gap: 10, paddingTop: 8 }}>
                      <button style={{ display: "flex", alignItems: "center", gap: 4, background: "none", border: "none", cursor: "pointer", padding: 0 }}>
                        <Icon name="redeem" size={14} color={c.primary} />
                        <span style={{ fontFamily: f.sans, fontSize: 13, color: c.primary, fontWeight: 500 }}>{p.action}</span>
                      </button>
                      <div style={{ flex: 1 }} />
                      <button style={{ background: "none", border: "none", fontFamily: f.caps, fontSize: 9, fontWeight: 700, color: c.tertiary, letterSpacing: "0.08em", cursor: "pointer", textTransform: "uppercase", padding: 0 }}>
                        EDIT
                      </button>
                      <div style={{ width: 1, height: 12, background: c.sage }} />
                      <button style={{ background: "none", border: "none", fontFamily: f.caps, fontSize: 9, fontWeight: 700, color: c.error, letterSpacing: "0.08em", cursor: "pointer", textTransform: "uppercase", padding: 0 }}>
                        DELETE
                      </button>
                    </div>

                    {/* Watermark */}
                    <div style={{ position: "absolute", right: -4, bottom: -4, opacity: 0.06, pointerEvents: "none" }}>
                      <Icon name={p.name === "Riya" ? "inventory_2" : p.name === "Aditya" ? "label_important" : "redeem"} size={48} color={c.onSurface} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Section 6 – Reminder settings */}
            <div style={{ padding: "0 20px 20px" }}>
              <div style={{ background: c.ivory, border: `1px solid ${c.sage}`, borderRadius: 18, padding: "16px 16px", position: "relative", overflow: "hidden", boxShadow: "4px 4px 15px rgba(58,51,40,0.05)" }}>
                <div style={{ position: "relative", zIndex: 1 }}>
                  <p style={{ fontFamily: f.caps, fontSize: 9, fontWeight: 700, color: c.gold, letterSpacing: "0.12em", textTransform: "uppercase", margin: "0 0 6px" }}>
                    REMINDER SETTINGS
                  </p>
                  <h2 style={{ fontFamily: f.display, fontSize: 15, fontStyle: "italic", color: c.onSurface, margin: "0 0 6px", lineHeight: 1.35 }}>
                    When should we remind you?
                  </h2>
                  <p style={{ fontFamily: f.sans, fontSize: 12, color: "#6E6453", margin: "0 0 10px" }}>
                    Currently notifying you <strong style={{ color: c.primary }}>7 days</strong> before the date.
                  </p>
                  <button style={{ background: "none", border: "none", padding: 0, fontFamily: f.sans, fontSize: 12, color: c.tertiary, cursor: "pointer" }}>
                    Change reminder timing →
                  </button>
                </div>
                <div style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", opacity: 0.08, pointerEvents: "none" }}>
                  <Icon name="notifications_active" size={64} color={c.onSurface} />
                </div>
              </div>
            </div>

            {/* Decorative footer scatter */}
            <div style={{ display: "flex", justifyContent: "center", gap: 28, opacity: 0.09, padding: "12px 0 4px", pointerEvents: "none" }}>
              <Icon name="park"          size={26} color={c.outline} style={{ transform: "rotate(12deg)" }} />
              <Icon name="local_florist" size={26} color={c.outline} style={{ transform: "rotate(-12deg)" }} />
              <Icon name="stylus"        size={26} color={c.outline} style={{ transform: "rotate(45deg)" }} />
            </div>
          </div>

          {/* ── Bottom nav ── */}
          <nav style={{ display: "flex", alignItems: "center", justifyContent: "space-around", borderTop: `1px solid ${c.outlineVariant}`, background: c.surface, height: 72, position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 40 }}>
            {([
              { id: "home",     icon: "home",        label: "Home" },
              { id: "category", icon: "category",    label: "Category" },
              { id: "reels",    icon: "play_circle", label: "Reels" },
              { id: "profile",  icon: "person",      label: "Profile" },
            ] as const).map((tab) => {
              const active = activeTab === tab.id;
              return (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "8px 12px", borderRadius: 8 }}>
                  <Icon name={tab.icon} filled={active} size={22} color={active ? c.primary : c.onSurfaceVariant} style={{ fontVariationSettings: active ? "'FILL' 1" : "'FILL' 0" }} />
                  <span style={{ fontFamily: f.caps, fontSize: 9, fontWeight: active ? 700 : 400, letterSpacing: "0.06em", color: active ? c.primary : c.onSurfaceVariant, textTransform: "uppercase" }}>
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </>
  );
}
