
  # Mobile Frontend Conversion

  This is a code bundle for Mobile Frontend Conversion. The original project is available at https://www.figma.com/design/k4ndWIs6uoyWUms3nC639T/Mobile-Frontend-Conversion.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  