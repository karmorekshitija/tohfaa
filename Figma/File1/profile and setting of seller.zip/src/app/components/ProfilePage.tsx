import { useState, useRef } from "react";
import { Drawer } from "vaul";
import {
  X, Camera, MapPin, Star, Shield, Zap, Leaf, Truck,
  Plus, Edit2, Trash2, Home, AlertTriangle, ChevronRight,
  Save, Info, CreditCard, Lock,
} from "lucide-react";
import { CheckCircle, AlertCircle } from "lucide-react";

const C = {
  primary: "#3D6B4F",
  gold: "#C8973A",
  sage: "#8FAF82",
  surface: "#FFFFFF",
  surfaceVariant: "#F7F3EC",
  surfaceContainer: "#f9ecdc",
  onSurface: "#211b11",
  onSurfaceVariant: "#414942",
  outlineVariant: "rgba(113,121,114,0.15)",
  outline: "rgba(113,121,114,0.3)",
};

// ── Types ─────────────────────────────────────────────────────────────────────
interface Address {
  id: string;
  label: string;
  address_line: string;
  city: string;
  state: string;
  pincode: string;
  phone?: string;
  is_default?: boolean;
}

type ProfileTab = "profile" | "settings";
type DrawerMode = "add-address" | "edit-address" | "close-account" | null;

// ── Mock data ─────────────────────────────────────────────────────────────────
const MOCK_PROFILE = {
  shop_name: "Aarav's Artisan Studio",
  handle: "aarav_crafts",
  location: "Jaipur, Rajasthan",
  bio: "Crafting handmade terracotta and jute goods since 2017. Each piece is made with love and traditional techniques.",
  email: "aarav.sharma@example.com",
  avatar_url: "https://ui-avatars.com/api/?name=Aarav+Sharma&background=a8b48e&color=fff&size=128",
  story_headline: "Where craft meets soul",
  story_description: "Born in the artisan lanes of Jaipur, every piece in this studio carries a story of tradition, patience, and craftsmanship passed down through generations.",
  working_on: "Working on a new terracotta series",
  badges: ["top_seller", "eco_friendly"],
  bank_account_holder: "Aarav Sharma",
  bank_name: "State Bank of India",
  bank_account_number: "1234****5678",
  ifsc_code: "SBIN0001234",
};

const MOCK_ADDRESSES: Address[] = [
  { id: "1", label: "Studio", address_line: "42, Craft Lane, Bapu Nagar", city: "Jaipur", state: "Rajasthan", pincode: "302015", phone: "+91 98765 43210", is_default: true },
  { id: "2", label: "Home", address_line: "7, Sindhi Colony", city: "Jaipur", state: "Rajasthan", pincode: "302001", phone: "+91 98765 43210" },
];

const MOCK_LIMITS = { daily: 50, weekly: 200, soldToday: 12, soldWeek: 67 };

const BADGE_OPTIONS = [
  { key: "top_seller",      label: "Top Seller",      Icon: Star },
  { key: "verified_crafts", label: "Verified Crafts",  Icon: Shield },
  { key: "fast_shipments",  label: "Fast Shipments",   Icon: Truck },
  { key: "eco_friendly",    label: "Eco-friendly",     Icon: Leaf },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function Toast({ msg, type }: { msg: string; type: "success" | "error" }) {
  return (
    <div
      style={{ background: type === "success" ? C.primary : "#FEE2E2", color: type === "success" ? "#fff" : "#991B1B" }}
      className="fixed top-4 left-4 right-4 z-[300] flex items-center gap-2 px-4 py-3 rounded-2xl shadow-lg text-sm font-medium max-w-[430px] mx-auto"
    >
      {type === "success" ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
      {msg}
    </div>
  );
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <label style={{ color: C.onSurfaceVariant, fontFamily: "'DM Sans', sans-serif" }}
           className="text-[10px] uppercase tracking-widest font-bold block mb-1.5">
      {children}
    </label>
  );
}

function FieldInput({ value, onChange, placeholder, type = "text", disabled }: {
  value: string; onChange: (v: string) => void; placeholder?: string; type?: string; disabled?: boolean;
}) {
  return (
    <input
      type={type}
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      disabled={disabled}
      style={{
        border: `1px solid ${C.outline}`,
        borderRadius: "0.625rem",
        color: C.onSurface,
        fontFamily: "'DM Sans', sans-serif",
        background: disabled ? C.surfaceVariant : C.surface,
      }}
      className="w-full px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-green-700/20 transition-all"
    />
  );
}

function SectionCard({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ background: C.surface, borderColor: C.outline }}
         className="mx-4 border rounded-2xl overflow-hidden shadow-sm">
      {children}
    </div>
  );
}

function SectionHeader({ icon: Icon, title }: { icon: React.ElementType; title: string }) {
  return (
    <div style={{ borderBottom: `1px solid ${C.outlineVariant}` }}
         className="flex items-center gap-2 px-4 py-4">
      <Icon size={18} color={C.primary} />
      <h2 style={{ color: C.onSurface, fontFamily: "'Playfair Display', serif" }}
          className="text-lg font-bold">{title}</h2>
    </div>
  );
}

function SaveButton({ label, onClick, saving }: { label: string; onClick: () => void; saving?: boolean }) {
  return (
    <div style={{ borderTop: `1px solid ${C.outlineVariant}` }} className="px-4 py-3">
      <button
        onClick={onClick}
        disabled={saving}
        style={{ background: C.primary }}
        className="w-full text-white font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2 active:opacity-80 disabled:opacity-60"
      >
        <Save size={15} />
        {saving ? "Saving…" : label}
      </button>
    </div>
  );
}

// ── Progress bar ──────────────────────────────────────────────────────────────
function ProgressBar({ value, max }: { value: number; max: number }) {
  const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  const color = pct > 80 ? "#D97706" : pct > 50 ? C.gold : C.primary;
  return (
    <div>
      <div className="flex justify-between mb-1">
        <span style={{ color: C.onSurfaceVariant }} className="text-xs">{value} / {max}</span>
        <span style={{ color }} className="text-xs font-bold">{pct}%</span>
      </div>
      <div style={{ background: C.surfaceVariant }} className="h-1.5 rounded-full overflow-hidden">
        <div style={{ width: `${pct}%`, background: color, transition: "width 0.6s ease" }}
             className="h-full rounded-full" />
      </div>
    </div>
  );
}

// ── AddressDrawer ─────────────────────────────────────────────────────────────
interface AddrForm { label: string; address_line: string; city: string; state: string; pincode: string; phone: string; is_default: boolean }
const EMPTY_ADDR: AddrForm = { label: "", address_line: "", city: "", state: "", pincode: "", phone: "", is_default: false };

function AddressDrawer({
  open, onClose, initial, onSave,
}: {
  open: boolean; onClose: () => void; initial: AddrForm | null; onSave: (f: AddrForm) => void;
}) {
  const [form, setForm] = useState<AddrForm>(initial ?? EMPTY_ADDR);
  const [errors, setErrors] = useState<Partial<AddrForm>>({});

  const set = (k: keyof AddrForm, v: string | boolean) =>
    setForm(prev => ({ ...prev, [k]: v }));

  function validate() {
    const e: Partial<AddrForm> = {};
    if (!form.label)        e.label = "Required";
    if (!form.address_line) e.address_line = "Required";
    if (!form.city)         e.city = "Required";
    if (!/^\d{6}$/.test(form.pincode)) e.pincode = "6-digit pincode";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function handleSave() {
    if (validate()) { onSave(form); onClose(); }
  }

  // Sync when initial changes
  useState(() => { setForm(initial ?? EMPTY_ADDR); setErrors({}); });

  return (
    <Drawer.Root open={open} onOpenChange={v => { if (!v) onClose(); }}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 z-50 bg-black/30" />
        <Drawer.Content style={{ background: C.surface }}
                        className="fixed bottom-0 left-0 right-0 z-50 max-h-[95dvh] rounded-t-3xl flex flex-col max-w-[430px] mx-auto">
          <div className="flex justify-center pt-3 pb-1">
            <div style={{ background: C.outlineVariant }} className="w-10 h-1 rounded-full" />
          </div>
          <div style={{ borderBottom: `1px solid ${C.outlineVariant}` }}
               className="flex items-center justify-between px-5 py-4">
            <h2 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
                className="text-xl font-bold italic">
              {initial?.label ? "Edit Address" : "Add New Address"}
            </h2>
            <button onClick={onClose} style={{ color: C.onSurfaceVariant }} className="p-2 rounded-full hover:bg-gray-100">
              <X size={20} />
            </button>
          </div>
          <div className="overflow-y-auto px-5 py-5 flex-1 space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <FieldLabel>Label</FieldLabel>
                <FieldInput value={form.label} onChange={v => set("label", v)} placeholder="Home, Studio…" />
                {errors.label && <p className="text-xs mt-1" style={{ color: "#DC2626" }}>{errors.label}</p>}
              </div>
              <div>
                <FieldLabel>Phone</FieldLabel>
                <FieldInput value={form.phone} onChange={v => set("phone", v)} placeholder="+91 9XXXXXXXX" type="tel" />
              </div>
            </div>
            <div>
              <FieldLabel>Address Line</FieldLabel>
              <FieldInput value={form.address_line} onChange={v => set("address_line", v)} placeholder="Street, building, area" />
              {errors.address_line && <p className="text-xs mt-1" style={{ color: "#DC2626" }}>{errors.address_line}</p>}
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-1">
                <FieldLabel>City</FieldLabel>
                <FieldInput value={form.city} onChange={v => set("city", v)} placeholder="City" />
                {errors.city && <p className="text-xs mt-1" style={{ color: "#DC2626" }}>{errors.city}</p>}
              </div>
              <div className="col-span-1">
                <FieldLabel>State</FieldLabel>
                <FieldInput value={form.state} onChange={v => set("state", v)} placeholder="State" />
              </div>
              <div className="col-span-1">
                <FieldLabel>Pincode</FieldLabel>
                <FieldInput value={form.pincode} onChange={v => set("pincode", v)} placeholder="000000" />
                {errors.pincode && <p className="text-xs mt-1" style={{ color: "#DC2626" }}>{errors.pincode}</p>}
              </div>
            </div>
            <label className="flex items-center gap-3 cursor-pointer">
              <input type="checkbox" checked={form.is_default} onChange={e => set("is_default", e.target.checked)}
                     className="w-4 h-4 rounded" style={{ accentColor: C.primary }} />
              <span style={{ color: C.onSurface }} className="text-sm">Set as default address</span>
            </label>
            <button onClick={handleSave} style={{ background: C.primary }}
                    className="w-full text-white font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2 active:opacity-80">
              <Save size={15} /> Save Address
            </button>
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

// ── CloseAccountDrawer ────────────────────────────────────────────────────────
function CloseAccountDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [text, setText] = useState("");
  const confirmed = text === "DELETE";
  return (
    <Drawer.Root open={open} onOpenChange={v => { if (!v) { onClose(); setText(""); } }}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 z-50 bg-black/30" />
        <Drawer.Content style={{ background: C.surface }}
                        className="fixed bottom-0 left-0 right-0 z-50 rounded-t-3xl flex flex-col max-w-[430px] mx-auto">
          <div className="flex justify-center pt-3 pb-1">
            <div style={{ background: C.outlineVariant }} className="w-10 h-1 rounded-full" />
          </div>
          <div className="px-5 py-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                <AlertTriangle size={20} color="#DC2626" />
              </div>
              <h2 style={{ fontFamily: "'Playfair Display', serif" }}
                  className="text-xl font-bold text-red-700">Close Seller Account</h2>
            </div>
            <p className="text-sm" style={{ color: C.onSurfaceVariant }}>
              This action is <strong style={{ color: C.onSurface }}>permanent and irreversible.</strong> All listings, orders, analytics, and data will be deleted.
            </p>
            <p className="text-sm" style={{ color: C.onSurfaceVariant }}>
              To confirm, type <code className="bg-red-50 text-red-700 px-1.5 py-0.5 rounded font-mono text-xs font-bold">DELETE</code> below:
            </p>
            <FieldInput value={text} onChange={setText} placeholder="Type DELETE to confirm" />
            <button
              disabled={!confirmed}
              onClick={() => { /* handle close account */ onClose(); setText(""); }}
              className="w-full text-white font-bold py-3 rounded-xl text-sm active:opacity-80 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{ background: "#DC2626" }}
            >
              Close My Account
            </button>
            <button onClick={() => { onClose(); setText(""); }}
                    style={{ color: C.onSurfaceVariant }} className="w-full text-sm text-center py-1">
              Cancel
            </button>
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

// ── Main ProfilePage ──────────────────────────────────────────────────────────
export function ProfilePage() {
  const [tab, setTab] = useState<ProfileTab>("profile");
  const [toast, setToast] = useState<{ msg: string; type: "success" | "error" } | null>(null);
  const [drawerMode, setDrawerMode] = useState<DrawerMode>(null);
  const [editingAddress, setEditingAddress] = useState<AddrForm | null>(null);

  // Profile state
  const [avatarSrc, setAvatarSrc] = useState(MOCK_PROFILE.avatar_url);
  const [shopName, setShopName] = useState(MOCK_PROFILE.shop_name);
  const [handle, setHandle] = useState(MOCK_PROFILE.handle);
  const [location, setLocation] = useState(MOCK_PROFILE.location);
  const [bio, setBio] = useState(MOCK_PROFILE.bio);
  const [activeBadges, setActiveBadges] = useState<Set<string>>(new Set(MOCK_PROFILE.badges));
  const [storyHeadline, setStoryHeadline] = useState(MOCK_PROFILE.story_headline);
  const [storyDesc, setStoryDesc] = useState(MOCK_PROFILE.story_description);
  const [workingOn, setWorkingOn] = useState(MOCK_PROFILE.working_on);
  const [videoUrl, setVideoUrl] = useState("");

  // Addresses state
  const [addresses, setAddresses] = useState<Address[]>(MOCK_ADDRESSES);

  // Settings state
  const [dailyLimit, setDailyLimit] = useState(String(MOCK_LIMITS.daily));
  const [weeklyLimit, setWeeklyLimit] = useState(String(MOCK_LIMITS.weekly));
  const [bankHolder, setBankHolder] = useState(MOCK_PROFILE.bank_account_holder);
  const [bankName, setBankName] = useState(MOCK_PROFILE.bank_name);
  const [bankAccount, setBankAccount] = useState(MOCK_PROFILE.bank_account_number);
  const [bankIfsc, setBankIfsc] = useState(MOCK_PROFILE.ifsc_code);
  const [passwordResetSent, setPasswordResetSent] = useState(false);

  const avatarInputRef = useRef<HTMLInputElement>(null);

  function showToast(msg: string, type: "success" | "error" = "success") {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3200);
  }

  function toggleBadge(key: string) {
    setActiveBadges(prev => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  }

  function handleAvatarChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setAvatarSrc(ev.target?.result as string);
    reader.readAsDataURL(file);
    showToast("Profile photo updated!");
  }

  function handleSaveBasicInfo() {
    if (!shopName.trim()) { showToast("Shop name is required.", "error"); return; }
    if (!handle.trim())   { showToast("Handle is required.", "error"); return; }
    showToast("Basic info saved!");
  }

  function handleSaveAbout() {
    showToast("About page saved!");
  }

  function handleSaveLimits() {
    const d = parseInt(dailyLimit); const w = parseInt(weeklyLimit);
    if (!d || d < 1) { showToast("Daily limit must be at least 1.", "error"); return; }
    if (!w || w < 1) { showToast("Weekly limit must be at least 1.", "error"); return; }
    if (w < d)       { showToast("Weekly limit must be ≥ daily limit.", "error"); return; }
    showToast("Capacity settings updated!");
  }

  function handleSaveBank() {
    if (!bankHolder || !bankName || !bankAccount || !bankIfsc) {
      showToast("All bank fields are required.", "error"); return;
    }
    showToast("Bank details updated successfully!");
  }

  function handleAddressOpen(addr?: Address) {
    if (addr) {
      setEditingAddress({ label: addr.label, address_line: addr.address_line, city: addr.city, state: addr.state, pincode: addr.pincode, phone: addr.phone || "", is_default: !!addr.is_default });
    } else {
      setEditingAddress(null);
    }
    setDrawerMode(addr ? "edit-address" : "add-address");
  }

  function handleAddressSave(form: AddrForm) {
    if (drawerMode === "edit-address" && editingAddress) {
      setAddresses(prev => prev.map((a, i) =>
        i === prev.findIndex(x => x.label === editingAddress.label && x.address_line === editingAddress.address_line)
          ? { ...a, ...form } : a
      ));
      showToast("Address updated!");
    } else {
      setAddresses(prev => [...prev, { id: String(Date.now()), ...form }]);
      showToast("Address added!");
    }
  }

  function handleDeleteAddress(id: string) {
    setAddresses(prev => prev.filter(a => a.id !== id));
    showToast("Address removed.");
  }

  const drawerOpen = drawerMode === "add-address" || drawerMode === "edit-address";

  return (
    <div style={{ background: "#FAF7F2", fontFamily: "'DM Sans', sans-serif" }}
         className="min-h-full flex flex-col">

      {toast && <Toast msg={toast.msg} type={toast.type} />}

      {/* Header */}
      <header style={{ background: C.surface, borderBottom: `1px solid ${C.outlineVariant}` }}
              className="sticky top-0 z-40 px-4 pt-10 pb-3">
        <p style={{ color: C.gold, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest font-bold">Seller Studio</p>
        <h1 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }} className="text-2xl italic font-bold mt-0.5">Profile & Settings</h1>
        <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5 opacity-70">Manage your profile, policies, and account</p>

        {/* Tab pills */}
        <div className="flex gap-2 mt-3">
          {(["profile", "settings"] as ProfileTab[]).map(t => (
            <button key={t} onClick={() => setTab(t)}
                    style={{
                      fontFamily: "'DM Sans', sans-serif",
                      background: tab === t ? C.primary : "transparent",
                      color: tab === t ? "#fff" : C.onSurfaceVariant,
                      border: `1px solid ${tab === t ? C.primary : "rgba(113,121,114,0.3)"}`,
                    }}
                    className="flex-shrink-0 text-sm font-semibold px-5 py-1.5 rounded-full transition-all capitalize">
              {t}
            </button>
          ))}
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto pb-6 pt-4 space-y-3">
        {tab === "profile" ? (
          <>
            {/* ── Basic Info ── */}
            <SectionCard>
              <SectionHeader icon={Camera} title="Basic Info" />
              <div className="p-4 space-y-4">
                {/* Avatar */}
                <div className="flex items-center gap-4">
                  <div className="relative flex-shrink-0 cursor-pointer" onClick={() => avatarInputRef.current?.click()}>
                    <img src={avatarSrc} alt="Avatar"
                         className="w-16 h-16 rounded-full object-cover border-2"
                         style={{ borderColor: C.sage }} />
                    <div style={{ background: C.primary }}
                         className="absolute -bottom-0.5 -right-0.5 p-1 rounded-full border-2 border-white">
                      <Camera size={10} color="#fff" />
                    </div>
                    <input ref={avatarInputRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p style={{ color: C.onSurface }} className="text-sm font-bold">{shopName}</p>
                    <p style={{ color: C.onSurfaceVariant }} className="text-xs">@{handle}</p>
                    <p style={{ color: C.onSurfaceVariant }} className="text-xs opacity-70">Tap avatar to change photo</p>
                  </div>
                </div>

                <div>
                  <FieldLabel>Shop Name</FieldLabel>
                  <FieldInput value={shopName} onChange={setShopName} placeholder="Your craft shop name" />
                </div>

                <div>
                  <FieldLabel>Username / Handle</FieldLabel>
                  <div className="flex items-center" style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem", overflow: "hidden" }}>
                    <span style={{ background: C.surfaceVariant, borderRight: `1px solid ${C.outline}`, color: C.onSurfaceVariant }}
                          className="px-3 py-2.5 text-sm font-medium select-none">@</span>
                    <input value={handle} onChange={e => setHandle(e.target.value)} placeholder="your_handle"
                           className="flex-1 px-3 py-2.5 text-sm focus:outline-none bg-white"
                           style={{ color: C.onSurface }} />
                  </div>
                </div>

                <div>
                  <FieldLabel>City / Location</FieldLabel>
                  <div className="relative">
                    <MapPin size={14} color={C.onSurfaceVariant} className="absolute left-3 top-1/2 -translate-y-1/2" />
                    <input value={location} onChange={e => setLocation(e.target.value)} placeholder="City, State"
                           style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem", color: C.onSurface }}
                           className="w-full pl-8 pr-3 py-2.5 text-sm focus:outline-none bg-white" />
                  </div>
                </div>

                <div>
                  <FieldLabel>Short Bio <span className="normal-case font-normal">(max 300)</span></FieldLabel>
                  <textarea rows={3} value={bio} onChange={e => setBio(e.target.value.slice(0, 300))}
                            placeholder="Tell buyers about yourself and your craft..."
                            style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem", color: C.onSurface, resize: "none" }}
                            className="w-full px-3 py-2.5 text-sm focus:outline-none bg-white" />
                  <p style={{ color: C.onSurfaceVariant }} className="text-[10px] text-right mt-0.5">{bio.length} / 300</p>
                </div>

                {/* Badges */}
                <div>
                  <FieldLabel>Seller Badges</FieldLabel>
                  <div className="flex flex-wrap gap-2">
                    {BADGE_OPTIONS.map(({ key, label, Icon }) => {
                      const on = activeBadges.has(key);
                      return (
                        <button key={key} onClick={() => toggleBadge(key)}
                                style={{
                                  background: on ? C.primary : C.surface,
                                  color: on ? "#fff" : C.onSurfaceVariant,
                                  border: `1.5px solid ${on ? C.primary : C.outline}`,
                                }}
                                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all">
                          <Icon size={12} />
                          {label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
              <SaveButton label="Save Basic Info" onClick={handleSaveBasicInfo} />
            </SectionCard>

            {/* ── About Page ── */}
            <SectionCard>
              <SectionHeader icon={Zap} title="About Page" />
              <div className="p-4 space-y-4">
                <div>
                  <FieldLabel>Story Headline</FieldLabel>
                  <FieldInput value={storyHeadline} onChange={setStoryHeadline} placeholder="A short, catchy headline…" />
                </div>
                <div>
                  <FieldLabel>Story Description <span className="normal-case font-normal">(max 1000)</span></FieldLabel>
                  <textarea rows={5} value={storyDesc} onChange={e => setStoryDesc(e.target.value.slice(0, 1000))}
                            placeholder="Share the story behind your craft…"
                            style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem", color: C.onSurface, resize: "none" }}
                            className="w-full px-3 py-2.5 text-sm focus:outline-none bg-white" />
                  <p style={{ color: C.onSurfaceVariant }} className="text-[10px] text-right mt-0.5">{storyDesc.length} / 1000</p>
                </div>
                <div>
                  <FieldLabel>Currently Working On</FieldLabel>
                  <FieldInput value={workingOn} onChange={setWorkingOn} placeholder="e.g. Working on a new pottery series" />
                </div>
                <div>
                  <FieldLabel>Workshop Video / Reel URL</FieldLabel>
                  <FieldInput value={videoUrl} onChange={setVideoUrl} placeholder="YouTube or Instagram URL" type="url" />
                  <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-1 opacity-70">Paste a YouTube or Instagram Reel URL</p>
                </div>
              </div>
              <SaveButton label="Save About Page" onClick={handleSaveAbout} />
            </SectionCard>

            {/* ── Addresses ── */}
            <SectionCard>
              <div style={{ borderBottom: `1px solid ${C.outlineVariant}` }}
                   className="flex items-center justify-between px-4 py-4">
                <div className="flex items-center gap-2">
                  <Home size={18} color={C.primary} />
                  <h2 style={{ color: C.onSurface, fontFamily: "'Playfair Display', serif" }}
                      className="text-lg font-bold">Addresses</h2>
                </div>
                <button onClick={() => handleAddressOpen()}
                        style={{ background: C.primary }}
                        className="flex items-center gap-1 text-white text-xs font-bold px-3 py-2 rounded-xl active:opacity-80">
                  <Plus size={14} /> Add
                </button>
              </div>
              <div className="p-4 space-y-3">
                {addresses.length === 0 ? (
                  <p style={{ color: C.onSurfaceVariant }} className="text-sm text-center py-6 opacity-60">No addresses saved yet.</p>
                ) : addresses.map(addr => (
                  <div key={addr.id} style={{ background: C.surfaceVariant, borderColor: C.outlineVariant }}
                       className="border rounded-xl p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span style={{ background: `${C.primary}18`, color: C.primary }}
                                className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full">
                            {addr.label}
                          </span>
                          {addr.is_default && (
                            <span style={{ background: C.primary, color: "#fff" }}
                                  className="text-[10px] font-bold px-2 py-0.5 rounded-full">Default</span>
                          )}
                        </div>
                        <p style={{ color: C.onSurface }} className="text-sm font-medium">{addr.address_line}</p>
                        <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5">{[addr.city, addr.state, addr.pincode].filter(Boolean).join(", ")}</p>
                        {addr.phone && <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5">{addr.phone}</p>}
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <button onClick={() => handleAddressOpen(addr)}
                                style={{ color: C.onSurfaceVariant }}
                                className="p-1.5 rounded-lg hover:bg-white transition-colors">
                          <Edit2 size={14} />
                        </button>
                        <button onClick={() => handleDeleteAddress(addr.id)}
                                className="p-1.5 rounded-lg hover:bg-red-50 transition-colors text-red-500">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>
          </>
        ) : (
          <>
            {/* ── Account & Security ── */}
            <SectionCard>
              <SectionHeader icon={Lock} title="Account & Security" />
              <div className="p-4 space-y-3">
                {/* Email */}
                <div style={{ background: C.surfaceVariant, borderColor: C.outlineVariant }}
                     className="border rounded-xl px-4 py-3">
                  <p style={{ color: C.onSurfaceVariant }} className="text-[10px] uppercase tracking-widest font-bold mb-1">Registered Email</p>
                  <div className="flex items-center justify-between gap-2">
                    <p style={{ color: C.onSurface }} className="text-sm font-semibold">{MOCK_PROFILE.email}</p>
                    <span className="flex items-center gap-1 bg-green-50 border border-green-200 px-2 py-0.5 rounded-full flex-shrink-0">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                      <span className="text-[10px] font-bold text-green-700">Verified</span>
                    </span>
                  </div>
                </div>

                {/* Password */}
                <div style={{ background: C.surfaceVariant, borderColor: C.outlineVariant }}
                     className="border rounded-xl px-4 py-3 flex items-center justify-between">
                  <div>
                    <p style={{ color: C.onSurfaceVariant }} className="text-[10px] uppercase tracking-widest font-bold mb-1">Account Password</p>
                    <p style={{ color: C.onSurfaceVariant }} className="text-lg tracking-widest select-none">•••••••••</p>
                    {passwordResetSent && (
                      <p style={{ color: C.primary }} className="text-xs font-semibold mt-1">✓ Reset link sent to your email</p>
                    )}
                  </div>
                  <button onClick={() => { setPasswordResetSent(true); showToast("Password reset link sent!"); setTimeout(() => setPasswordResetSent(false), 6000); }}
                          style={{ color: C.primary }}
                          className="text-xs font-bold uppercase tracking-wider flex-shrink-0 ml-4">
                    Reset
                  </button>
                </div>

                {/* Close Account */}
                <button onClick={() => setDrawerMode("close-account")}
                        style={{ background: "#FEF2F2", borderColor: "#FECACA" }}
                        className="w-full border rounded-xl px-4 py-3 flex items-center justify-between text-left group">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                      <AlertTriangle size={16} color="#DC2626" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-red-700">Close Seller Account</p>
                      <p style={{ color: C.onSurfaceVariant }} className="text-xs">Permanently delete your account and all data</p>
                    </div>
                  </div>
                  <ChevronRight size={18} color="#DC2626" />
                </button>
              </div>
            </SectionCard>

            {/* ── Selling Limits ── */}
            <SectionCard>
              <SectionHeader icon={Zap} title="Selling Limits" />
              <div className="p-4 space-y-4">
                <div style={{ background: C.surfaceVariant, borderColor: C.outlineVariant }}
                     className="border rounded-xl p-4">
                  <FieldLabel>Daily Limit (max orders/day)</FieldLabel>
                  <input type="number" min={1} value={dailyLimit} onChange={e => setDailyLimit(e.target.value)}
                         style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem", color: C.onSurface, fontFamily: "'Space Mono', monospace" }}
                         className="w-24 px-3 py-2 text-lg font-bold text-center focus:outline-none bg-white mb-3" />
                  <ProgressBar value={MOCK_LIMITS.soldToday} max={parseInt(dailyLimit) || MOCK_LIMITS.daily} />
                </div>
                <div style={{ background: C.surfaceVariant, borderColor: C.outlineVariant }}
                     className="border rounded-xl p-4">
                  <FieldLabel>Weekly Limit (max orders/week)</FieldLabel>
                  <input type="number" min={1} value={weeklyLimit} onChange={e => setWeeklyLimit(e.target.value)}
                         style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem", color: C.onSurface, fontFamily: "'Space Mono', monospace" }}
                         className="w-24 px-3 py-2 text-lg font-bold text-center focus:outline-none bg-white mb-3" />
                  <ProgressBar value={MOCK_LIMITS.soldWeek} max={parseInt(weeklyLimit) || MOCK_LIMITS.weekly} />
                </div>
                <div className="flex items-center gap-1.5">
                  <Info size={14} color={C.onSurfaceVariant} />
                  <p style={{ color: C.onSurfaceVariant }} className="text-xs">Weekly limit must be ≥ daily limit.</p>
                </div>
              </div>
              <SaveButton label="Save Limits" onClick={handleSaveLimits} />
            </SectionCard>

            {/* ── Bank Details ── */}
            <SectionCard>
              <SectionHeader icon={CreditCard} title="Bank Account Details" />
              <div className="p-4 space-y-4">
                <div>
                  <FieldLabel>Account Holder Name</FieldLabel>
                  <FieldInput value={bankHolder} onChange={setBankHolder} placeholder="e.g. Aarav Sharma" />
                </div>
                <div>
                  <FieldLabel>Bank Name</FieldLabel>
                  <FieldInput value={bankName} onChange={setBankName} placeholder="e.g. State Bank of India" />
                </div>
                <div>
                  <FieldLabel>Account Number</FieldLabel>
                  <FieldInput value={bankAccount} onChange={setBankAccount} placeholder="e.g. 123456789012" />
                </div>
                <div>
                  <FieldLabel>IFSC Code</FieldLabel>
                  <FieldInput value={bankIfsc} onChange={setBankIfsc} placeholder="e.g. SBIN0001234" />
                </div>
              </div>
              <SaveButton label="Save Bank Details" onClick={handleSaveBank} />
            </SectionCard>
          </>
        )}
      </main>

      {/* Address bottom drawer */}
      <AddressDrawer
        open={drawerOpen}
        onClose={() => setDrawerMode(null)}
        initial={editingAddress}
        onSave={handleAddressSave}
      />

      {/* Close account drawer */}
      <CloseAccountDrawer
        open={drawerMode === "close-account"}
        onClose={() => setDrawerMode(null)}
      />
    </div>
  );
}
