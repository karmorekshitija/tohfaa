import { useState, useRef, useEffect } from "react";

// ─── Types ────────────────────────────────────────────────────────────────────

type Filter = "all" | "overflow" | "custom";

interface Conversation {
  id: string;
  name: string;
  initials: string;
  avatarColor: string;
  lastMessage: string;
  time: string;
  unread: number;
  online: boolean;
  tag: "custom" | "overflow" | "inquiry";
  product: string;
}

interface Message {
  id: string;
  from: "buyer" | "seller";
  text: string;
  time: string;
  attachmentUrl?: string;
}

// ─── Sample Data ──────────────────────────────────────────────────────────────

const CONVERSATIONS: Conversation[] = [
  {
    id: "1",
    name: "Kavita Bhat",
    initials: "KB",
    avatarColor: "#8FAF82",
    lastMessage: "Can you ship before Diwali? Need it by Oct 18.",
    time: "2m",
    unread: 2,
    online: true,
    tag: "custom",
    product: "Hand-woven Silk Dupatta",
  },
  {
    id: "2",
    name: "Rohan Mehta",
    initials: "RM",
    avatarColor: "#C8973A",
    lastMessage: "The packaging was absolutely beautiful, thank you!",
    time: "1h",
    unread: 0,
    online: false,
    tag: "overflow",
    product: "Block-print Cotton Kurta",
  },
  {
    id: "3",
    name: "Priya Sharma",
    initials: "PS",
    avatarColor: "#3D6B4F",
    lastMessage: "Could I get a custom embroidery on the neckline?",
    time: "3h",
    unread: 1,
    online: true,
    tag: "custom",
    product: "Chikankari Anarkali Set",
  },
  {
    id: "4",
    name: "Ananya Iyer",
    initials: "AI",
    avatarColor: "#B06060",
    lastMessage: "Is this available in size XS? I couldn't see it listed.",
    time: "Yesterday",
    unread: 0,
    online: false,
    tag: "inquiry",
    product: "Indigo-dyed Linen Stole",
  },
  {
    id: "5",
    name: "Deepak Nair",
    initials: "DN",
    avatarColor: "#5B7FA6",
    lastMessage: "Order placed! Looking forward to receiving it.",
    time: "2 days",
    unread: 0,
    online: false,
    tag: "overflow",
    product: "Handmade Brass Dhokra Pendant",
  },
];

const MESSAGES_BY_CONV: Record<string, Message[]> = {
  "1": [
    { id: "m1", from: "buyer", text: "Hello! I saw your silk dupatta listing — it's gorgeous.", time: "10:02 AM" },
    { id: "m2", from: "seller", text: "Thank you so much! Each piece is hand-woven on a traditional pit loom. Happy to answer any questions.", time: "10:05 AM" },
    { id: "m3", from: "buyer", text: "Wonderful. I need it for a wedding on the 20th. Can you ship before Diwali? Need it by Oct 18.", time: "10:08 AM" },
    { id: "m4", from: "seller", text: "Yes, I can prioritise your order. I'll need 3–4 days to finish the border work, then express courier — should reach you by the 17th.", time: "10:11 AM" },
    { id: "m5", from: "buyer", text: "Perfect. Also, could you do a deep maroon instead of the crimson shown?", time: "10:13 AM" },
  ],
  "2": [
    { id: "m1", from: "buyer", text: "My kurta arrived today. The packaging was absolutely beautiful, thank you!", time: "Yesterday" },
    { id: "m2", from: "seller", text: "So glad it reached you safely! The hand-stamped tissue paper is our little signature touch.", time: "Yesterday" },
  ],
  "3": [
    { id: "m1", from: "buyer", text: "Could I get a custom embroidery on the neckline? Maybe a lotus motif?", time: "3h ago" },
    { id: "m2", from: "seller", text: "Absolutely — lotus embroidery in zari thread is one of our specialties. Let me prepare a custom offer for you.", time: "2h ago" },
  ],
  "4": [
    { id: "m1", from: "buyer", text: "Is this available in size XS? I couldn't see it listed.", time: "Yesterday" },
  ],
  "5": [
    { id: "m1", from: "buyer", text: "Order placed! Looking forward to receiving it.", time: "2 days ago" },
    { id: "m2", from: "seller", text: "Thank you, Deepak! Your pendant will be carefully bubble-wrapped and dispatched within 48 hours.", time: "2 days ago" },
  ],
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

const TAG_STYLES: Record<string, string> = {
  custom: "bg-[#EAF2EA] text-[#3D6B4F]",
  overflow: "bg-[#FDF6E8] text-[#C8973A]",
  inquiry: "bg-[#EEF2F7] text-[#5B7FA6]",
};

function Avatar({ initials, color, size = 40, online = false }: { initials: string; color: string; size?: number; online?: boolean }) {
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <div
        className="rounded-full flex items-center justify-center font-bold text-white"
        style={{ width: size, height: size, backgroundColor: color, fontFamily: "'Playfair Display', serif", fontSize: size * 0.35 }}
      >
        {initials}
      </div>
      {online && (
        <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-green-500 border-2 border-white" />
      )}
    </div>
  );
}

function PulsingDot() {
  return (
    <span
      className="inline-block w-2 h-2 rounded-full bg-green-500"
      style={{
        boxShadow: "0 0 0 0 rgba(34,197,94,0.7)",
        animation: "pulse-dot 1.8s infinite",
      }}
    />
  );
}

// ─── Screens ──────────────────────────────────────────────────────────────────

function InboxScreen({
  onSelectConv,
}: {
  onSelectConv: (c: Conversation) => void;
}) {
  const [filter, setFilter] = useState<Filter>("all");
  const [search, setSearch] = useState("");

  const filtered = CONVERSATIONS.filter((c) => {
    const matchesFilter = filter === "all" || c.tag === filter;
    const matchesSearch = c.name.toLowerCase().includes(search.toLowerCase()) || c.product.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="px-5 pt-12 pb-3 bg-card border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h1 style={{ fontFamily: "'Playfair Display', serif" }} className="text-2xl font-bold text-primary">
            Messages
          </h1>
          <button className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-muted text-primary transition-colors">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 20h9" /><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4 12.5-12.5z" />
            </svg>
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
          </svg>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 bg-muted rounded-xl border border-border text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-primary transition-all"
            placeholder="Search chats…"
          />
        </div>

        {/* Filter tabs */}
        <div className="flex gap-1">
          {(["all", "overflow", "custom"] as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`flex-1 py-1.5 text-[11px] font-bold rounded-lg transition-all capitalize tracking-wider ${
                filter === f
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Conversation list */}
      <div className="flex-1 overflow-y-auto">
        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center h-40 gap-2 text-muted-foreground">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg>
            <p className="text-xs">No conversations found</p>
          </div>
        )}
        {filtered.map((conv, i) => (
          <button
            key={conv.id}
            onClick={() => onSelectConv(conv)}
            className={`w-full flex items-center gap-3.5 px-5 py-4 text-left transition-colors active:bg-muted ${
              i < filtered.length - 1 ? "border-b border-border" : ""
            } hover:bg-muted/60 bg-card`}
          >
            <Avatar initials={conv.initials} color={conv.avatarColor} size={46} online={conv.online} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-0.5">
                <span
                  className="text-sm font-bold text-foreground truncate"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  {conv.name}
                </span>
                <span className="text-[10px] text-muted-foreground shrink-0 ml-2">{conv.time}</span>
              </div>
              <div className="flex items-center gap-1.5 mb-1">
                <span
                  className={`text-[9px] font-bold uppercase tracking-widest px-1.5 py-0.5 rounded-full ${TAG_STYLES[conv.tag]}`}
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  {conv.tag}
                </span>
                <span className="text-[10px] text-muted-foreground truncate">{conv.product}</span>
              </div>
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground truncate flex-1">{conv.lastMessage}</p>
                {conv.unread > 0 && (
                  <span className="ml-2 min-w-[18px] h-[18px] bg-primary text-primary-foreground rounded-full text-[10px] font-bold flex items-center justify-center px-1 shrink-0">
                    {conv.unread}
                  </span>
                )}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function ChatScreen({
  conv,
  onBack,
  onOpenOrder,
}: {
  conv: Conversation;
  onBack: () => void;
  onOpenOrder: () => void;
}) {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>(MESSAGES_BY_CONV[conv.id] || []);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  function sendMessage() {
    const text = input.trim();
    if (!text) return;
    setMessages((prev) => [
      ...prev,
      {
        id: `new-${Date.now()}`,
        from: "seller",
        text,
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      },
    ]);
    setInput("");
  }

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border px-4 pt-12 pb-3 shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-muted text-primary transition-colors shrink-0"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="m15 18-6-6 6-6" />
            </svg>
          </button>
          <Avatar initials={conv.initials} color={conv.avatarColor} size={38} online={conv.online} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h2
                className="text-base font-bold text-primary truncate"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                {conv.name}
              </h2>
              {conv.online && <PulsingDot />}
            </div>
            <p className="text-[10px] text-muted-foreground truncate">{conv.product}</p>
          </div>
          <button
            onClick={onOpenOrder}
            className="flex items-center gap-1 px-2.5 py-1.5 border border-primary text-primary rounded-lg text-[10px] font-bold transition-all active:bg-primary/5 shrink-0"
            style={{ fontFamily: "'Cinzel', serif" }}
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <polyline points="14,2 14,8 20,8" />
              <line x1="16" y1="13" x2="8" y2="13" />
              <line x1="16" y1="17" x2="8" y2="17" />
            </svg>
            <span>Order</span>
          </button>
        </div>
      </header>

      {/* Product context card */}
      <div className="mx-4 my-2 p-3 bg-card border border-[#C5D6BC] rounded-xl flex items-center gap-3 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-[#EAF2EA] flex items-center justify-center shrink-0">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#3D6B4F" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="3" width="20" height="14" rx="2" ry="2" /><line x1="8" y1="21" x2="16" y2="21" /><line x1="12" y1="17" x2="12" y2="21" />
          </svg>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest" style={{ fontFamily: "'Cinzel', serif" }}>Product Inquiry</p>
          <p className="text-xs text-primary font-medium truncate">{conv.product}</p>
        </div>
        <span className={`text-[9px] font-bold uppercase tracking-widest px-1.5 py-0.5 rounded-full ${TAG_STYLES[conv.tag]}`} style={{ fontFamily: "'Cinzel', serif" }}>
          {conv.tag}
        </span>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-2 space-y-4" style={{ paddingBottom: 8 }}>
        {messages.map((msg) => (
          <div key={msg.id} className={`flex w-full ${msg.from === "seller" ? "justify-end" : "justify-start"}`}>
            {msg.from === "buyer" && (
              <div className="mr-2 mt-auto">
                <Avatar initials={conv.initials} color={conv.avatarColor} size={28} />
              </div>
            )}
            <div className={`max-w-[72%] ${msg.from === "seller" ? "items-end" : "items-start"} flex flex-col gap-1`}>
              <div
                className={`px-3.5 py-2.5 text-sm leading-relaxed ${
                  msg.from === "seller"
                    ? "bg-primary text-primary-foreground rounded-[18px_18px_4px_18px]"
                    : "bg-card border border-[#C5D6BC] text-foreground rounded-[18px_18px_18px_4px]"
                }`}
                style={{ fontFamily: "'DM Sans', sans-serif" }}
              >
                {msg.text}
              </div>
              <span className="text-[10px] text-muted-foreground px-1">{msg.time}</span>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input bar */}
      <div className="bg-card border-t border-border px-4 py-3 shrink-0" style={{ paddingBottom: "calc(12px + env(safe-area-inset-bottom, 0px))" }}>
        <div className="flex items-center gap-2">
          <button className="w-9 h-9 flex items-center justify-center text-muted-foreground hover:text-primary rounded-xl hover:bg-muted transition-all shrink-0">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.47" />
            </svg>
          </button>
          <div className="flex-1 relative">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              rows={1}
              className="w-full pl-4 pr-10 py-2.5 bg-muted rounded-xl border border-border text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-primary resize-none transition-all"
              placeholder="Write a message…"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            />
            <button
              onClick={sendMessage}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 bg-primary text-primary-foreground rounded-lg flex items-center justify-center active:scale-95 transition-all"
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="22" y1="2" x2="11" y2="13" /><polygon points="22 2 15 22 11 13 2 9 22 2" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function CustomOrderSheet({ conv, onClose }: { conv: Conversation; onClose: () => void }) {
  const [productName, setProductName] = useState(conv.product);
  const [price, setPrice] = useState("");
  const [qty, setQty] = useState("1");
  const [date, setDate] = useState("");
  const [notes, setNotes] = useState("");
  const [expiry, setExpiry] = useState("48");
  const [sent, setSent] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" onClick={onClose} />

      {/* Sheet */}
      <div className="relative bg-card rounded-t-3xl overflow-hidden flex flex-col" style={{ maxHeight: "90vh" }}>
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-1 shrink-0">
          <div className="w-10 h-1 bg-border rounded-full" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-border shrink-0">
          <h3 className="text-lg font-bold text-primary" style={{ fontFamily: "'Playfair Display', serif" }}>
            Custom Order
          </h3>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center text-muted-foreground hover:text-foreground rounded-lg hover:bg-muted transition-all">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Form */}
        <div className="overflow-y-auto flex-1 px-6 py-4" style={{ paddingBottom: "calc(16px + env(safe-area-inset-bottom, 0px))" }}>
          {sent ? (
            <div className="flex flex-col items-center justify-center py-12 gap-4">
              <div className="w-14 h-14 rounded-full bg-[#EAF2EA] flex items-center justify-center">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#3D6B4F" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              </div>
              <h4 className="text-lg font-bold text-primary" style={{ fontFamily: "'Playfair Display', serif" }}>Offer Sent!</h4>
              <p className="text-xs text-muted-foreground text-center">Your custom offer has been sent to {conv.name}. You will be notified when they respond.</p>
              <button onClick={onClose} className="mt-2 px-6 py-2.5 bg-primary text-primary-foreground text-xs font-bold rounded-lg uppercase tracking-widest" style={{ fontFamily: "'Cinzel', serif" }}>
                Done
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-1" style={{ fontFamily: "'Cinzel', serif" }}>Product Name</label>
                <input
                  value={productName}
                  onChange={(e) => setProductName(e.target.value)}
                  required
                  className="w-full px-3 py-2.5 bg-muted border border-border rounded-xl text-sm text-foreground outline-none focus:ring-1 focus:ring-primary transition-all"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-1" style={{ fontFamily: "'Cinzel', serif" }}>Price ₹</label>
                  <input
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    type="number"
                    required
                    min="1"
                    placeholder="0"
                    className="w-full px-3 py-2.5 bg-muted border border-border rounded-xl text-sm text-foreground outline-none focus:ring-1 focus:ring-primary transition-all"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-1" style={{ fontFamily: "'Cinzel', serif" }}>Qty</label>
                  <input
                    value={qty}
                    onChange={(e) => setQty(e.target.value)}
                    type="number"
                    required
                    min="1"
                    className="w-full px-3 py-2.5 bg-muted border border-border rounded-xl text-sm text-foreground outline-none focus:ring-1 focus:ring-primary transition-all"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-1" style={{ fontFamily: "'Cinzel', serif" }}>Delivery Date</label>
                <input
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  type="date"
                  required
                  className="w-full px-3 py-2.5 bg-muted border border-border rounded-xl text-sm text-foreground outline-none focus:ring-1 focus:ring-primary transition-all"
                />
              </div>
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-[10px] font-bold text-muted-foreground uppercase tracking-widest" style={{ fontFamily: "'Cinzel', serif" }}>Custom Notes</label>
                  <span className="text-[10px] text-muted-foreground">{notes.length}/300</span>
                </div>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value.slice(0, 300))}
                  rows={3}
                  placeholder="Add personalization requirements…"
                  className="w-full px-3 py-2.5 bg-muted border border-border rounded-xl text-sm text-foreground outline-none focus:ring-1 focus:ring-primary resize-none transition-all"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-1" style={{ fontFamily: "'Cinzel', serif" }}>Offer Expiry</label>
                <select
                  value={expiry}
                  onChange={(e) => setExpiry(e.target.value)}
                  className="w-full px-3 py-2.5 bg-muted border border-border rounded-xl text-sm text-foreground outline-none focus:ring-1 focus:ring-primary transition-all"
                >
                  <option value="24">24 Hours</option>
                  <option value="48">48 Hours</option>
                  <option value="72">72 Hours</option>
                </select>
              </div>
              <button
                type="submit"
                className="w-full py-3.5 bg-primary text-primary-foreground text-xs font-bold rounded-xl uppercase tracking-widest transition-all active:scale-[0.98] mt-2"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                Send Offer
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [activeConv, setActiveConv] = useState<Conversation | null>(null);
  const [showOrder, setShowOrder] = useState(false);

  return (
    <>
      <style>{`
        @keyframes pulse-dot {
          0%   { box-shadow: 0 0 0 0 rgba(34,197,94,0.7); transform: scale(0.95); }
          70%  { box-shadow: 0 0 0 6px rgba(34,197,94,0); transform: scale(1); }
          100% { box-shadow: 0 0 0 0 rgba(34,197,94,0); transform: scale(0.95); }
        }
        * { -webkit-tap-highlight-color: transparent; }
        ::-webkit-scrollbar { display: none; }
      `}</style>

      {/* Phone frame */}
      <div className="min-h-screen bg-[#2C3E35] flex items-center justify-center p-6">
        <div
          className="relative bg-background overflow-hidden flex flex-col"
          style={{
            width: 390,
            height: 844,
            borderRadius: 44,
            boxShadow: "0 0 0 10px #1a2520, 0 30px 80px rgba(0,0,0,0.5)",
          }}
        >
          {/* Status bar */}
          <div className="flex items-center justify-between px-8 pt-3 pb-0 shrink-0 bg-card z-10">
            <span className="text-[12px] font-bold text-foreground" style={{ fontFamily: "'DM Sans', sans-serif" }}>9:41</span>
            <div className="w-[120px] h-[30px] bg-foreground rounded-full mx-auto" style={{ marginTop: -2 }} />
            <div className="flex items-center gap-1.5">
              <svg width="15" height="11" viewBox="0 0 15 11" fill="currentColor" className="text-foreground"><rect x="0" y="4" width="3" height="7" rx="0.5"/><rect x="4" y="2.5" width="3" height="8.5" rx="0.5"/><rect x="8" y="1" width="3" height="10" rx="0.5"/><rect x="12" y="0" width="3" height="11" rx="0.5" opacity="0.3"/></svg>
              <svg width="15" height="12" viewBox="0 0 24 24" fill="currentColor" className="text-foreground"><path d="M1.5 8.5a13 13 0 0 1 21 0M5 12a10 10 0 0 1 14 0M8.5 15.5a6 6 0 0 1 7 0M12 19h.01" strokeWidth="1.5" stroke="none"/></svg>
              <svg width="23" height="12" viewBox="0 0 23 12" className="text-foreground" fill="none"><rect x="0.5" y="0.5" width="20" height="11" rx="3.5" stroke="currentColor" strokeOpacity="0.35"/><rect x="1.5" y="1.5" width="17" height="9" rx="2.5" fill="currentColor"/><path d="M21.5 4v4a2.5 2.5 0 0 0 0-4z" fill="currentColor" fillOpacity="0.4"/></svg>
            </div>
          </div>

          {/* Main content */}
          <div className="flex-1 overflow-hidden relative">
            {/* Inbox */}
            <div
              className="absolute inset-0 transition-transform duration-300"
              style={{ transform: activeConv ? "translateX(-100%)" : "translateX(0)" }}
            >
              <InboxScreen onSelectConv={(c) => setActiveConv(c)} />
            </div>

            {/* Chat */}
            <div
              className="absolute inset-0 transition-transform duration-300"
              style={{ transform: activeConv ? "translateX(0)" : "translateX(100%)" }}
            >
              {activeConv && (
                <ChatScreen
                  conv={activeConv}
                  onBack={() => setActiveConv(null)}
                  onOpenOrder={() => setShowOrder(true)}
                />
              )}
            </div>
          </div>

          {/* Home indicator */}
          <div className="flex justify-center py-2 bg-card shrink-0">
            <div className="w-32 h-1 bg-foreground/20 rounded-full" />
          </div>
        </div>
      </div>

      {/* Custom Order Sheet — rendered outside phone frame overlay for correct stacking */}
      {showOrder && activeConv && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <div className="w-full max-w-[390px] mx-auto">
            <CustomOrderSheet conv={activeConv} onClose={() => setShowOrder(false)} />
          </div>
        </div>
      )}
    </>
  );
}
