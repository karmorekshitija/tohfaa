import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Search, X, Download, Filter, ChevronDown, Check,
  Package, Truck, ShoppingBag, AlertCircle, Clock,
  MessageCircle, ChevronRight, ArrowLeft, MoreVertical,
  Bell, LayoutGrid, ClipboardList, BarChart2, User,
  MapPin, Calendar, Hash, Tag, FileText, Send,
  CheckCircle2, XCircle, Loader2, Leaf
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

type Status = "pending" | "crafting" | "shipped" | "delivered" | "cancelled";

interface Order {
  id: string;
  orderId: string;
  date: string;
  buyer: string;
  phone?: string;
  address: string;
  product: string;
  productId: string;
  variant?: string;
  qty: number;
  amountPaise: number;
  status: Status;
  trackingNumber?: string;
  courier?: string;
  deadline?: string;
  estDelivery?: string;
  notes: string[];
  customization?: string;
  timeline: { label: string; date?: string; done: boolean; active: boolean }[];
}

// ─── Mock Data ────────────────────────────────────────────────────────────────

const MOCK_ORDERS: Order[] = [
  {
    id: "1", orderId: "TF-8821", date: "2025-06-10",
    buyer: "Priya Mehta", phone: "+91 98200 11234",
    address: "14 Rose Garden Lane, Bandra West, Mumbai 400050",
    product: "Pressed Wildflower Resin Frame — A4", productId: "PRD-441",
    variant: "Ivory Mount", qty: 2, amountPaise: 349800, status: "crafting",
    deadline: "2025-06-16", estDelivery: "2025-06-22",
    notes: ["Buyer requested no visible air bubbles", "Gift wrap requested"],
    customization: "\"Eternal Garden\" engraved on the back frame",
    timeline: [
      { label: "Order Placed", date: "Jun 10", done: true, active: false },
      { label: "Processing", date: "Jun 11", done: true, active: false },
      { label: "Crafting", done: false, active: true },
      { label: "Packed / QC", done: false, active: false },
      { label: "Dispatched", done: false, active: false },
      { label: "Delivered", done: false, active: false },
    ]
  },
  {
    id: "2", orderId: "TF-8819", date: "2025-06-09",
    buyer: "Rohan Verma", phone: "+91 97300 55678",
    address: "7C, Indira Nagar, Block 3, Bengaluru 560038",
    product: "Dried Botanicals Gift Hamper — Medium", productId: "PRD-312",
    qty: 1, amountPaise: 149900, status: "pending",
    deadline: "2025-06-14", notes: [],
    timeline: [
      { label: "Order Placed", date: "Jun 9", done: true, active: false },
      { label: "Processing", done: false, active: true },
      { label: "Crafting", done: false, active: false },
      { label: "Packed / QC", done: false, active: false },
      { label: "Dispatched", done: false, active: false },
      { label: "Delivered", done: false, active: false },
    ]
  },
  {
    id: "3", orderId: "TF-8815", date: "2025-06-07",
    buyer: "Ananya Sharma", phone: "+91 99400 88901",
    address: "Plot 22, Sector 14, Gurugram, Haryana 122001",
    product: "Lavender & Eucalyptus Wreath — 30cm", productId: "PRD-289",
    variant: "Natural Hoop", qty: 1, amountPaise: 220000, status: "shipped",
    trackingNumber: "DL900412993IN", courier: "Delhivery",
    deadline: "2025-06-12", estDelivery: "2025-06-18",
    notes: ["Fragile — handle with care sticker applied"],
    timeline: [
      { label: "Order Placed", date: "Jun 7", done: true, active: false },
      { label: "Processing", date: "Jun 8", done: true, active: false },
      { label: "Crafting", date: "Jun 9", done: true, active: false },
      { label: "Packed / QC", date: "Jun 10", done: true, active: false },
      { label: "Dispatched", date: "Jun 11", done: false, active: true },
      { label: "Delivered", done: false, active: false },
    ]
  },
  {
    id: "4", orderId: "TF-8802", date: "2025-06-03",
    buyer: "Kavita Nair", phone: "+91 90100 22345",
    address: "Flat 8, Thevara Ferry Road, Kochi 682013",
    product: "Vintage Botanica Print Set — 3pc", productId: "PRD-178",
    qty: 1, amountPaise: 89900, status: "delivered",
    trackingNumber: "SHP81923A", courier: "Shiprocket",
    deadline: "2025-06-08", estDelivery: "2025-06-15",
    notes: [],
    timeline: [
      { label: "Order Placed", date: "Jun 3", done: true, active: false },
      { label: "Processing", date: "Jun 4", done: true, active: false },
      { label: "Crafting", date: "Jun 5", done: true, active: false },
      { label: "Packed / QC", date: "Jun 6", done: true, active: false },
      { label: "Dispatched", date: "Jun 7", done: true, active: false },
      { label: "Delivered", date: "Jun 14", done: true, active: false },
    ]
  },
  {
    id: "5", orderId: "TF-8798", date: "2025-06-01",
    buyer: "Deepak Iyer", phone: "+91 86600 44567",
    address: "No. 3, Adyar Bridge Road, Chennai 600020",
    product: "Custom Pressed Flower Pendant — Gold", productId: "PRD-510",
    qty: 1, amountPaise: 399900, status: "cancelled",
    deadline: "2025-06-07", notes: ["Buyer cancelled — out of stock variant"],
    timeline: [
      { label: "Order Placed", date: "Jun 1", done: true, active: false },
      { label: "Processing", done: false, active: false },
      { label: "Crafting", done: false, active: false },
      { label: "Packed / QC", done: false, active: false },
      { label: "Dispatched", done: false, active: false },
      { label: "Delivered", done: false, active: false },
    ]
  },
];

const KPI = {
  total: 24, pending: 5, onTime: "91%", avgDispatch: "2.3d"
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

const fmt = (p: number) =>
  "₹" + (p / 100).toLocaleString("en-IN", { maximumFractionDigits: 0 });

const fmtDate = (s?: string) =>
  s ? new Date(s).toLocaleDateString("en-IN", { day: "numeric", month: "short" }) : "—";

const STATUS_META: Record<Status, { label: string; bg: string; text: string; dot: string }> = {
  pending:   { label: "Pending",   bg: "bg-amber-50",   text: "text-amber-700",  dot: "bg-amber-400" },
  crafting:  { label: "Crafting",  bg: "bg-green-50",   text: "text-green-700",  dot: "bg-green-500" },
  shipped:   { label: "Shipped",   bg: "bg-violet-50",  text: "text-violet-700", dot: "bg-violet-500" },
  delivered: { label: "Delivered", bg: "bg-teal-50",    text: "text-teal-700",   dot: "bg-teal-500" },
  cancelled: { label: "Cancelled", bg: "bg-red-50",     text: "text-red-600",    dot: "bg-red-400" },
};

const TAB_LABELS: { key: string; label: string }[] = [
  { key: "all", label: "All" },
  { key: "pending", label: "Pending" },
  { key: "crafting", label: "Crafting" },
  { key: "shipped", label: "Shipped" },
  { key: "delivered", label: "Delivered" },
  { key: "cancelled", label: "Cancelled" },
];

// ─── Status Badge ─────────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: Status }) {
  const m = STATUS_META[status];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${m.bg} ${m.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${m.dot}`} />
      {m.label}
    </span>
  );
}

// ─── Order Card ───────────────────────────────────────────────────────────────

function OrderCard({ order, onTap }: { order: Order; onTap: () => void }) {
  return (
    <motion.button
      onClick={onTap}
      whileTap={{ scale: 0.985 }}
      className="w-full text-left bg-white rounded-2xl border border-green-100 shadow-sm p-4 flex flex-col gap-3 active:shadow-none transition-shadow"
    >
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-bold text-[#3D6B4F] text-sm" style={{ fontFamily: "'Playfair Display', serif" }}>
            {order.product}
          </p>
          <p className="text-[10px] mt-0.5 font-mono text-[#C8973A]">#{order.productId}</p>
        </div>
        <StatusBadge status={order.status} />
      </div>

      <div className="flex items-center gap-4 text-xs text-[#717972]">
        <span className="flex items-center gap-1">
          <Hash size={11} />
          <span className="font-mono">{order.orderId}</span>
        </span>
        <span className="flex items-center gap-1">
          <User size={11} />
          {order.buyer}
        </span>
        <span className="flex items-center gap-1">
          <Calendar size={11} />
          {fmtDate(order.date)}
        </span>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1 text-xs text-[#717972]">
          <Package size={11} />
          <span>Qty {order.qty}</span>
          {order.deadline && (
            <>
              <span className="mx-1.5 text-green-200">·</span>
              <Clock size={11} className="text-amber-500" />
              <span className="text-amber-600 font-medium">Due {fmtDate(order.deadline)}</span>
            </>
          )}
        </div>
        <p className="font-bold text-[#3D6B4F] text-sm font-mono">{fmt(order.amountPaise)}</p>
      </div>
    </motion.button>
  );
}

// ─── Tracking Modal ───────────────────────────────────────────────────────────

function TrackingModal({ onClose, onConfirm }: { onClose: () => void; onConfirm: (data: { courier: string; trackingNumber: string; estDelivery: string }) => void }) {
  const [courier, setCourier] = useState("");
  const [trackingNumber, setTrackingNumber] = useState("");
  const [estDelivery, setEstDelivery] = useState("");
  const today = new Date().toISOString().split("T")[0];

  return (
    <motion.div
      className="fixed inset-0 z-[200] flex items-end bg-black/40"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className="w-full bg-white rounded-t-3xl p-6 pb-8 flex flex-col gap-5"
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 30, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-10 h-1 rounded-full bg-green-200 mx-auto" />
        <div>
          <h3 className="text-xl font-bold italic text-[#3D6B4F]" style={{ fontFamily: "'Playfair Display', serif" }}>
            Ship Sub-order
          </h3>
          <p className="text-xs text-[#717972] mt-0.5">Enter courier details to mark as shipped</p>
        </div>

        <div className="flex flex-col gap-4">
          <div>
            <label className="block text-[10px] uppercase tracking-widest font-bold text-[#717972] mb-1.5">Courier</label>
            <select
              value={courier}
              onChange={(e) => setCourier(e.target.value)}
              className="w-full bg-[#fff2e1] border border-green-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-[#3D6B4F]"
            >
              <option value="" disabled>Select Courier</option>
              {["Delhivery", "Shiprocket", "BlueDart", "DTDC", "Other"].map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-[10px] uppercase tracking-widest font-bold text-[#717972] mb-1.5">Tracking Number</label>
            <input
              type="text"
              value={trackingNumber}
              onChange={(e) => setTrackingNumber(e.target.value)}
              placeholder="e.g. DL900412993IN"
              className="w-full bg-[#fff2e1] border border-green-200 rounded-xl px-3 py-2.5 text-sm font-mono focus:outline-none focus:ring-1 focus:ring-[#3D6B4F]"
            />
          </div>
          <div>
            <label className="block text-[10px] uppercase tracking-widest font-bold text-[#717972] mb-1.5">Expected Delivery</label>
            <input
              type="date"
              min={today}
              value={estDelivery}
              onChange={(e) => setEstDelivery(e.target.value)}
              className="w-full bg-[#fff2e1] border border-green-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-[#3D6B4F]"
            />
          </div>
        </div>

        <div className="flex gap-3 mt-1">
          <button
            onClick={onClose}
            className="flex-1 py-3 border border-green-200 text-[#3D6B4F] font-bold text-sm rounded-xl active:bg-green-50"
          >
            Cancel
          </button>
          <button
            onClick={() => { if (courier && trackingNumber && estDelivery) onConfirm({ courier, trackingNumber, estDelivery }); }}
            className="flex-1 py-3 bg-[#3D6B4F] text-white font-bold text-sm rounded-xl active:opacity-90 disabled:opacity-50"
            disabled={!courier || !trackingNumber || !estDelivery}
          >
            Confirm Shipment
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ─── Order Detail Sheet ───────────────────────────────────────────────────────

function OrderDetailSheet({
  order,
  onClose,
}: {
  order: Order;
  onClose: () => void;
}) {
  const [showTracking, setShowTracking] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState(order.status);
  const [note, setNote] = useState("");
  const [saved, setSaved] = useState(false);

  const handleStatusChange = (s: Status) => {
    if (s === "shipped") { setShowTracking(true); return; }
    setSelectedStatus(s);
  };

  return (
    <>
      <motion.div
        className="fixed inset-0 z-[100] flex flex-col bg-[#faf7f2]"
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ type: "spring", damping: 32, stiffness: 280 }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-12 pb-4 bg-white border-b border-green-100">
          <button onClick={onClose} className="p-2 -ml-2 rounded-xl active:bg-green-50">
            <ArrowLeft size={20} className="text-[#3D6B4F]" />
          </button>
          <div className="text-center">
            <p className="text-[10px] uppercase tracking-widest font-bold text-[#C8973A]">Detail View</p>
            <h2 className="text-base font-bold text-[#3D6B4F]" style={{ fontFamily: "'Playfair Display', serif" }}>
              Order #{order.orderId}
            </h2>
          </div>
          <button className="p-2 -mr-2 rounded-xl active:bg-green-50">
            <MoreVertical size={20} className="text-[#717972]" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto pb-28">
          {/* Status + Amounts */}
          <div className="mx-4 mt-4 bg-white rounded-2xl border border-green-100 p-4 flex items-center justify-between shadow-sm">
            <div>
              <StatusBadge status={selectedStatus} />
              <p className="text-2xl font-bold text-[#3D6B4F] mt-2 font-mono">{fmt(order.amountPaise)}</p>
              <p className="text-xs text-[#717972] mt-0.5">Qty: {order.qty} · {fmtDate(order.date)}</p>
            </div>
            <div className="w-14 h-14 rounded-2xl bg-[#f3e6d6] flex items-center justify-center">
              <Leaf size={24} className="text-[#3D6B4F]" />
            </div>
          </div>

          {/* Product */}
          <Section title="Product">
            <div className="flex flex-col gap-1">
              <p className="font-bold text-[#3D6B4F] text-sm leading-snug" style={{ fontFamily: "'Playfair Display', serif" }}>{order.product}</p>
              <p className="text-[10px] font-mono text-[#C8973A]">#{order.productId}</p>
              {order.variant && <p className="text-xs text-[#717972]">Variant: {order.variant}</p>}
              {order.customization && (
                <div className="mt-2 bg-[#f9ecdc] rounded-xl p-3 border border-[#8FAF82]/30">
                  <p className="text-[10px] uppercase tracking-widest font-bold text-[#8FAF82] mb-1">Customization</p>
                  <p className="text-xs italic text-[#414942] leading-relaxed">"{order.customization}"</p>
                </div>
              )}
            </div>
          </Section>

          {/* Buyer */}
          <Section title="Patron">
            <div className="flex flex-col gap-1.5">
              <p className="font-bold text-sm">{order.buyer}</p>
              {order.phone && <p className="text-xs font-mono text-[#717972]">{order.phone}</p>}
              <div className="flex items-start gap-1.5 mt-0.5">
                <MapPin size={12} className="text-[#8FAF82] mt-0.5 flex-shrink-0" />
                <p className="text-xs text-[#717972] leading-relaxed">{order.address}</p>
              </div>
            </div>
          </Section>

          {/* Dates */}
          <Section title="Dates">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-[#fff2e1] rounded-xl p-3">
                <p className="text-[9px] uppercase tracking-widest font-bold text-[#717972]">Pickup Deadline</p>
                <p className="text-sm font-bold text-[#C8973A] mt-1 font-mono">{fmtDate(order.deadline)}</p>
              </div>
              <div className="bg-[#f3e6d6] rounded-xl p-3">
                <p className="text-[9px] uppercase tracking-widest font-bold text-[#717972]">Est. Delivery</p>
                <p className="text-sm font-bold text-[#3D6B4F] mt-1 font-mono">{fmtDate(order.estDelivery)}</p>
              </div>
            </div>
          </Section>

          {/* Timeline */}
          <Section title="Delivery Journey">
            <div className="flex flex-col">
              {order.timeline.map((step, i) => (
                <div key={i} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-[10px] font-bold border-2 ${
                      step.done ? "bg-[#3D6B4F] border-[#3D6B4F] text-white" :
                      step.active ? "bg-[#C8973A] border-[#C8973A] text-white" :
                      "bg-white border-gray-200 text-gray-400"
                    }`}>
                      {step.done ? <Check size={12} /> : i + 1}
                    </div>
                    {i < order.timeline.length - 1 && (
                      <div className={`w-0.5 h-5 my-0.5 ${step.done ? "bg-[#3D6B4F]/30" : "bg-gray-100"}`} />
                    )}
                  </div>
                  <div className="pb-4">
                    <p className={`text-xs font-semibold ${step.done || step.active ? "text-[#211b11]" : "text-gray-300"}`}>
                      {step.label}
                    </p>
                    {step.date && <p className="text-[10px] text-[#717972]">{step.date}</p>}
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* Tracking */}
          {order.trackingNumber && (
            <Section title="Tracking">
              <div className="flex items-center gap-2 bg-violet-50 rounded-xl p-3">
                <Truck size={16} className="text-violet-600 flex-shrink-0" />
                <div>
                  <p className="text-[10px] text-violet-500 uppercase tracking-widest font-bold">{order.courier}</p>
                  <p className="text-sm font-mono font-bold text-violet-700 select-all">{order.trackingNumber}</p>
                </div>
              </div>
            </Section>
          )}

          {/* Quick Actions */}
          <Section title="Quick Actions">
            <div className="grid grid-cols-2 gap-2">
              {(["pending", "crafting", "shipped", "delivered"] as Status[]).map(s => (
                <button
                  key={s}
                  onClick={() => handleStatusChange(s)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                    selectedStatus === s
                      ? "bg-[#3D6B4F] text-white border-[#3D6B4F]"
                      : "bg-white text-[#3D6B4F] border-green-200 active:bg-green-50"
                  }`}
                >
                  {STATUS_META[s].label}
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowTracking(true)}
              className="w-full mt-2 flex items-center justify-center gap-2 py-2.5 bg-[#8FAF82]/20 text-[#3D6B4F] font-bold text-xs rounded-xl border border-[#8FAF82]/40 active:opacity-80"
            >
              <Truck size={14} />
              Add / Update Tracking
            </button>
          </Section>

          {/* Chat with Buyer */}
          <Section title="">
            <button className="w-full flex items-center justify-center gap-2 py-3 border-2 border-[#3D6B4F] text-[#3D6B4F] font-bold text-sm rounded-xl active:bg-green-50">
              <MessageCircle size={16} />
              Chat with Buyer
            </button>
          </Section>

          {/* Studio Notes */}
          <Section title="Studio Notes">
            <div className="flex flex-col gap-2">
              {order.notes.map((n, i) => (
                <div key={i} className="bg-[#f9ecdc] rounded-xl p-3 border border-[#8FAF82]/20">
                  <p className="text-xs text-[#414942] leading-relaxed">{n}</p>
                </div>
              ))}
              <div className="mt-1">
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Add a studio note..."
                  rows={2}
                  className="w-full bg-white border border-green-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-[#3D6B4F] resize-none"
                />
                <button
                  onClick={() => { if (note.trim()) { setSaved(true); setNote(""); setTimeout(() => setSaved(false), 2000); }}}
                  className="mt-2 flex items-center gap-1.5 bg-[#3D6B4F] text-white text-xs font-bold px-4 py-2 rounded-xl active:opacity-90"
                >
                  {saved ? <><CheckCircle2 size={12} /> Saved!</> : <><Send size={12} /> Save Note</>}
                </button>
              </div>
            </div>
          </Section>
        </div>
      </motion.div>

      <AnimatePresence>
        {showTracking && (
          <TrackingModal
            onClose={() => setShowTracking(false)}
            onConfirm={() => { setShowTracking(false); setSelectedStatus("shipped"); }}
          />
        )}
      </AnimatePresence>
    </>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mx-4 mt-3 bg-white rounded-2xl border border-green-100 p-4 shadow-sm">
      {title && (
        <p className="text-[9px] uppercase tracking-widest font-bold text-[#717972] mb-3">{title}</p>
      )}
      {children}
    </div>
  );
}

// ─── Search Bar ───────────────────────────────────────────────────────────────

function SearchBar({ value, onChange, onClose }: { value: string; onChange: (v: string) => void; onClose: () => void }) {
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => { ref.current?.focus(); }, []);
  return (
    <motion.div
      className="flex items-center gap-2 bg-white border border-green-200 rounded-2xl px-3 py-2.5 shadow-sm mx-4"
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <Search size={16} className="text-[#8FAF82] flex-shrink-0" />
      <input
        ref={ref}
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search orders, buyers..."
        className="flex-1 text-sm bg-transparent outline-none text-[#211b11] placeholder-[#aaa]"
      />
      <button onClick={onClose} className="text-[#717972]">
        <X size={16} />
      </button>
    </motion.div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [activeTab, setActiveTab] = useState("all");
  const [activeNav, setActiveNav] = useState("orders");
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [period, setPeriod] = useState("30d");
  const [periodOpen, setPeriodOpen] = useState(false);
  const tabsRef = useRef<HTMLDivElement>(null);

  const filtered = MOCK_ORDERS.filter(o => {
    if (activeTab !== "all" && o.status !== activeTab) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return o.buyer.toLowerCase().includes(q) ||
        o.orderId.toLowerCase().includes(q) ||
        o.product.toLowerCase().includes(q);
    }
    return true;
  });

  const PERIOD_LABELS: Record<string, string> = {
    "7d": "Last 7 Days", "30d": "Last 30 Days", "90d": "Last 90 Days", "all": "All Time"
  };

  const NAV = [
    { key: "orders", icon: ClipboardList, label: "Orders" },
    { key: "messages", icon: MessageCircle, label: "Messages" },
    { key: "analytics", icon: BarChart2, label: "Analytics" },
    { key: "profile", icon: User, label: "Profile" },
  ];

  return (
    <div className="min-h-screen bg-[#faf7f2] flex flex-col" style={{ fontFamily: "'DM Sans', sans-serif" }}>

      {/* Decorative background blobs */}
      <div className="fixed top-0 right-0 w-48 h-48 rounded-full bg-[#8FAF82]/5 blur-3xl pointer-events-none" />
      <div className="fixed bottom-32 left-0 w-64 h-64 rounded-full bg-[#C8973A]/5 blur-3xl pointer-events-none" />

      {/* ── Top Bar ── */}
      <div className="sticky top-0 z-40 bg-[#faf7f2]/95 backdrop-blur-sm pt-12 pb-3">
        <div className="flex items-center justify-between px-5 mb-3">
          <div>
            <p className="text-[10px] uppercase tracking-widest font-bold text-[#C8973A]">TOFA Seller Studio</p>
            <h1 className="text-2xl font-bold italic text-[#3D6B4F]" style={{ fontFamily: "'Playfair Display', serif" }}>
              Order Queue
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => { setSearchOpen(true); }}
              className="w-9 h-9 flex items-center justify-center bg-white rounded-xl border border-green-100 shadow-sm active:bg-green-50"
            >
              <Search size={17} className="text-[#3D6B4F]" />
            </button>
            <button className="w-9 h-9 flex items-center justify-center bg-white rounded-xl border border-green-100 shadow-sm relative active:bg-green-50">
              <Bell size={17} className="text-[#3D6B4F]" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#C8973A] rounded-full border border-white" />
            </button>
          </div>
        </div>

        {/* Search bar */}
        <AnimatePresence>
          {searchOpen && (
            <div className="mb-2">
              <SearchBar
                value={searchQuery}
                onChange={setSearchQuery}
                onClose={() => { setSearchOpen(false); setSearchQuery(""); }}
              />
            </div>
          )}
        </AnimatePresence>

        {/* Status Tabs */}
        <div
          ref={tabsRef}
          className="flex gap-1 px-5 overflow-x-auto"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {TAB_LABELS.map(t => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`flex-shrink-0 px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                activeTab === t.key
                  ? "bg-[#3D6B4F] text-white shadow-sm"
                  : "bg-white text-[#717972] border border-green-100"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── KPI Strip ── */}
      <div className="px-4 py-3 grid grid-cols-2 gap-2.5">
        {[
          { label: "Total Orders", value: KPI.total, icon: <ShoppingBag size={14} /> },
          { label: "Pending Action", value: KPI.pending, icon: <Clock size={14} /> },
          { label: "On-Time Rate", value: KPI.onTime, icon: <CheckCircle2 size={14} /> },
          { label: "Avg Dispatch", value: KPI.avgDispatch, icon: <Truck size={14} /> },
        ].map((k) => (
          <div key={k.label} className="bg-white rounded-2xl border border-green-100 p-3.5 shadow-sm flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-[#f3e6d6] flex items-center justify-center text-[#3D6B4F] flex-shrink-0">
              {k.icon}
            </div>
            <div>
              <p className="text-[9px] uppercase tracking-widest font-bold text-[#717972]">{k.label}</p>
              <p className="text-lg font-bold text-[#3D6B4F] leading-tight font-mono">{k.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ── Period Picker + Count ── */}
      <div className="flex items-center justify-between px-5 pb-2">
        <p className="text-xs text-[#717972]">
          <span className="font-bold text-[#3D6B4F]">{filtered.length}</span> orders
        </p>
        <div className="relative">
          <button
            onClick={() => setPeriodOpen(!periodOpen)}
            className="flex items-center gap-1.5 text-xs font-bold text-[#3D6B4F] bg-white border border-green-200 rounded-xl px-3 py-1.5"
          >
            {PERIOD_LABELS[period]}
            <ChevronDown size={12} />
          </button>
          <AnimatePresence>
            {periodOpen && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="absolute right-0 top-full mt-1 bg-white border border-green-100 rounded-2xl shadow-xl overflow-hidden z-50"
              >
                {Object.entries(PERIOD_LABELS).map(([k, v]) => (
                  <button
                    key={k}
                    onClick={() => { setPeriod(k); setPeriodOpen(false); }}
                    className={`flex items-center gap-2 w-full px-4 py-2.5 text-sm text-left ${period === k ? "text-[#3D6B4F] font-bold" : "text-[#717972]"} active:bg-green-50`}
                  >
                    {period === k && <Check size={12} className="text-[#3D6B4F]" />}
                    {period !== k && <span className="w-3" />}
                    {v}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* ── Order List ── */}
      <div className="flex-1 px-4 pb-4 flex flex-col gap-2.5">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-16 h-16 bg-white rounded-3xl border border-green-100 flex items-center justify-center shadow-sm">
              <ShoppingBag size={28} className="text-[#8FAF82]" />
            </div>
            <div className="text-center">
              <p className="font-bold italic text-[#3D6B4F] text-lg" style={{ fontFamily: "'Playfair Display', serif" }}>
                No orders found
              </p>
              <p className="text-xs text-[#717972] mt-1">No orders match the current filters.</p>
            </div>
          </div>
        ) : (
          filtered.map(o => (
            <OrderCard key={o.id} order={o} onTap={() => setSelectedOrder(o)} />
          ))
        )}
      </div>

      {/* Export FAB */}
      <button className="fixed bottom-24 right-4 z-30 w-12 h-12 bg-[#3D6B4F] text-white rounded-2xl shadow-lg flex items-center justify-center active:scale-95 transition-transform">
        <Download size={18} />
      </button>

      {/* ── Bottom Nav ── */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-green-100 pb-safe">
        <div className="flex items-center justify-around px-2 py-2">
          {NAV.map(n => {
            const active = activeNav === n.key;
            return (
              <button
                key={n.key}
                onClick={() => setActiveNav(n.key)}
                className={`flex flex-col items-center gap-1 px-4 py-1.5 rounded-xl transition-all ${active ? "text-[#3D6B4F]" : "text-[#aaa]"}`}
              >
                <div className={`p-1.5 rounded-xl transition-all ${active ? "bg-[#f3e6d6]" : ""}`}>
                  <n.icon size={20} strokeWidth={active ? 2.5 : 1.5} />
                </div>
                <span className={`text-[9px] font-bold uppercase tracking-wide ${active ? "text-[#3D6B4F]" : "text-[#aaa]"}`}>
                  {n.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Order Detail ── */}
      <AnimatePresence>
        {selectedOrder && (
          <OrderDetailSheet
            key={selectedOrder.id}
            order={selectedOrder}
            onClose={() => setSelectedOrder(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
