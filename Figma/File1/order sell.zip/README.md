
  # Mobile UI Design

  This is a code bundle for Mobile UI Design. The original project is available at https://www.figma.com/design/xFEsb2S9C6SJqXUrgmOmzf/Mobile-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  