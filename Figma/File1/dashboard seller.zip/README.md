
  # Create Mobile View Panels

  This is a code bundle for Create Mobile View Panels. The original project is available at https://www.figma.com/design/1LYltuzzMJpPbEVJWH3J3M/Create-Mobile-View-Panels.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  