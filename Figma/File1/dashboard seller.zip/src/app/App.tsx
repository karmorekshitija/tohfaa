import { useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import {
  Home,
  Package,
  BarChart2,
  Store,
  PlusCircle,
  Video,
  CalendarOff,
  Eye,
  ArrowRight,
  Leaf,
  Bell,
  ChevronRight,
  Sun,
} from "lucide-react";

// ── Mock data ─────────────────────────────────────────────────────────────────

const SELLER_NAME = "Priya Menon";
const DATE_LABEL = "17 Jun";
const DAY_LABEL = "Tuesday";

const KPIS = [
  { label: "Total Orders", value: "142", change: "+18 new", positive: true },
  { label: "Conversion", value: "3.8%", change: null, positive: true },
  { label: "Revenue", value: "₹58,420", change: "↑12%", positive: true },
  { label: "Pending", value: "9", change: null, positive: null },
];

const LOW_STOCK = [
  { title: "Hand-thrown Clay Pot", stock: 2 },
  { title: "Indigo Block Print Tote", stock: 0 },
  { title: "Beeswax Taper Set", stock: 3 },
  { title: "Shibori Cushion Cover", stock: 1 },
];

const ANNOUNCEMENTS = [
  {
    title: "New Packaging Guidelines",
    body: "Use 100% biodegradable twine and soy-ink labels for all gift boxes starting Sept 1st.",
  },
  {
    title: "Monsoon Curated Collection",
    body: 'Submit "Petrichor & Fern" themed listings by July 30th for homepage feature.',
  },
  {
    title: "Seller Workshop: New Resources",
    body: "Join us this Friday for a live masterclass on extracting pigments from studio waste.",
  },
];

const RECENT_ORDERS = [
  {
    id: "#TF-8821",
    product: "Kalamkari Wall Scroll",
    buyer: "Aarav Sharma",
    city: "Bengaluru",
    amount: "₹2,400",
    status: "shipped",
    img: "https://images.unsplash.com/photo-1603695820978-48f3e9c1b3bd?w=80&h=80&fit=crop&auto=format",
  },
  {
    id: "#TF-8819",
    product: "Brass Dhokra Figurine",
    buyer: "Meera Nair",
    city: "Kochi",
    amount: "₹3,850",
    status: "processing",
    img: "https://images.unsplash.com/photo-1618160702438-9b02ab6515c9?w=80&h=80&fit=crop&auto=format",
  },
  {
    id: "#TF-8814",
    product: "Indigo Block Print Tote",
    buyer: "Rohan Gupta",
    city: "Jaipur",
    amount: "₹980",
    status: "pending",
    img: "https://images.unsplash.com/photo-1595432541891-a461100d3054?w=80&h=80&fit=crop&auto=format",
  },
  {
    id: "#TF-8809",
    product: "Beeswax Taper Set",
    buyer: "Divya Iyer",
    city: "Chennai",
    amount: "₹1,200",
    status: "delivered",
    img: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?w=80&h=80&fit=crop&auto=format",
  },
];

const CHART_DATA = [
  { day: "Jun 11", revenue: 4200, visits: 38 },
  { day: "Jun 12", revenue: 5800, visits: 52 },
  { day: "Jun 13", revenue: 3900, visits: 31 },
  { day: "Jun 14", revenue: 7100, visits: 64 },
  { day: "Jun 15", revenue: 6400, visits: 57 },
  { day: "Jun 16", revenue: 8200, visits: 72 },
  { day: "Jun 17", revenue: 9100, visits: 89 },
];

const QUICK_ACTIONS = [
  { label: "ADD LISTING", icon: <PlusCircle size={22} />, href: "#" },
  { label: "MANAGE ORDERS", icon: <Package size={22} />, href: "#" },
  { label: "UPLOAD REEL", icon: <Video size={22} />, href: "#" },
  { label: "ANALYTICS", icon: <BarChart2 size={22} />, href: "#" },
  { label: "OVERFLOW REQUESTS", icon: <CalendarOff size={22} />, href: "#", badge: 3 },
  { label: "VIEW STORE", icon: <Eye size={22} />, href: "#" },
];

// ── Status badge ──────────────────────────────────────────────────────────────

const STATUS_MAP: Record<string, { bg: string; text: string; label: string }> = {
  pending:    { bg: "bg-amber-100",   text: "text-amber-800",  label: "Pending" },
  processing: { bg: "bg-blue-100",    text: "text-blue-800",   label: "Processing" },
  shipped:    { bg: "bg-purple-100",  text: "text-purple-800", label: "Shipped" },
  delivered:  { bg: "bg-green-100",   text: "text-green-800",  label: "Delivered" },
  cancelled:  { bg: "bg-red-100",     text: "text-red-800",    label: "Cancelled" },
};

function StatusBadge({ status }: { status: string }) {
  const s = STATUS_MAP[status] ?? { bg: "bg-muted", text: "text-muted-foreground", label: status };
  return (
    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider ${s.bg} ${s.text}`}>
      {s.label}
    </span>
  );
}

// ── Toggle switch ─────────────────────────────────────────────────────────────

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 ${checked ? "bg-primary" : "bg-secondary/40"}`}
    >
      <span
        className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform duration-300 ${checked ? "translate-x-5" : "translate-x-0.5"}`}
      />
    </button>
  );
}

// ── Period chips ──────────────────────────────────────────────────────────────

function PeriodChips({ selected, onChange }: { selected: string; onChange: (p: string) => void }) {
  const chips = ["7d", "30d", "90d"];
  return (
    <div className="flex gap-2">
      {chips.map((c) => (
        <button
          key={c}
          onClick={() => onChange(c)}
          className={`px-4 py-1.5 rounded-full text-[10px] font-bold tracking-widest transition-all ${
            selected === c
              ? "bg-primary text-primary-foreground shadow-sm"
              : "bg-card border border-border text-muted-foreground hover:bg-muted"
          }`}
          style={{ fontFamily: "'Cinzel', serif" }}
        >
          {c.toUpperCase()}
        </button>
      ))}
    </div>
  );
}

// ── Bottom Nav ────────────────────────────────────────────────────────────────

function BottomNav({ active }: { active: string }) {
  const items = [
    { id: "home", icon: <Home size={20} />, label: "Home" },
    { id: "orders", icon: <Package size={20} />, label: "Orders" },
    { id: "catalog", icon: <Store size={20} />, label: "Catalog" },
    { id: "analytics", icon: <BarChart2 size={20} />, label: "Analytics" },
  ];
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border flex items-center justify-around px-2 pb-safe">
      {items.map((item) => (
        <button
          key={item.id}
          className={`flex flex-col items-center gap-0.5 py-2 px-3 transition-all ${
            active === item.id ? "text-primary" : "text-muted-foreground"
          }`}
        >
          {item.icon}
          <span className="text-[10px] font-bold tracking-wider" style={{ fontFamily: "'Cinzel', serif" }}>
            {item.label.toUpperCase()}
          </span>
          {active === item.id && (
            <span className="absolute bottom-0 w-6 h-0.5 bg-primary rounded-full" />
          )}
        </button>
      ))}
    </nav>
  );
}

// ── Section heading ───────────────────────────────────────────────────────────

function SectionHeading({ children, action, dot }: { children: React.ReactNode; action?: React.ReactNode; dot?: boolean }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <h2
        className="text-xl text-foreground flex items-center gap-2"
        style={{ fontFamily: "'Playfair Display', serif", fontStyle: "italic" }}
      >
        {children}
        {dot && <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse inline-block" />}
      </h2>
      {action}
    </div>
  );
}

// ── Chart tooltip ─────────────────────────────────────────────────────────────

function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg px-3 py-2 shadow-md text-xs">
      <p className="font-bold text-foreground mb-1" style={{ fontFamily: "'Space Mono', monospace" }}>{label}</p>
      {payload.map((p: any) => (
        <p key={p.name} style={{ color: p.color, fontFamily: "'Space Mono', monospace" }}>
          {p.name === "revenue" ? `₹${p.value.toLocaleString("en-IN")}` : `${p.value} visits`}
        </p>
      ))}
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────

export default function App() {
  const [period, setPeriod] = useState("7d");
  const [holidayOn, setHolidayOn] = useState(false);
  const [activeNav, setActiveNav] = useState("home");

  return (
    <div
      className="min-h-screen bg-background text-foreground"
      style={{ fontFamily: "'DM Sans', sans-serif", maxWidth: 430, margin: "0 auto" }}
    >
      {/* Status bar spacer */}
      <div className="h-10 bg-background" />

      {/* ── Header ── */}
      <header className="px-5 pb-5 pt-1">
        <div className="flex items-start justify-between mb-1">
          <div>
            <h1
              className="text-2xl text-foreground flex items-center gap-1.5 leading-tight"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Good morning, {SELLER_NAME.split(" ")[0]}
              <span className="text-accent">✦</span>
            </h1>
            <p className="text-xs text-muted-foreground mt-0.5">Welcome back to your creative sanctuary.</p>
          </div>
          <div className="flex flex-col items-end gap-1 mt-0.5">
            <span
              className="text-xs text-muted-foreground tracking-widest uppercase"
              style={{ fontFamily: "'Space Mono', monospace" }}
            >
              {DATE_LABEL}
            </span>
            <span
              className="text-[9px] font-bold text-primary/60 tracking-widest uppercase"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              {DAY_LABEL}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between mt-3">
          <PeriodChips selected={period} onChange={setPeriod} />
          <button className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-full text-xs font-medium shadow-sm hover:opacity-90 transition-all">
            <Eye size={14} />
            View Store
          </button>
        </div>
      </header>

      {/* ── Main content ── */}
      <main className="px-4 pb-24 flex flex-col gap-5">

        {/* ── KPI Grid ── */}
        <section>
          <div className="grid grid-cols-2 gap-3">
            {KPIS.map((kpi) => (
              <div
                key={kpi.label}
                className="bg-card border border-border rounded-2xl p-4 shadow-sm flex flex-col justify-between min-h-[100px]"
              >
                <p
                  className="text-[10px] font-bold text-muted-foreground tracking-widest uppercase"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  {kpi.label}
                </p>
                <div className="mt-2">
                  <span
                    className="text-[26px] text-foreground leading-none"
                    style={{ fontFamily: "'Space Mono', monospace" }}
                  >
                    {kpi.value}
                  </span>
                  {kpi.change && (
                    <span
                      className={`ml-2 text-[11px] px-1.5 py-0.5 rounded font-medium ${kpi.positive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}
                      style={{ fontFamily: "'Space Mono', monospace" }}
                    >
                      {kpi.change}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ── Quick Actions ── */}
        <section className="bg-card border border-border rounded-2xl p-4 shadow-sm">
          <SectionHeading>Quick Actions</SectionHeading>
          <div className="grid grid-cols-3 gap-2.5">
            {QUICK_ACTIONS.map((action) => (
              <a
                key={action.label}
                href={action.href}
                className="relative flex flex-col items-center justify-center gap-2 p-3 bg-muted rounded-xl border border-border hover:border-primary hover:bg-secondary/10 transition-all active:scale-95"
              >
                {action.badge && (
                  <span className="absolute -top-1.5 -right-1.5 bg-primary text-primary-foreground text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center border border-background">
                    {action.badge}
                  </span>
                )}
                <div className="w-10 h-10 rounded-full bg-secondary/30 flex items-center justify-center text-primary">
                  {action.icon}
                </div>
                <span
                  className="text-[9px] font-bold text-muted-foreground tracking-wider text-center leading-tight"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  {action.label}
                </span>
              </a>
            ))}
          </div>
        </section>

        {/* ── Low Stock Alerts ── */}
        <section className="bg-card border border-border rounded-2xl p-4 shadow-sm">
          <SectionHeading
            dot
            action={
              <a
                href="#"
                className="text-[10px] font-bold text-primary tracking-widest border-b border-primary/30 hover:border-primary transition-all"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                VIEW CATALOG
              </a>
            }
          >
            Low Stock Alerts
          </SectionHeading>
          <div className="grid grid-cols-2 gap-2.5">
            {LOW_STOCK.map((item) => (
              <div
                key={item.title}
                className="border border-border rounded-xl p-3 flex flex-col gap-1 cursor-pointer hover:border-primary/40 transition-all"
              >
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                  <span className="text-primary-foreground text-[10px]">✦</span>
                </div>
                <p className="text-xs font-medium text-foreground leading-tight mt-1">{item.title}</p>
                <span className={`text-[10px] font-bold ${item.stock === 0 ? "text-red-600" : "text-amber-600"}`}>
                  {item.stock === 0 ? "Out of stock" : `Only ${item.stock} left`}
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* ── Recent Orders ── */}
        <section>
          <SectionHeading
            action={
              <a href="#" className="flex items-center gap-1 text-accent text-xs hover:underline">
                View All <ArrowRight size={13} />
              </a>
            }
          >
            Recent Orders
          </SectionHeading>
          <div className="flex flex-col gap-2.5">
            {RECENT_ORDERS.map((order) => (
              <div
                key={order.id}
                className="bg-card border border-border rounded-2xl p-3 flex items-center gap-3 shadow-sm cursor-pointer active:scale-[0.98] transition-all"
              >
                <div className="w-12 h-12 rounded-xl overflow-hidden border border-border flex-shrink-0 bg-muted">
                  <img src={order.img} alt={order.product} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 min-w-0">
                  <p
                    className="text-sm font-bold text-foreground truncate"
                    style={{ fontFamily: "'Merriweather', serif" }}
                  >
                    {order.product}
                  </p>
                  <p className="text-[11px] text-muted-foreground truncate">
                    {order.buyer} · {order.city}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <span
                      className="text-sm font-bold text-foreground"
                      style={{ fontFamily: "'Space Mono', monospace" }}
                    >
                      {order.amount}
                    </span>
                    <StatusBadge status={order.status} />
                  </div>
                </div>
                <ChevronRight size={16} className="text-muted-foreground flex-shrink-0" />
              </div>
            ))}
          </div>
        </section>

        {/* ── Announcements ── */}
        <section className="bg-card border border-border rounded-2xl p-4 shadow-sm">
          <SectionHeading>Announcements</SectionHeading>
          <div className="grid grid-cols-1 gap-3">
            {ANNOUNCEMENTS.map((a) => (
              <div key={a.title} className="relative pl-6 border border-border rounded-xl p-3">
                <Leaf
                  size={14}
                  className="absolute left-2 top-3.5 text-primary fill-primary"
                />
                <h4
                  className="text-sm font-bold text-primary leading-snug"
                  style={{ fontFamily: "'Merriweather', serif" }}
                >
                  {a.title}
                </h4>
                <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed">{a.body}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ── Holiday Mode ── */}
        <section className="bg-card border border-border rounded-2xl p-4 shadow-sm">
          <div className="flex items-center gap-3 pb-4 border-b border-border">
            <div className="w-11 h-11 rounded-full bg-secondary/30 flex items-center justify-center text-primary flex-shrink-0">
              <Sun size={20} />
            </div>
            <div className="flex-1">
              <h2
                className="text-lg text-foreground"
                style={{ fontFamily: "'Playfair Display', serif", fontStyle: "italic" }}
              >
                Holiday Mode
              </h2>
              <p className="flex items-center gap-1.5 text-[11px] mt-0.5">
                <span className={`w-2 h-2 rounded-full inline-block ${holidayOn ? "bg-amber-400 animate-pulse" : "bg-green-500"}`} />
                <span className={holidayOn ? "text-amber-600" : "text-green-600"}>
                  {holidayOn ? "Shop on temporary break" : "Your shop is active & open"}
                </span>
              </p>
            </div>
            <div className="flex flex-col items-end gap-1">
              <span
                className="text-[9px] font-bold text-muted-foreground tracking-widest"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                BREAK
              </span>
              <Toggle checked={holidayOn} onChange={setHolidayOn} />
            </div>
          </div>

          {holidayOn && (
            <div className="pt-4 flex flex-col gap-3">
              <div className="grid grid-cols-2 gap-2.5">
                <div className="bg-muted rounded-xl p-3 border border-border">
                  <label
                    className="text-[9px] font-bold text-muted-foreground tracking-widest uppercase block mb-1.5"
                    style={{ fontFamily: "'Cinzel', serif" }}
                  >
                    Start Date
                  </label>
                  <input
                    type="datetime-local"
                    className="w-full text-[11px] bg-transparent text-foreground outline-none"
                    style={{ fontFamily: "'Space Mono', monospace" }}
                  />
                </div>
                <div className="bg-muted rounded-xl p-3 border border-border">
                  <label
                    className="text-[9px] font-bold text-muted-foreground tracking-widest uppercase block mb-1.5"
                    style={{ fontFamily: "'Cinzel', serif" }}
                  >
                    End Date
                  </label>
                  <input
                    type="datetime-local"
                    className="w-full text-[11px] bg-transparent text-foreground outline-none"
                    style={{ fontFamily: "'Space Mono', monospace" }}
                  />
                </div>
              </div>
              <button className="w-full py-3 bg-primary text-primary-foreground rounded-full text-[11px] font-bold tracking-widest shadow-md flex items-center justify-center gap-2 hover:opacity-90 active:scale-[0.98] transition-all"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                SAVE HOLIDAY SCHEDULE
              </button>
            </div>
          )}
        </section>

        {/* ── Performance Chart ── */}
        <section className="bg-card border border-border rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-5">
            <h2
              className="text-lg text-foreground"
              style={{ fontFamily: "'Playfair Display', serif", fontStyle: "italic" }}
            >
              Performance Overview
            </h2>
            <div className="flex gap-3">
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                <span className="text-[9px] font-bold text-muted-foreground tracking-widest" style={{ fontFamily: "'Cinzel', serif" }}>REV</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full border-2 border-dashed border-accent bg-transparent" />
                <span className="text-[9px] font-bold text-muted-foreground tracking-widest" style={{ fontFamily: "'Cinzel', serif" }}>VISITS</span>
              </div>
            </div>
          </div>
          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={CHART_DATA} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3D6B4F" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#3D6B4F" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(61,107,79,0.07)" />
                <XAxis
                  dataKey="day"
                  tick={{ fontFamily: "'Space Mono', monospace", fontSize: 9, fill: "#717972" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  yAxisId="rev"
                  tick={{ fontFamily: "'Space Mono', monospace", fontSize: 9, fill: "#3D6B4F" }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`}
                />
                <Tooltip content={<ChartTooltip />} />
                <Area
                  yAxisId="rev"
                  type="monotone"
                  dataKey="revenue"
                  stroke="#3D6B4F"
                  strokeWidth={2.5}
                  fill="url(#revenueGrad)"
                  dot={false}
                  activeDot={{ r: 5, fill: "#3D6B4F" }}
                />
                <Area
                  yAxisId="rev"
                  type="monotone"
                  dataKey="visits"
                  stroke="#7B5EA7"
                  strokeWidth={2}
                  strokeDasharray="5 4"
                  fill="none"
                  dot={false}
                  activeDot={{ r: 5, fill: "#7B5EA7" }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* Breathing room for bottom nav */}
        <div className="h-2" />
      </main>

      {/* ── Bottom Nav ── */}
      <BottomNav active={activeNav} />
    </div>
  );
}
