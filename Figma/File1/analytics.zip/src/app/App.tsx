import React, { useState } from "react";
import { Drawer } from "vaul";
import {
  X, CalendarDays, Package, Star,
  BarChart2, User, Inbox,
  CheckCircle, AlertCircle,
} from "lucide-react";
import { ProfilePage } from "./components/ProfilePage";
import { ReviewsPage } from "./components/ReviewsPage";
import { AnalyticsPage } from "./components/AnalyticsPage";

// {/* MARKER-MAKE-KIT-INVOKED */}

// ── Brand colours ─────────────────────────────────────────────────────────────
const C = {
  primary: "#3D6B4F",
  gold: "#C8973A",
  sage: "#8FAF82",
  sageSoft: "#e9f0e8",
  surface: "#FFFFFF",
  surfaceVariant: "#F7F3EC",
  onSurface: "#211b11",
  onSurfaceVariant: "#414942",
  outlineVariant: "rgba(113,121,114,0.15)",
};

// ── Types ─────────────────────────────────────────────────────────────────────
type Status = "pending" | "accepted" | "confirmed" | "declined" | "expired" | "cancelled";
type FilterKey = "all" | "pending" | "accepted" | "confirmed" | "declined";
type SlideContent = "accept" | "decline" | "confirmed-detail" | null;

interface Request {
  id: number;
  status: Status;
  product_title: string;
  listing_id: string;
  product_image: string;
  buyer_name: string;
  buyer_email: string;
  quantity: number;
  original_price_paise: number;
  created_at: string;
  seller_proposed_date?: string;
}

// ── Dummy data ────────────────────────────────────────────────────────────────
const DUMMY: Request[] = [
  {
    id: 101, status: "pending",
    product_title: "Handwoven Artisan Wall Hanging", listing_id: "1284",
    product_image: "https://images.unsplash.com/photo-1528190336454-13cd56b45b5a?w=150&auto=format&fit=crop&q=60",
    buyer_name: "Priya Patel", buyer_email: "priya.patel@example.com",
    quantity: 2, original_price_paise: 180000,
    created_at: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 102, status: "accepted",
    product_title: "Terracotta Ceramic Coffee Mug Set", listing_id: "1532",
    product_image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=150&auto=format&fit=crop&q=60",
    buyer_name: "Aarav Sharma", buyer_email: "aarav.sharma@example.com",
    quantity: 1, original_price_paise: 120000,
    created_at: new Date(Date.now() - 172800000).toISOString(),
    seller_proposed_date: new Date(Date.now() + 604800000).toISOString().slice(0, 10),
  },
  {
    id: 103, status: "confirmed",
    product_title: "Hand-Carved Walnut Wood Coasters", listing_id: "1908",
    product_image: "https://images.unsplash.com/photo-1538688525198-9b88f6f53126?w=150&auto=format&fit=crop&q=60",
    buyer_name: "Meera Nair", buyer_email: "meera.nair@example.com",
    quantity: 3, original_price_paise: 95000,
    created_at: new Date(Date.now() - 259200000).toISOString(),
  },
  {
    id: 104, status: "pending",
    product_title: "Pure Soy Wax Lavender Candle", listing_id: "2045",
    product_image: "https://images.unsplash.com/photo-1603006905003-be475563bc59?w=150&auto=format&fit=crop&q=60",
    buyer_name: "Kabir Sen", buyer_email: "kabir.sen@example.com",
    quantity: 5, original_price_paise: 45000,
    created_at: new Date(Date.now() - 7200000).toISOString(),
  },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatPaise(p: number) {
  return "₹" + (p / 100).toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

function formatDate(dt: string | undefined | null) {
  if (!dt) return "—";
  return new Date(dt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function timeAgo(dt: string) {
  const h = Math.floor((Date.now() - new Date(dt).getTime()) / 3600000);
  if (h < 1) return "just now";
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

const STATUS_META: Record<Status, { label: string; bg: string; text: string }> = {
  pending:   { label: "Pending",    bg: "#FEF3C7", text: "#92400E" },
  accepted:  { label: "Offer Sent", bg: "#DBEAFE", text: "#1E40AF" },
  confirmed: { label: "Confirmed",  bg: "#D1FAE5", text: "#065F46" },
  declined:  { label: "Declined",   bg: "#FFE4E6", text: "#9F1239" },
  expired:   { label: "Expired",    bg: "#F3F4F6", text: "#374151" },
  cancelled: { label: "Cancelled",  bg: "#F3F4F6", text: "#374151" },
};

// ── Small components ──────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: Status }) {
  const m = STATUS_META[status] ?? STATUS_META.expired;
  return (
    <span
      style={{ background: m.bg, color: m.text }}
      className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider whitespace-nowrap"
    >
      {m.label}
    </span>
  );
}

function Toast({ msg, type }: { msg: string; type: "success" | "error" }) {
  return (
    <div
      style={{ background: type === "success" ? C.primary : "#FEE2E2", color: type === "success" ? "#fff" : "#991B1B" }}
      className="fixed top-4 left-4 right-4 z-[300] flex items-center gap-2 px-4 py-3 rounded-2xl shadow-lg text-sm font-medium max-w-[430px] mx-auto"
    >
      {type === "success" ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
      {msg}
    </div>
  );
}

function KpiStrip({ requests }: { requests: Request[] }) {
  const tiles = [
    { label: "Total Requests",  value: requests.length,                                      color: C.primary },
    { label: "Pending Action",  value: requests.filter(r => r.status === "pending").length,  color: "#D97706" },
    { label: "Offer Sent",      value: requests.filter(r => r.status === "accepted").length, color: "#2563EB" },
    { label: "Confirmed",       value: requests.filter(r => r.status === "confirmed").length,color: C.primary },
  ];
  return (
    <div className="grid grid-cols-2 gap-3 px-4 mb-4">
      {tiles.map(t => (
        <div key={t.label} style={{ background: C.surface, borderColor: C.outlineVariant }}
             className="border rounded-2xl px-4 py-3 shadow-sm">
          <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
             className="text-[9px] uppercase tracking-widest opacity-70 leading-none">{t.label}</p>
          <p style={{ color: t.color, fontFamily: "'Playfair Display', serif" }}
             className="text-3xl font-bold mt-1 leading-none">{t.value}</p>
        </div>
      ))}
    </div>
  );
}

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: "all",       label: "All"       },
  { key: "pending",   label: "Pending"   },
  { key: "accepted",  label: "Offered"   },
  { key: "confirmed", label: "Confirmed" },
  { key: "declined",  label: "Declined"  },
];

function FilterTabs({ active, onChange }: { active: FilterKey; onChange: (k: FilterKey) => void }) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
      {FILTERS.map(f => {
        const on = f.key === active;
        return (
          <button
            key={f.key}
            onClick={() => onChange(f.key)}
            style={{
              fontFamily: "'DM Sans', sans-serif",
              background: on ? C.primary : "transparent",
              color: on ? "#fff" : C.onSurfaceVariant,
              border: `1px solid ${on ? C.primary : "rgba(113,121,114,0.3)"}`,
            }}
            className="flex-shrink-0 text-sm font-semibold px-4 py-1.5 rounded-full transition-all"
          >
            {f.label}
          </button>
        );
      })}
    </div>
  );
}

function RequestCard({
  request: r, onOffer, onDecline, onDetail,
}: {
  request: Request;
  onOffer: () => void;
  onDecline: () => void;
  onDetail: () => void;
}) {
  return (
    <div style={{ background: C.surface, borderColor: C.outlineVariant }}
         className="mx-4 border rounded-2xl overflow-hidden shadow-sm">
      {/* Product row */}
      <div className="flex items-start gap-3 p-4">
        <img
          src={r.product_image}
          alt={r.product_title}
          className="w-14 h-14 rounded-xl object-cover flex-shrink-0"
          style={{ border: `1px solid ${C.outlineVariant}` }}
        />
        <div className="flex-1 min-w-0">
          <p style={{ color: C.primary, fontFamily: "'Merriweather', serif" }}
             className="text-sm font-bold leading-snug line-clamp-2">{r.product_title}</p>
          <p style={{ color: C.onSurfaceVariant }} className="text-xs opacity-60 mt-0.5">
            #{r.listing_id} · {timeAgo(r.created_at)}
          </p>
        </div>
        <StatusBadge status={r.status} />
      </div>

      {/* Details row */}
      <div style={{ borderTop: `1px solid ${C.outlineVariant}`, background: C.surfaceVariant }}
           className="flex items-center px-4 py-2.5 gap-4">
        <div className="flex-1 min-w-0">
          <p style={{ color: C.onSurfaceVariant }} className="text-[10px] uppercase tracking-wider opacity-60">Buyer</p>
          <p style={{ color: C.onSurface, fontFamily: "'DM Sans', sans-serif" }}
             className="text-xs font-semibold truncate">{r.buyer_name}</p>
        </div>
        <div className="text-center">
          <p style={{ color: C.onSurfaceVariant }} className="text-[10px] uppercase tracking-wider opacity-60">Qty</p>
          <p style={{ color: C.primary, fontFamily: "'Space Mono', monospace" }}
             className="text-sm font-bold">{r.quantity}</p>
        </div>
        <div className="text-right">
          <p style={{ color: C.onSurfaceVariant }} className="text-[10px] uppercase tracking-wider opacity-60">Value</p>
          <p style={{ color: C.onSurface, fontFamily: "'Space Mono', monospace" }}
             className="text-sm font-bold">{formatPaise(r.original_price_paise * r.quantity)}</p>
        </div>
      </div>

      {/* Action row */}
      {r.status === "pending" && (
        <div className="flex gap-2 px-4 py-3">
          <button onClick={onOffer} style={{ background: C.primary }}
                  className="flex-1 text-white text-sm font-bold py-2.5 rounded-xl active:opacity-80">
            Offer Terms
          </button>
          <button onClick={onDecline}
                  style={{ border: `1px solid ${C.primary}`, color: C.primary }}
                  className="flex-1 text-sm font-bold py-2.5 rounded-xl active:opacity-70">
            Decline
          </button>
        </div>
      )}
      {r.status === "accepted" && (
        <div className="flex flex-col items-center gap-1 px-4 py-3">
          <p style={{ color: C.onSurfaceVariant }} className="text-xs">
            Proposed: <strong>{formatDate(r.seller_proposed_date)}</strong>
          </p>
          <button onClick={onDecline} className="text-xs font-bold underline" style={{ color: "#DC2626" }}>
            Cancel Offer
          </button>
        </div>
      )}
      {r.status === "confirmed" && (
        <div className="px-4 py-3">
          <button onClick={onDetail}
                  style={{ border: `1px solid ${C.primary}`, color: C.primary }}
                  className="w-full text-sm font-bold py-2.5 rounded-xl active:opacity-70">
            View Details
          </button>
        </div>
      )}
    </div>
  );
}

function AcceptForm({ r, onSubmit, onCancel }: {
  r: Request;
  onSubmit: (date: string, notes: string) => void;
  onCancel: () => void;
}) {
  const def = new Date(); def.setDate(def.getDate() + 7);
  const [date, setDate] = useState(def.toISOString().slice(0, 10));
  const [notes, setNotes] = useState("");
  return (
    <div className="space-y-4">
      <div style={{ background: `${C.primary}0D`, border: `1px solid ${C.primary}20` }} className="p-4 rounded-xl">
        <p style={{ color: C.primary, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest font-bold">Request Summary</p>
        <p style={{ color: C.onSurface }} className="text-sm font-semibold mt-1">
          {r.buyer_name} wants {r.quantity}× {r.product_title}
        </p>
        <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5">Value: {formatPaise(r.original_price_paise * r.quantity)}</p>
      </div>
      <div className="flex flex-col gap-1.5">
        <label style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest">
          Proposed Fulfillment Date
        </label>
        <input type="date" required min={new Date().toISOString().slice(0, 10)} value={date}
               onChange={e => setDate(e.target.value)}
               style={{ border: `1px solid ${C.sage}`, borderRadius: "0.75rem" }}
               className="w-full bg-white px-3 py-2.5 text-sm focus:outline-none" />
      </div>
      <div className="flex flex-col gap-1.5">
        <label style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest">
          Notes to Buyer
        </label>
        <textarea rows={4} value={notes} onChange={e => setNotes(e.target.value)}
                  placeholder="Explain your custom timeline..."
                  style={{ border: `1px solid ${C.sage}`, borderRadius: "0.75rem" }}
                  className="w-full bg-white px-3 py-2.5 text-sm focus:outline-none resize-none" />
      </div>
      <button onClick={() => onSubmit(date, notes)} style={{ background: C.primary }}
              className="w-full text-white font-bold py-3 rounded-xl text-sm active:opacity-80">
        Send Offer to Buyer
      </button>
      <button onClick={onCancel} style={{ color: C.onSurfaceVariant }} className="w-full text-sm text-center py-1">Cancel</button>
    </div>
  );
}

function DeclineForm({ r, onSubmit, onCancel }: {
  r: Request;
  onSubmit: (notes: string) => void;
  onCancel: () => void;
}) {
  const [notes, setNotes] = useState("");
  return (
    <div className="space-y-4">
      <div className="p-4 rounded-xl border border-red-100 bg-red-50">
        <p className="text-[9px] uppercase tracking-widest font-bold text-red-700" style={{ fontFamily: "'Cinzel', serif" }}>Decline Confirmation</p>
        <p className="text-sm font-semibold text-red-900 mt-1">Declining {r.buyer_name}'s request</p>
        <p className="text-xs text-red-700 mt-1 opacity-80">Any associated payment authorization will be released automatically.</p>
      </div>
      <div className="flex flex-col gap-1.5">
        <label style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest">
          Note to Buyer (Optional)
        </label>
        <textarea rows={4} value={notes} onChange={e => setNotes(e.target.value)}
                  placeholder="Let the buyer know why you are unable to fulfill..."
                  style={{ border: "1px solid #FECACA", borderRadius: "0.75rem" }}
                  className="w-full bg-white px-3 py-2.5 text-sm focus:outline-none resize-none" />
      </div>
      <button onClick={() => onSubmit(notes)} className="w-full text-white font-bold py-3 rounded-xl text-sm active:opacity-80" style={{ background: "#DC2626" }}>
        Confirm Decline
      </button>
      <button onClick={onCancel} style={{ color: C.onSurfaceVariant }} className="w-full text-sm text-center py-1">Cancel</button>
    </div>
  );
}

function ConfirmedDetail({ r }: { r: Request }) {
  const infoCard = (children: React.ReactNode) => (
    <div style={{ background: C.surfaceVariant, borderColor: C.outlineVariant }} className="rounded-xl border p-4">
      {children}
    </div>
  );
  return (
    <div className="space-y-4">
      {infoCard(
        <>
          <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest opacity-70">Buyer</p>
          <p style={{ color: C.onSurface }} className="font-bold text-base mt-1">{r.buyer_name}</p>
          <p style={{ color: C.onSurfaceVariant }} className="text-xs">{r.buyer_email}</p>
          <div style={{ borderTop: `1px solid ${C.outlineVariant}` }} className="pt-2 mt-2">
            <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest opacity-70">Shipping Address</p>
            <p style={{ color: C.onSurfaceVariant }} className="text-xs leading-relaxed mt-1">42, Laxmi Nagar, Sector 7, Mumbai, Maharashtra - 400001</p>
          </div>
        </>
      )}
      {infoCard(
        <div className="flex gap-3 items-start">
          <img src={r.product_image} alt={r.product_title} className="w-12 h-12 rounded-xl object-cover flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p style={{ color: C.primary }} className="font-bold text-sm truncate">{r.product_title}</p>
            <p style={{ color: C.gold, fontFamily: "'Space Mono', monospace" }} className="text-[10px] mt-0.5">#PROD-{r.listing_id}</p>
            <div style={{ borderTop: `1px solid ${C.outlineVariant}` }} className="flex justify-between mt-2 pt-2">
              <span style={{ color: C.onSurfaceVariant }} className="text-xs">Qty: {r.quantity}</span>
              <span style={{ color: C.primary, fontFamily: "'Space Mono', monospace" }} className="font-bold text-sm">
                {formatPaise(r.original_price_paise * r.quantity)}
              </span>
            </div>
          </div>
        </div>
      )}
      {infoCard(
        <>
          <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest opacity-70 mb-2">Deal History</p>
          <div className="grid grid-cols-2 gap-3">
            {[{ l: "Requested On", v: formatDate(r.created_at) }, { l: "Finalized On", v: formatDate(r.created_at) }].map(x => (
              <div key={x.l}>
                <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest opacity-60">{x.l}</p>
                <p style={{ color: C.onSurface }} className="text-xs font-medium mt-0.5">{x.v}</p>
              </div>
            ))}
          </div>
        </>
      )}
      {infoCard(
        <>
          <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest opacity-70 mb-2">Shipment Details</p>
          {[
            { l: "Order Ref",   v: "TF-1007" },
            { l: "Status",      v: "Delivered" },
            { l: "Carrier",     v: "Blue Dart" },
            { l: "Tracking ID", v: "BD83749210" },
          ].map(x => (
            <p key={x.l} style={{ color: C.onSurfaceVariant }} className="text-xs">
              {x.l}: <span style={{ color: C.onSurface, fontFamily: "'Space Mono', monospace" }} className="font-bold">{x.v}</span>
            </p>
          ))}
        </>
      )}
    </div>
  );
}

type AppPage = "analytics" | "reviews" | "overflow" | "profile";

function BottomNav({ active, onChange }: { active: AppPage; onChange: (p: AppPage) => void }) {
  const tabs: { key: AppPage; label: string; Icon: React.ElementType }[] = [
    { key: "analytics", label: "Analytics", Icon: BarChart2 },
    { key: "reviews",   label: "Reviews",   Icon: Star },
    { key: "overflow",  label: "Overflow",  Icon: Package },
    { key: "profile",   label: "Profile",   Icon: User },
  ];
  return (
    <nav style={{ background: C.surface, borderTop: `1px solid ${C.outlineVariant}` }}
         className="fixed bottom-0 left-0 right-0 z-50 flex items-center justify-around px-2 pt-2 pb-3 max-w-[430px] mx-auto">
      {tabs.map(({ key, label, Icon }) => {
        const on = key === active;
        return (
          <button key={key} onClick={() => onChange(key)} style={{ color: on ? C.primary : C.onSurfaceVariant }}
                  className="flex flex-col items-center gap-0.5 py-1 px-3 flex-1 min-w-0">
            <Icon size={22} strokeWidth={on ? 2.5 : 1.8} />
            <span style={{ fontFamily: "'DM Sans', sans-serif" }}
                  className={`text-[10px] ${on ? "font-bold" : "font-medium"}`}>{label}</span>
            {on && <span style={{ background: C.primary }} className="w-1 h-1 rounded-full mt-0.5" />}
          </button>
        );
      })}
    </nav>
  );
}

// ── Root component ────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState<AppPage>("overflow");
  const [requests, setRequests] = useState<Request[]>(DUMMY);
  const [filter, setFilter] = useState<FilterKey>("all");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [slideContent, setSlideContent] = useState<SlideContent>(null);
  const [activeReq, setActiveReq] = useState<Request | null>(null);
  const [toast, setToast] = useState<{ msg: string; type: "success" | "error" } | null>(null);

  function showToast(msg: string, type: "success" | "error" = "success") {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3200);
  }

  function openSheet(r: Request, content: SlideContent) {
    setActiveReq(r);
    setSlideContent(content);
    setDrawerOpen(true);
  }

  const filtered = requests.filter(r => {
    if (filter === "all") return true;
    if (filter === "declined") return ["declined", "expired", "cancelled"].includes(r.status);
    return r.status === filter;
  });

  function handleAccept(date: string, notes: string) {
    if (!activeReq) return;
    setRequests(prev => prev.map(r => r.id === activeReq.id
      ? { ...r, status: "accepted" as Status, seller_proposed_date: date }
      : r));
    showToast("Fulfillment offer sent to buyer!");
    setDrawerOpen(false);
  }

  function handleDecline() {
    if (!activeReq) return;
    setRequests(prev => prev.map(r => r.id === activeReq.id ? { ...r, status: "declined" as Status } : r));
    showToast("Request declined successfully.");
    setDrawerOpen(false);
  }

  const sheetTitle =
    slideContent === "accept"           ? "Propose Fulfillment" :
    slideContent === "decline"          ? "Decline Request"     :
                                          "Deal Details";
  const sheetSubtitle =
    slideContent === "accept"           ? `Request #${activeReq?.id} · Offer Terms` :
    slideContent === "decline"          ? `Request #${activeReq?.id} · Decline`     :
                                          `Request #${activeReq?.id} · Confirmed`;

  if (page === "profile") {
    return (
      <div style={{ background: "#FAF7F2", fontFamily: "'DM Sans', sans-serif" }}
           className="min-h-screen max-w-[430px] mx-auto flex flex-col relative">
        <div className="flex-1 overflow-y-auto pb-20">
          <ProfilePage />
        </div>
        <BottomNav active={page} onChange={setPage} />
      </div>
    );
  }

  if (page === "reviews") {
    return (
      <div style={{ background: "#FAF7F2", fontFamily: "'DM Sans', sans-serif" }}
           className="min-h-screen max-w-[430px] mx-auto flex flex-col relative">
        <div className="flex-1 overflow-y-auto pb-20">
          <ReviewsPage />
        </div>
        <BottomNav active={page} onChange={setPage} />
      </div>
    );
  }

  if (page === "analytics") {
    return (
      <div style={{ background: "#FAF7F2", fontFamily: "'DM Sans', sans-serif" }}
           className="min-h-screen max-w-[430px] mx-auto flex flex-col relative">
        <div className="flex-1 overflow-y-auto pb-20">
          <AnalyticsPage />
        </div>
        <BottomNav active={page} onChange={setPage} />
      </div>
    );
  }

  return (
    <div style={{ background: "#FAF7F2", fontFamily: "'DM Sans', sans-serif" }}
         className="min-h-screen max-w-[430px] mx-auto flex flex-col relative">

      {toast && <Toast msg={toast.msg} type={toast.type} />}

      {/* ── Sticky header ── */}
      <header style={{ background: C.surface, borderBottom: `1px solid ${C.outlineVariant}` }}
              className="sticky top-0 z-40 px-4 pt-10 pb-3">
        <div className="flex items-end justify-between mb-3">
          <div>
            <p style={{ color: C.gold, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest font-bold">Seller Studio</p>
            <h1 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }} className="text-2xl italic font-bold leading-tight mt-0.5">
              Overflow Requests
            </h1>
            <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5 opacity-70">
              {filtered.length} request{filtered.length !== 1 ? "s" : ""} in view
            </p>
          </div>
          {/* using <a> instead of a kit Link: no kit routing component present */}
          <a href="#" style={{ border: `1px solid ${C.primary}`, color: C.primary }}
             className="flex items-center gap-1.5 text-xs font-bold px-3 py-2 rounded-xl">
            <CalendarDays size={14} />
            Planner
          </a>
        </div>
        <FilterTabs active={filter} onChange={setFilter} />
      </header>

      {/* ── Body ── */}
      <main className="flex-1 overflow-y-auto pb-24 pt-4">
        <KpiStrip requests={requests} />

        {filtered.length === 0 ? (
          <div className="flex flex-col items-center py-16 gap-3 px-8 text-center">
            <Inbox size={48} color={C.sage} />
            <h3 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }} className="text-xl italic font-bold">No requests found</h3>
            <p style={{ color: C.onSurfaceVariant }} className="text-sm opacity-70">No overflow requests match the current filter.</p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {filtered.map(r => (
              <RequestCard
                key={r.id}
                request={r}
                onOffer={() => openSheet(r, "accept")}
                onDecline={() => openSheet(r, "decline")}
                onDetail={() => openSheet(r, "confirmed-detail")}
              />
            ))}
          </div>
        )}
      </main>

      <BottomNav active={page} onChange={setPage} />

      {/* ── Bottom sheet ── */}
      <Drawer.Root open={drawerOpen} onOpenChange={setDrawerOpen}>
        <Drawer.Portal>
          <Drawer.Overlay className="fixed inset-0 z-50 bg-black/30" />
          <Drawer.Content style={{ background: C.surface }}
                          className="fixed bottom-0 left-0 right-0 z-50 max-h-[92dvh] rounded-t-3xl flex flex-col max-w-[430px] mx-auto">
            <div className="flex justify-center pt-3 pb-1">
              <div style={{ background: C.outlineVariant }} className="w-10 h-1 rounded-full" />
            </div>
            <div style={{ borderBottom: `1px solid ${C.outlineVariant}` }}
                 className="flex items-start justify-between px-5 py-4">
              <div>
                <p style={{ color: C.gold, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest font-bold">{sheetSubtitle}</p>
                <h2 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }} className="text-xl font-bold italic mt-0.5">{sheetTitle}</h2>
              </div>
              <button onClick={() => setDrawerOpen(false)} style={{ color: C.onSurfaceVariant }}
                      className="p-2 rounded-full hover:bg-gray-100 transition-colors">
                <X size={20} />
              </button>
            </div>
            <div className="overflow-y-auto px-5 py-5 flex-1">
              {activeReq && slideContent === "accept"           && <AcceptForm r={activeReq} onSubmit={handleAccept} onCancel={() => setDrawerOpen(false)} />}
              {activeReq && slideContent === "decline"          && <DeclineForm r={activeReq} onSubmit={handleDecline} onCancel={() => setDrawerOpen(false)} />}
              {activeReq && slideContent === "confirmed-detail" && <ConfirmedDetail r={activeReq} />}
            </div>
          </Drawer.Content>
        </Drawer.Portal>
      </Drawer.Root>
    </div>
  );
}
