
  # Convert Desktop to Mobile

  This is a code bundle for Convert Desktop to Mobile. The original project is available at https://www.figma.com/design/XdQVEMgLwJDPEoZjqN8P44/Convert-Desktop-to-Mobile.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  