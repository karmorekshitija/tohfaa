import { useState, useRef, useEffect } from "react";

// ── Tokens ────────────────────────────────────────────────────────────────────
const C = {
  primary: "#3D6B4F",
  forest: "#3D6B4F",
  sage: "#8FAF82",
  gold: "#C8973A",
  violet: "#7B5EA7",
  parchment: "#F7F3EC",
  surface: "#FFFFFF",
  surfaceContainer: "#edeeea",
  surfaceContainerLow: "#f3f4f0",
  outline: "#717972",
  outlineVariant: "#E8E2D5",
  onSurface: "#1a1c1a",
  onSurfaceVariant: "#414942",
  secondary: "#49663f",
};

// ── Mock data ─────────────────────────────────────────────────────────────────
const MOCK_REELS = [
  { id: "r1", title: "Wheel throwing a celadon vase", caption: "From raw clay to finished form — the meditative process of centering on the wheel. #ceramics #processvideo", visibility: "public", views: 2140, thumb: "https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?q=80&w=400&auto=format&fit=crop" },
  { id: "r2", title: "Hand-dyeing silk scarves", caption: "Natural indigo dye bath — each scarf emerges completely unique. Slow craft, intentional colour.", visibility: "public", views: 874, thumb: "https://images.unsplash.com/photo-1590736969955-71cb94801759?q=80&w=400&auto=format&fit=crop" },
  { id: "r3", title: "Beeswax candle pour", caption: "Pouring hand-poured beeswax candles with lavender + honey notes.", visibility: "draft", views: 0, thumb: "https://images.unsplash.com/photo-1603006905003-be475563bc59?q=80&w=400&auto=format&fit=crop" },
];

const MOCK_LISTINGS = [
  { id: 1, title: "Speckled Moon Bowl", price: "₹480", image: "https://lh3.googleusercontent.com/aida-public/AB6AXuALC6UYYOUWjs3W4VkD8uWjcppHVpQhleCxmEGF6UAFY8zCGq3M9x6zGcZb7ATlZPZWyZLbSbkv6C58GzEpFbGJJF7JEwus4RG0AzgYM1uMpb92qU1vu8i14hzLiI8fu0O8r26llYaiEO1t5Q9kPxeoUw1n4rvUdAC5wtPtJiaCY0kStW5phf-aTpMsoEorrV1be7nbHSSBZTPskASzrBSMxaqLYGItxSzojxseeJL8bn5hlwwz74rh9mHDKiSU_JfgVPudS3_BDcE" },
  { id: 2, title: "Sage Ribbed Carafe", price: "₹850", image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBfTUELyuKQTKXZ8luOpxbP9ZxSrvRQDToCQ0N18Chw5sTUg82THIln8Ywpy6ROctrBVZxm4zFsYwHOuhtAI92ZCIAbpe4eqUYATYVv7s9zWjEG9SfkJyQSQdzQBsrnhvLPPvDNP_-gMX3s304PZA5qDh3Joi58lbJcAkG31FdyaiEJhovOjCwL0xUY1mFiuqNY1vjkip3sOainPZ_dkH3YAFlh143DRgVjCKL1NQONSkN_iExDgNpXIkfSJ-VXTND2mi3OdvzYZrs" },
  { id: 3, title: "Forest Espresso Set", price: "₹320", image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAVOngRd-DVK72EyammumZPlK3sZdreV15xeleG5jZxygwSOJ09GzEOyVEuHGwUtHyHCjfb5iNmcXFEHLNU7dEdOrvZrIJ_SKc4RWteMPfH4UQt1iQ8fDsEpRhg7R0UA4jLfpudhLGVyoicGdIvGeezmZSBt5ehdb7pd2A6sr4tAHk8UyPCdXKv-zBNShdIwAEt7czXe-trxM6QSdALpWd-4QnZTcoprR1gR0j9mbqGZFAmnUcUnX5kvHlmhlV2oFJryqm0PKX-pbg" },
  { id: 4, title: "Petal Ring Dish", price: "₹240", image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBnYwodC8O5OBIoHWDoOMQ_wndi6zN0wBAKqxarh1XKgMAwXhMz0eCaH5Wkv8xfSozcufOwFAreoGEys_Za0DK4CVqLAXxxQj2tFv-SxeEi3WaPLuHQNmvN_r_nTcljqc3Wdam1xn2LaMHwxF_rVy9UPcLza3R17VZXHodaznYkCDfp2J_pZ-GlA0qAOUsvFbwDA3jkJkx7vU1RFPUk_sgAmCNoVe9lWC9izWoIbkDhT3DxWPNVqGj9RPcExPbmQn9G0B9rZPcagxs" },
];

type View = "library" | "upload" | "success";
type Reel = typeof MOCK_REELS[0];

// ── Section label ─────────────────────────────────────────────────────────────
function Label({ children }: { children: React.ReactNode }) {
  return <p style={{ fontFamily: "'DM Sans'", fontSize: 11, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: C.onSurfaceVariant, margin: "0 0 6px" }}>{children}</p>;
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <Label>{label}</Label>
      {children}
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  width: "100%", padding: "11px 14px", borderRadius: 10, border: `1px solid ${C.sage}40`,
  fontFamily: "'DM Sans'", fontSize: 14, outline: "none", background: `${C.parchment}50`,
  color: C.onSurface, boxSizing: "border-box",
};

const selectStyle: React.CSSProperties = { ...inputStyle, cursor: "pointer", appearance: "none" };

// ── Delete modal ──────────────────────────────────────────────────────────────
function DeleteModal({ onConfirm, onCancel }: { onConfirm: () => void; onCancel: () => void }) {
  return (
    <>
      <div onClick={onCancel} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 80, backdropFilter: "blur(3px)" }} />
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: "calc(100% - 40px)", maxWidth: 380, background: C.parchment, borderRadius: 20, padding: "28px 24px", zIndex: 90, border: `1px solid ${C.sage}99`, boxShadow: "0 20px 60px rgba(0,0,0,0.25)", textAlign: "center" }}>
        <div style={{ width: 48, height: 48, borderRadius: "50%", background: "#fee2e2", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}>
          <span className="material-symbols-outlined" style={{ fontSize: 24, color: "#dc2626" }}>warning</span>
        </div>
        <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 20, fontWeight: 700, color: C.primary, margin: "0 0 8px" }}>Delete Reel?</h3>
        <p style={{ fontFamily: "'DM Sans'", fontSize: 13, color: C.onSurfaceVariant, margin: "0 0 22px", lineHeight: 1.6 }}>Are you sure? This action cannot be undone and will remove it from the gallery.</p>
        <div style={{ display: "flex", gap: 12 }}>
          <button onClick={onCancel} style={{ flex: 1, padding: "12px", borderRadius: 99, border: `1px solid ${C.sage}`, background: "transparent", fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 700, color: C.primary, cursor: "pointer" }}>Cancel</button>
          <button onClick={onConfirm} style={{ flex: 1, padding: "12px", borderRadius: 99, border: "none", background: "#dc2626", color: "#fff", fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 700, cursor: "pointer" }}>Delete</button>
        </div>
      </div>
    </>
  );
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function Toast({ msg, type }: { msg: string; type: "success" | "error" }) {
  return (
    <div style={{ position: "fixed", top: 72, left: "50%", transform: "translateX(-50%)", background: type === "success" ? C.forest : "#dc2626", color: "#fff", borderRadius: 12, padding: "10px 18px", fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 600, zIndex: 100, display: "flex", alignItems: "center", gap: 8, boxShadow: "0 4px 20px rgba(0,0,0,0.2)", whiteSpace: "nowrap" }}>
      <span className="material-symbols-outlined" style={{ fontSize: 16, fontVariationSettings: "'FILL' 1" }}>{type === "success" ? "check_circle" : "error"}</span>
      {msg}
    </div>
  );
}

// ── Confetti canvas ───────────────────────────────────────────────────────────
function Confetti() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const COLORS = ["#3D6B4F", "#bceecb", "#ecdcff", "#7B5EA7", "#f9ecdc", "#C8973A"];
    type P = { x: number; y: number; size: number; sx: number; sy: number; color: string; alpha: number };
    let particles: P[] = Array.from({ length: 80 }, () => ({
      x: canvas.width / 2 + (Math.random() - 0.5) * 120,
      y: canvas.height / 2 + (Math.random() - 0.5) * 120,
      size: Math.random() * 5 + 2,
      sx: (Math.random() - 0.5) * 10,
      sy: (Math.random() - 0.5) * 14 - 6,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      alpha: 1,
    }));
    let raf: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles = particles.filter(p => p.alpha > 0);
      particles.forEach(p => {
        p.sy += 0.25; p.x += p.sx; p.y += p.sy; p.alpha -= 0.007;
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.fillStyle = p.color;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill();
      });
      if (particles.length > 0) raf = requestAnimationFrame(animate);
    };
    raf = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(raf);
  }, []);
  return <canvas ref={ref} style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }} />;
}

// ── Success screen ────────────────────────────────────────────────────────────
function SuccessScreen({ onViewFeed, onPostAnother }: { onViewFeed: () => void; onPostAnother: () => void }) {
  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "40px 24px", textAlign: "center", position: "relative", minHeight: "70vh" }}>
      <Confetti />
      <div style={{ position: "relative", zIndex: 1, display: "flex", flexDirection: "column", alignItems: "center" }}>
        {/* Circle image + badge */}
        <div style={{ position: "relative", width: 180, height: 180, marginBottom: 28 }}>
          <div style={{ position: "absolute", inset: 0, borderRadius: "50%", background: "rgba(188,238,203,0.25)", filter: "blur(20px)" }} />
          <div style={{ width: 180, height: 180, borderRadius: "50%", overflow: "hidden", border: "4px solid #fff", boxShadow: "0 8px 32px rgba(0,0,0,0.15)" }}>
            <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuA7JM8T5TvWDX0uzJvCBQDAX0Y4-BT6YOHi7Xu0YwYYe3bOvecPCaLkatT6ZIL5mV-QQaxlS4r5CtREcKqKiDxHg9u1dnFa-ECRjY0XGwomWPryAYYuNOxDq9LlP0aUAnEG5_xTFtliT74h8nl5XkHYhZ3DBIhwxDldfKCl2GvTtcyAYvL0FW4BynJbG9N40acxLdyCmcfUfd5WK9fNP16qXMUJzSjVXMK8y-QrjZlMqQtlzvfXSDN5XDU423Bjnft8nR2YBTIDVvY" alt="Success" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </div>
          <div style={{ position: "absolute", bottom: 8, right: 8, width: 44, height: 44, borderRadius: "50%", background: C.primary, display: "flex", alignItems: "center", justifyContent: "center", border: "3px solid #fff", boxShadow: "0 4px 12px rgba(61,107,79,0.4)", animation: "bounce 1s ease-in-out infinite" }}>
            <span className="material-symbols-outlined" style={{ fontSize: 22, color: "#fff", fontVariationSettings: "'FILL' 1" }}>check_circle</span>
          </div>
        </div>

        <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 700, color: C.onSurface, margin: "0 0 12px", lineHeight: 1.25 }}>
          Your reel is live <span style={{ color: C.violet }}>✦</span>
        </h1>
        <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 16, fontStyle: "italic", color: C.onSurfaceVariant, margin: "0 0 36px", lineHeight: 1.6, maxWidth: 300 }}>
          Your craft has been shared with the community. Let the inspiration begin.
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, width: "100%", maxWidth: 300 }}>
          <button onClick={onViewFeed} style={{ padding: "14px", background: C.primary, color: "#fff", border: "none", borderRadius: 12, fontFamily: "'DM Sans'", fontSize: 14, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <span>View in feed</span>
            <span className="material-symbols-outlined" style={{ fontSize: 18 }}>arrow_forward</span>
          </button>
          <button onClick={onPostAnother} style={{ padding: "14px", background: "transparent", color: C.primary, border: `1px solid ${C.outline}`, borderRadius: 12, fontFamily: "'DM Sans'", fontSize: 14, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <span>Post another</span>
            <span className="material-symbols-outlined" style={{ fontSize: 18 }}>add</span>
          </button>
        </div>

        <div style={{ marginTop: 32, opacity: 0.2 }}>
          <span className="material-symbols-outlined" style={{ fontSize: 40, color: C.secondary }}>eco</span>
        </div>
      </div>
    </div>
  );
}

// ── Library view ──────────────────────────────────────────────────────────────
function LibraryView({ reels, onAdd, onEdit, onDelete }: { reels: Reel[]; onAdd: () => void; onEdit: (id: string) => void; onDelete: (id: string) => void }) {
  const visBadge = (v: string) => {
    if (v === "public") return { label: "Public", bg: "#E6F4EA", color: C.primary, border: "#3D6B4F30" };
    if (v === "store-only") return { label: "Store-Only", bg: "#F0F4F1", color: C.secondary, border: "#8FAF8230" };
    return { label: "Draft", bg: "#FEF3C7", color: "#92400e", border: "#C8973A30" };
  };

  return (
    <div style={{ padding: "16px 16px 32px" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 24, gap: 12 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
            <span style={{ fontFamily: "'DM Sans'", fontSize: 12, color: C.onSurfaceVariant }}>Catalog</span>
            <span className="material-symbols-outlined" style={{ fontSize: 14, color: C.onSurfaceVariant }}>chevron_right</span>
            <span style={{ fontFamily: "'DM Sans'", fontSize: 12, color: C.primary, fontWeight: 700 }}>My Reels</span>
          </div>
          <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: 24, fontWeight: 700, color: C.primary, margin: 0 }}>My Reels</h2>
        </div>
        <button onClick={onAdd} style={{ flexShrink: 0, display: "flex", alignItems: "center", gap: 6, padding: "10px 18px", background: C.forest, color: "#fff", border: "none", borderRadius: 99, fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 14px rgba(61,107,79,0.3)" }}>
          <span className="material-symbols-outlined" style={{ fontSize: 18 }}>add</span>
          Add Reel
        </button>
      </div>

      {/* Empty state */}
      {reels.length === 0 && (
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", padding: "48px 24px", background: "#fff", borderRadius: 16, border: `1px solid ${C.sage}66` }}>
          <div style={{ width: 64, height: 64, borderRadius: "50%", background: C.sage + "40", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
            <span className="material-symbols-outlined" style={{ fontSize: 32, color: C.primary }}>movie</span>
          </div>
          <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, color: C.primary, margin: "0 0 8px" }}>Grow your reach with Reels</h3>
          <p style={{ fontFamily: "'DM Sans'", fontSize: 13, color: C.onSurfaceVariant, margin: "0 0 20px", lineHeight: 1.6 }}>Share your making-of processes, stories, and showcase your craft directly to buyers.</p>
          <button onClick={onAdd} style={{ padding: "12px 28px", background: C.forest, color: "#fff", border: "none", borderRadius: 99, fontFamily: "'DM Sans'", fontSize: 14, fontWeight: 700, cursor: "pointer" }}>+ Upload Your First Reel</button>
        </div>
      )}

      {/* Reels grid */}
      {reels.length > 0 && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          {reels.map(reel => {
            const vis = visBadge(reel.visibility);
            return (
              <div key={reel.id} style={{ background: "#fff", borderRadius: 14, overflow: "hidden", border: `1px solid ${C.sage}66`, boxShadow: "0 2px 8px rgba(0,0,0,0.06)", display: "flex", flexDirection: "column" }}>
                {/* Thumbnail */}
                <div style={{ position: "relative", aspectRatio: "9/16", maxHeight: 220, overflow: "hidden", background: "#000", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  {reel.thumb
                    ? <img src={reel.thumb} alt={reel.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                    : <span className="material-symbols-outlined" style={{ fontSize: 40, color: C.sage }}>movie</span>
                  }
                  {/* Visibility badge */}
                  <div style={{ position: "absolute", top: 8, left: 8, background: vis.bg, color: vis.color, border: `1px solid ${vis.border}`, borderRadius: 99, padding: "2px 8px", fontSize: 9, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em" }}>{vis.label}</div>
                  {/* Views */}
                  <div style={{ position: "absolute", bottom: 8, left: 8, background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)", color: "#fff", borderRadius: 99, padding: "3px 8px", fontSize: 10, fontFamily: "'DM Sans'", display: "flex", alignItems: "center", gap: 4 }}>
                    <span className="material-symbols-outlined" style={{ fontSize: 13 }}>visibility</span>
                    {reel.views.toLocaleString()}
                  </div>
                </div>
                {/* Body */}
                <div style={{ padding: "10px 12px 12px", flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                  <div style={{ marginBottom: 10 }}>
                    <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 13, fontWeight: 700, color: C.primary, margin: "0 0 4px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{reel.title || "Untitled Reel"}</p>
                    <p style={{ fontFamily: "'DM Sans'", fontSize: 11, color: C.onSurfaceVariant, margin: 0, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", lineHeight: 1.4 }}>{reel.caption}</p>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", paddingTop: 8, borderTop: `1px solid ${C.sage}30` }}>
                    <button onClick={() => onEdit(reel.id)} style={{ display: "flex", alignItems: "center", gap: 4, padding: "5px 10px", background: `${C.sage}20`, color: C.primary, border: "none", borderRadius: 99, fontFamily: "'DM Sans'", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                      <span className="material-symbols-outlined" style={{ fontSize: 14 }}>edit_note</span>Edit
                    </button>
                    <button onClick={() => onDelete(reel.id)} style={{ display: "flex", alignItems: "center", gap: 4, padding: "5px 10px", background: "#fee2e2", color: "#dc2626", border: "none", borderRadius: 99, fontFamily: "'DM Sans'", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                      <span className="material-symbols-outlined" style={{ fontSize: 14 }}>delete</span>Delete
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Upload form ───────────────────────────────────────────────────────────────
function UploadForm({ editId, onBack, onPost }: { editId: string | null; onBack: () => void; onPost: () => void }) {
  const [uploadState, setUploadState] = useState<"idle" | "uploading" | "preview">("idle");
  const [progress, setProgress] = useState(0);
  const [title, setTitle] = useState("");
  const [caption, setCaption] = useState("");
  const [reelType, setReelType] = useState("process");
  const [seasonalTag, setSeasonalTag] = useState("");
  const [visibility, setVisibility] = useState("public");
  const [tags, setTags] = useState(["ceramics", "processvideo"]);
  const [tagInput, setTagInput] = useState("");
  const [audio, setAudio] = useState<"original" | "music">("original");
  const [selectedProducts, setSelectedProducts] = useState<Set<number>>(new Set());
  const [productSearch, setProductSearch] = useState("");
  const [posting, setPosting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const isEdit = editId !== null;

  const handleFilePick = () => fileRef.current?.click();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 30 * 1024 * 1024) { alert("Video exceeds 30 MB limit."); return; }
    setUploadState("uploading");
    setProgress(0);
    let p = 0;
    intervalRef.current = setInterval(() => {
      p += 10;
      setProgress(p);
      if (p >= 100) {
        if (intervalRef.current) clearInterval(intervalRef.current);
        setUploadState("preview");
      }
    }, 150);
  };

  const addTag = () => {
    const val = tagInput.replace(/#/g, "").trim().toLowerCase();
    if (val && !tags.includes(val)) setTags(prev => [...prev, val]);
    setTagInput("");
  };

  const handlePost = () => {
    if (!isEdit && uploadState !== "preview") { alert("Please select a video first."); return; }
    if (selectedProducts.size === 0) { alert("Please tag at least one product."); return; }
    setPosting(true);
    setTimeout(() => { setPosting(false); onPost(); }, 1000);
  };

  const circumference = 2 * Math.PI * 40;
  const strokeDashoffset = circumference - (circumference * progress) / 100;

  const filteredListings = MOCK_LISTINGS.filter(l => l.title.toLowerCase().includes(productSearch.toLowerCase()));

  return (
    <div style={{ padding: "16px 16px 100px" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 24, gap: 12 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
            <span style={{ fontFamily: "'DM Sans'", fontSize: 12, color: C.onSurfaceVariant }}>Catalog</span>
            <span className="material-symbols-outlined" style={{ fontSize: 14, color: C.onSurfaceVariant }}>chevron_right</span>
            <span style={{ fontFamily: "'DM Sans'", fontSize: 12, color: C.primary, fontWeight: 700 }}>{isEdit ? "Edit Reel" : "New Reel"}</span>
          </div>
          <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: 24, fontWeight: 700, color: C.primary, margin: 0 }}>{isEdit ? "Edit Reel" : "Upload Reel"}</h2>
        </div>
        <button onClick={onBack} style={{ flexShrink: 0, display: "flex", alignItems: "center", gap: 4, padding: "8px 14px", background: "transparent", color: C.primary, border: `1px solid ${C.sage}`, borderRadius: 99, fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
          <span className="material-symbols-outlined" style={{ fontSize: 14 }}>arrow_back</span>
          Library
        </button>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>

        {/* ── Video Upload Zone ── */}
        <div style={{ background: "#fff", borderRadius: 16, border: `1px solid ${C.sage}66`, padding: "18px 16px" }}>
          <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 16, fontWeight: 700, color: C.primary, margin: "0 0 14px", display: "flex", alignItems: "center", gap: 8 }}>
            <span className="material-symbols-outlined" style={{ fontSize: 18, fontVariationSettings: "'FILL' 1" }}>movie_edit</span>
            Video
          </h3>

          {uploadState === "idle" && (
            <button onClick={handleFilePick} style={{ width: "100%", minHeight: 180, borderRadius: 12, border: `1.5px dashed ${C.sage}`, background: `${C.parchment}50`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10, cursor: "pointer" }}>
              <div style={{ width: 56, height: 56, borderRadius: "50%", background: C.sage + "40", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <span className="material-symbols-outlined" style={{ fontSize: 28, color: C.primary, fontVariationSettings: "'FILL' 1" }}>movie_edit</span>
              </div>
              <div style={{ textAlign: "center" }}>
                <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 16, fontWeight: 700, color: C.onSurface, margin: "0 0 4px" }}>Tap to select your reel</p>
                <p style={{ fontFamily: "'DM Sans'", fontSize: 12, color: C.onSurfaceVariant, margin: 0 }}>MP4, MOV · max 30 MB · 9:16 recommended</p>
              </div>
              <span style={{ padding: "8px 20px", background: C.primary, color: "#fff", borderRadius: 99, fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 600 }}>Select from Files</span>
            </button>
          )}

          {uploadState === "uploading" && (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 180, gap: 14 }}>
              <div style={{ position: "relative", width: 90, height: 90 }}>
                <svg width="90" height="90" style={{ transform: "rotate(-90deg)" }}>
                  <circle cx="45" cy="45" r="40" fill="transparent" stroke={C.outlineVariant} strokeWidth="4" />
                  <circle cx="45" cy="45" r="40" fill="transparent" stroke={C.primary} strokeWidth="4" strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={strokeDashoffset} style={{ transition: "stroke-dashoffset 0.15s" }} />
                </svg>
                <span style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", fontFamily: "'Space Mono',monospace", fontSize: 14, color: C.primary, fontWeight: 700 }}>{progress}%</span>
              </div>
              <p style={{ fontFamily: "'Playfair Display',serif", fontSize: 14, fontStyle: "italic", color: C.primary }}>Spinning the thread...</p>
            </div>
          )}

          {uploadState === "preview" && (
            <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
              {/* 9:16 thumbnail preview */}
              <div style={{ flexShrink: 0, width: 90, aspectRatio: "9/16", borderRadius: 10, overflow: "hidden", background: "#000", position: "relative" }}>
                <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuC5VM4lUKEDHK5fa01g-G79ESVIQTcf3VUKlM9aBj-1LySkBCs-idXjV5Lsjae779XlW2AXejrn2ebhy_uR_fQ8Xj8TJTPEMjk5zJLjoqVuqY_2gPO84qvJmTjwuZMg1Lyo1TYDW4KqogHSaQoKdg0x2EchUlO9yeWoKMa_HA_qxFeqm_6scpRNxuMEfl7bmlQWQFmPp-83DKyD6SXpq8mpa_oDtZff-ixY07uzh5w4aDZ4FOkuHV0HD0NiHsXvl1-hx4XaJwm3Mg0" alt="thumb" style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.8 }} />
                <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <button style={{ background: "rgba(255,255,255,0.9)", color: C.primary, border: "none", borderRadius: 99, padding: "4px 10px", fontSize: 10, fontWeight: 700, cursor: "pointer" }}>Cover</button>
                </div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 18, color: C.primary, fontVariationSettings: "'FILL' 1" }}>check_circle</span>
                  <span style={{ fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 700, color: C.primary }}>Video ready</span>
                </div>
                <button onClick={handleFilePick} style={{ display: "flex", alignItems: "center", gap: 6, padding: "7px 14px", background: `${C.sage}20`, color: C.primary, border: "none", borderRadius: 99, fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 14 }}>refresh</span>Replace
                </button>
                <div style={{ marginTop: 10, padding: "10px 12px", background: `${C.sage}20`, borderRadius: 10, border: `1px solid ${C.sage}30` }}>
                  <p style={{ fontFamily: "'DM Sans'", fontSize: 11, fontStyle: "italic", color: C.secondary, margin: 0, display: "flex", alignItems: "flex-start", gap: 6, lineHeight: 1.5 }}>
                    <span className="material-symbols-outlined" style={{ fontSize: 14, flexShrink: 0 }}>tips_and_updates</span>
                    Reels 15–30 sec with process shots perform 40% better.
                  </p>
                </div>
              </div>
            </div>
          )}

          <input ref={fileRef} type="file" accept="video/*" style={{ display: "none" }} onChange={handleFileChange} />
        </div>

        {/* ── Reel Details ── */}
        <div style={{ background: "#fff", borderRadius: 16, border: `1px solid ${C.sage}66`, padding: "18px 16px", display: "flex", flexDirection: "column", gap: 16 }}>
          <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 16, fontWeight: 700, color: C.primary, margin: 0 }}>Reel Details</h3>

          <Field label="Title">
            <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Enter reel title…" style={inputStyle} />
          </Field>

          <Field label="Caption">
            <div style={{ position: "relative" }}>
              <textarea value={caption} onChange={e => setCaption(e.target.value.slice(0, 200))} placeholder="Tell the story of this process…" rows={4} style={{ ...inputStyle, resize: "none", lineHeight: 1.5 }} />
              <span style={{ position: "absolute", bottom: 10, right: 12, fontFamily: "'Space Mono',monospace", fontSize: 10, color: caption.length > 180 ? "#dc2626" : C.onSurfaceVariant }}>{caption.length}/200</span>
            </div>
          </Field>

          <Field label="Reel Type">
            <select value={reelType} onChange={e => setReelType(e.target.value)} style={selectStyle}>
              {[["process","Process (making of)"],["behind_the_scenes","Behind the Scenes"],["storytime","Storytime"],["qa","Q&A"],["tutorial","Tutorial"],["showcase","Product Showcase"],["other","Other"]].map(([v,l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </Field>

          <Field label="Seasonal Tag (Optional)">
            <input value={seasonalTag} onChange={e => setSeasonalTag(e.target.value)} placeholder="e.g. Diwali, Spring, Monsoon…" style={inputStyle} />
          </Field>

          <Field label="Visibility">
            <select value={visibility} onChange={e => setVisibility(e.target.value)} style={selectStyle}>
              <option value="public">Public (Everyone)</option>
              <option value="store-only">Store-Only (Followers/Visitors)</option>
              <option value="draft">Draft</option>
            </select>
          </Field>

          <Field label="Reel Tags">
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, padding: "10px 12px", border: `1px solid ${C.sage}40`, borderRadius: 10, background: `${C.parchment}50`, minHeight: 48, alignItems: "center" }}>
              {tags.map(t => (
                <span key={t} style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "4px 10px", background: C.sage + "40", color: C.secondary, borderRadius: 99, fontSize: 12, fontFamily: "'DM Sans'", fontWeight: 500 }}>
                  #{t}
                  <button onClick={() => setTags(prev => prev.filter(x => x !== t))} style={{ background: "transparent", border: "none", cursor: "pointer", padding: 0, display: "flex", alignItems: "center" }}>
                    <span className="material-symbols-outlined" style={{ fontSize: 14, color: C.outline }}>close</span>
                  </button>
                </span>
              ))}
              <input
                value={tagInput}
                onChange={e => setTagInput(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addTag(); } }}
                placeholder="Add tag…"
                style={{ border: "none", outline: "none", background: "transparent", fontFamily: "'DM Sans'", fontSize: 13, flex: 1, minWidth: 80 }}
              />
            </div>
          </Field>

          <Field label="Music & Audio">
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {[
                { key: "original" as const, icon: "mic", title: "Original Audio", sub: "Studio Ambience" },
                { key: "music" as const, icon: "music_note", title: "Artisan Melodies", sub: "Nature-inspired" },
              ].map(opt => (
                <button key={opt.key} onClick={() => setAudio(opt.key)} style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px", borderRadius: 10, border: audio === opt.key ? `2px solid ${C.primary}` : `1px solid ${C.outlineVariant}`, background: audio === opt.key ? `${C.sage}25` : "transparent", cursor: "pointer", textAlign: "left", transition: "all 0.15s" }}>
                  <span className="material-symbols-outlined" style={{ fontSize: 20, color: audio === opt.key ? C.primary : C.onSurfaceVariant }}>{opt.icon}</span>
                  <div>
                    <p style={{ fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 700, color: C.onSurface, margin: "0 0 2px" }}>{opt.title}</p>
                    <p style={{ fontFamily: "'DM Sans'", fontSize: 10, color: C.onSurfaceVariant, margin: 0 }}>{opt.sub}</p>
                  </div>
                </button>
              ))}
            </div>
          </Field>
        </div>

        {/* ── Tag Products ── */}
        <div style={{ background: "#fff", borderRadius: 16, border: `1px solid ${C.sage}66`, padding: "18px 16px" }}>
          <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: 16, fontWeight: 700, color: C.primary, margin: "0 0 4px" }}>
            Tag Products <span style={{ color: "#dc2626", marginLeft: 2 }}>*</span>
          </h3>
          <p style={{ fontFamily: "'DM Sans'", fontSize: 12, color: C.onSurfaceVariant, margin: "0 0 14px" }}>Link items from your catalog to make this reel shoppable.</p>

          <div style={{ position: "relative", marginBottom: 14 }}>
            <span className="material-symbols-outlined" style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", fontSize: 18, color: C.onSurfaceVariant }}>search</span>
            <input value={productSearch} onChange={e => setProductSearch(e.target.value)} placeholder="Search Catalog…" style={{ ...inputStyle, paddingLeft: 38, borderRadius: 99 }} />
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 8, maxHeight: 240, overflowY: "auto", scrollbarWidth: "none" }}>
            {filteredListings.map(l => {
              const sel = selectedProducts.has(l.id);
              return (
                <div key={l.id} onClick={() => setSelectedProducts(prev => { const n = new Set(prev); sel ? n.delete(l.id) : n.add(l.id); return n; })}
                  style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 10px", borderRadius: 10, border: sel ? `2px solid ${C.primary}` : `1px solid ${C.outlineVariant}`, background: sel ? `${C.sage}15` : "#fff", cursor: "pointer", transition: "all 0.15s" }}>
                  <div style={{ width: 44, height: 44, borderRadius: 8, overflow: "hidden", flexShrink: 0 }}>
                    <img src={l.image} alt={l.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontFamily: "'DM Sans'", fontSize: 13, fontWeight: 700, color: C.primary, margin: "0 0 2px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{l.title}</p>
                    <p style={{ fontFamily: "'Space Mono',monospace", fontSize: 11, color: C.gold, margin: 0 }}>{l.price}</p>
                  </div>
                  <span style={{ padding: "4px 10px", borderRadius: 99, border: `1px solid ${C.primary}`, background: sel ? C.primary : "transparent", color: sel ? "#fff" : C.primary, fontSize: 11, fontFamily: "'DM Sans'", fontWeight: 700, flexShrink: 0 }}>{sel ? "Tagged" : "Tag"}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* ── Footer actions ── */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10, paddingTop: 8 }}>
          <button onClick={() => { setVisibility("draft"); handlePost(); }} style={{ padding: "14px", background: "transparent", color: C.primary, border: `1px solid ${C.sage}`, borderRadius: 99, fontFamily: "'DM Sans'", fontSize: 14, fontWeight: 700, cursor: "pointer" }}>
            Save Draft
          </button>
          <button onClick={handlePost} disabled={posting} style={{ padding: "14px", background: posting ? C.sage : C.forest, color: "#fff", border: "none", borderRadius: 99, fontFamily: "'DM Sans'", fontSize: 14, fontWeight: 700, cursor: posting ? "default" : "pointer", boxShadow: "0 4px 14px rgba(61,107,79,0.35)", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, transition: "background 0.2s" }}>
            {posting ? <><span className="material-symbols-outlined" style={{ fontSize: 18, animation: "spin 0.9s linear infinite" }}>sync</span>Posting…</> : `${isEdit ? "Save Changes" : "Post Reel"} 🌸`}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── App ───────────────────────────────────────────────────────────────────────
export default function App() {
  const [view, setView] = useState<View>("library");
  const [editId, setEditId] = useState<string | null>(null);
  const [reels, setReels] = useState(MOCK_REELS);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; type: "success" | "error" } | null>(null);
  const [activeNav, setActiveNav] = useState("reels");

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleDelete = (id: string) => setDeleteId(id);

  const confirmDelete = () => {
    setReels(prev => prev.filter(r => r.id !== deleteId));
    setDeleteId(null);
    showToast("Reel deleted successfully! 🌸");
  };

  const handleEdit = (id: string) => { setEditId(id); setView("upload"); };
  const handleAdd = () => { setEditId(null); setView("upload"); };

  return (
    <div style={{ fontFamily: "'DM Sans',sans-serif", background: C.parchment, minHeight: "100vh", maxWidth: 430, margin: "0 auto", display: "flex", flexDirection: "column" }}>

      {/* Top App Bar */}
      <header style={{ position: "sticky", top: 0, zIndex: 50, background: "#fff", borderBottom: `1px solid ${C.sage}66`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px", height: 58, flexShrink: 0 }}>
        <span style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, fontStyle: "italic", color: C.primary }}>
          Tohfa<span style={{ color: C.gold }}>.</span>
          <span style={{ fontFamily: "'DM Sans'", fontSize: 12, fontStyle: "normal", color: C.onSurfaceVariant, marginLeft: 6 }}>Seller Studio</span>
        </span>
        <div style={{ display: "flex", alignItems: "center", gap: 2 }}>
          <button style={{ background: "transparent", border: "none", cursor: "pointer", padding: 8, display: "flex" }}>
            <span className="material-symbols-outlined" style={{ color: C.primary, fontSize: 22 }}>notifications</span>
          </button>
          <div style={{ width: 32, height: 32, borderRadius: "50%", background: C.primary, display: "flex", alignItems: "center", justifyContent: "center", marginLeft: 4 }}>
            <span style={{ fontFamily: "'DM Sans'", fontSize: 12, fontWeight: 700, color: "#fff" }}>EW</span>
          </div>
        </div>
      </header>

      {/* Content */}
      <div style={{ flex: 1, overflowY: "auto" }}>
        {view === "library" && (
          <LibraryView reels={reels} onAdd={handleAdd} onEdit={handleEdit} onDelete={handleDelete} />
        )}
        {view === "upload" && (
          <UploadForm editId={editId} onBack={() => setView("library")} onPost={() => setView("success")} />
        )}
        {view === "success" && (
          <SuccessScreen onViewFeed={() => setView("library")} onPostAnother={() => { setEditId(null); setView("upload"); }} />
        )}
      </div>

      {/* Seller Bottom Nav */}
      <nav style={{ position: "sticky", bottom: 0, zIndex: 50, background: "#fff", borderTop: `1px solid ${C.sage}66`, display: "flex", alignItems: "center", height: 62, flexShrink: 0 }}>
        {[
          { key: "dashboard", icon: "dashboard", label: "Dashboard" },
          { key: "catalog", icon: "storefront", label: "Catalog" },
          { key: "reels", icon: "movie", label: "Reels" },
          { key: "orders", icon: "receipt_long", label: "Orders" },
          { key: "profile", icon: "person", label: "Profile" },
        ].map(item => (
          <button key={item.key} onClick={() => setActiveNav(item.key)} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 2, background: "transparent", border: "none", cursor: "pointer", color: activeNav === item.key ? C.primary : C.outline, position: "relative", padding: "6px 0" }}>
            <span className="material-symbols-outlined" style={{ fontSize: 22, fontVariationSettings: activeNav === item.key ? "'FILL' 1" : "'FILL' 0" }}>{item.icon}</span>
            <span style={{ fontFamily: "'DM Sans'", fontSize: 9, fontWeight: activeNav === item.key ? 700 : 400 }}>{item.label}</span>
            {activeNav === item.key && <div style={{ position: "absolute", bottom: 0, width: 20, height: 3, background: C.primary, borderRadius: "3px 3px 0 0" }} />}
          </button>
        ))}
      </nav>

      {/* Delete modal */}
      {deleteId && <DeleteModal onConfirm={confirmDelete} onCancel={() => setDeleteId(null)} />}

      {/* Toast */}
      {toast && <Toast msg={toast.msg} type={toast.type} />}

      <style>{`@keyframes spin{to{transform:rotate(360deg)}} @keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}} *{-webkit-tap-highlight-color:transparent;box-sizing:border-box} ::-webkit-scrollbar{display:none}`}</style>
    </div>
  );
}
