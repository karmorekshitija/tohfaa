<!DOCTYPE html>
<html class="light" lang="en">
<head>
<script src="/src/components/ReportWidget.js" defer></script>
<script src="/src/components/ProtectedRoute.js"></script>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Tohfa Artisan Studio - Catalog</title>
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&amp;family=DM+Sans:wght@400;500;700&amp;family=Cinzel:wght@700&amp;family=Space+Mono:wght@400;700&amp;family=Merriweather:wght@400;700&amp;display=swap" rel="stylesheet"/>
<!-- Material Symbols -->
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<script src="/components/seller-components.js"></script>
<script id="tailwind-config">
  tailwind.config = {
    darkMode: "class",
    theme: {
      extend: {
        "colors": {
                "tertiary-container": "#7B5EA7",
                "surface-tint": "#3a684c",
                "surface-container-high": "#f3e6d6",
                "on-secondary-container": "#4d6a43",
                "background": "#FFFFFF",
                "secondary-container": "#8FAF82",
                "on-surface-variant": "#414942",
                "on-surface": "#211b11",
                "surface": "#FFFFFF",
                "primary-container": "#3d6b4f",
                "on-secondary-fixed-variant": "#324e29",
                "secondary": "#49663f",
                "on-error-container": "#3D6B4F",
                "outline-variant": "#F7F3EC",
                "on-tertiary": "#ffffff",
                "surface-dim": "#e5d8c8",
                "secondary-fixed": "#caecbb",
                "inverse-on-surface": "#fcefde",
                "on-primary-container": "#b7e9c6",
                "on-primary": "#ffffff",
                "secondary-fixed-dim": "#afd0a0",
                "inverse-surface": "#362f25",
                "primary-fixed-dim": "#a0d2b0",
                "inverse-primary": "#a0d2b0",
                "on-background": "#211b11",
                "surface-container": "#f9ecdc",
                "surface-bright": "#FFFFFF",
                "on-primary-fixed-variant": "#214f36",
                "primary-fixed": "#bceecb",
                "primary": "#3D6B4F",
                "tertiary-fixed-dim": "#d6baff",
                "on-primary-fixed": "#002110",
                "surface-container-highest": "#F7F3EC",
                "on-secondary": "#ffffff",
                "on-tertiary-container": "#e8d6ff",
                "surface-container-low": "#fff2e1",
                "error": "#3D6B4F",
                "error-container": "#F7F3EC",
                "tertiary-fixed": "#ecdcff",
                "surface-container-lowest": "#ffffff",
                "outline": "#717972",
                "on-tertiary-fixed-variant": "#54387e",
                "tertiary": "#7B5EA7",
                "on-secondary-fixed": "#062103",
                "on-tertiary-fixed": "#270550",
                "on-error": "#ffffff",
                "surface-variant": "#F7F3EC",
                "forest": "#3D6B4F",
                "sage": "#8FAF82",
                "gold": "#C8973A",
                "parchment": "#F7F3EC",
                "violet": "#7B5EA7"
        },
        "borderRadius": {
                "DEFAULT": "0.25rem",
                "lg": "0.5rem",
                "xl": "0.75rem",
                "full": "9999px"
        },
        "spacing": {
                "xl": "40px",
                "sm": "8px",
                "margin-mobile": "20px",
                "margin-desktop": "64px",
                "xs": "4px",
                "gutter": "16px",
                "unit": "4px",
                "md": "16px",
                "lg": "24px"
        },
        "fontFamily": {
                "display-hero": ["Playfair Display"],
                "headline-lg-mobile": ["Playfair Display"],
                "headline-lg": ["Playfair Display"],
                "body-md": ["DM Sans"],
                "label-caps": ["Cinzel"],
                "data-price": ["Space Mono"],
                "title-serif": ["Merriweather"]
        },
        "fontSize": {
                "display-hero": ["48px", {"lineHeight": "56px", "fontWeight": "300"}],
                "headline-lg-mobile": ["28px", {"lineHeight": "36px", "fontWeight": "400"}],
                "headline-lg": ["32px", {"lineHeight": "40px", "fontWeight": "400"}],
                "body-md": ["16px", {"lineHeight": "24px", "fontWeight": "400"}],
                "label-caps": ["12px", {"lineHeight": "16px", "letterSpacing": "0.1em", "fontWeight": "700"}],
                "data-price": ["14px", {"lineHeight": "20px", "fontWeight": "500"}],
                "title-serif": ["18px", {"lineHeight": "24px", "fontWeight": "700"}]
        }
      },
    },
  }
</script>
<style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        .header-glow {
            background: radial-gradient(circle at top right, rgba(200, 233, 184, 0.2) 0%, transparent 60%);
        }
        .card-shadow {
            box-shadow: 0 4px 20px -2px rgba(58, 51, 40, 0.08);
        }
        .modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:200; display:flex; align-items:center; justify-content:center; backdrop-filter: blur(4px); }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        @keyframes shimmer { 0% { background-position: -400px 0; } 100% { background-position: 400px 0; } }
        .skeleton { background: linear-gradient(90deg,#f9ecdc 25%,#F7F3EC 50%,#f9ecdc 75%); background-size: 400px 100%; animation: shimmer 1.4s infinite; border-radius: 12px; }
        @keyframes fadeIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:none; } }
        .fade-in { animation: fadeIn 0.3s ease forwards; }

        /* Override global min-width/min-height constraints from responsive.css for toggle switches */
        button.relative.inline-flex.h-5.w-8 {
            min-height: 0 !important;
            min-width: 0 !important;
        }
    </style>

<!-- Mobile Style Overrides -->
<style>
  @media (max-width: 768px) {
    /* Stack grid & flex items */
    .grid, [class*="grid-cols-"], .flex-row, .md\:flex-row {
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
    }
    /* Let card items span full width */
    .col-span-1, .col-span-2, .col-span-3, .col-span-4, .col-span-5, .col-span-6,
    .col-span-7, .col-span-8, .col-span-9, .col-span-10, .col-span-11, .col-span-12,
    .lg\:col-span-1, .lg\:col-span-2, .lg\:col-span-3, .lg\:col-span-4,
    .lg\:col-span-5, .lg\:col-span-6, .lg\:col-span-7, .lg\:col-span-8,
    .lg\:col-span-9, .lg\:col-span-10, .lg\:col-span-11, .lg\:col-span-12 {
      grid-column: span 12 / span 12 !important;
      width: 100% !important;
    }
    /* Set min spacing */
    .grid > div, .flex > div, .space-y-lg > div, .space-y-md > div {
      margin-top: 12px;
    }
    /* Enforce playfair display for headings */
    h1, h2, h3, h4, h5, h6 {
      font-family: 'Playfair Display', serif !important;
    }
  }
</style>

</head>
<body class="bg-white text-on-surface font-body-md selection:bg-secondary-container">

<seller-layout active-tab="catalog">
  <!-- Top row: Stats, Search, Download Report, and New Listing -->
  <div class="bg-parchment/60 border-b border-sage/10 py-6 px-4 md:px-12 z-10 mb-8">
    <div class="max-w-7xl mx-auto flex justify-between items-center flex-wrap gap-4">
      <!-- Left side: Stats -->
      <div class="flex items-center gap-4 flex-wrap justify-center">
        <div class="bg-primary/10 px-4 py-2 rounded-lg border border-sage/20">
          <span class="text-[10px] font-bold text-forest uppercase tracking-widest block">Total Listings</span>
          <span class="font-display-hero text-2xl text-primary leading-tight" id="stats-total-listings">—</span>
        </div>
        <div class="bg-gold/10 px-4 py-2 rounded-lg border border-gold/20">
          <span class="text-[10px] font-bold text-gold uppercase tracking-widest block">Low Stock</span>
          <span class="font-display-hero text-2xl text-gold leading-tight" id="stats-low-stock">—</span>
        </div>
        <div class="bg-violet/10 px-4 py-2 rounded-lg border border-violet/20">
          <span class="text-[10px] font-bold text-violet uppercase tracking-widest block">On Discount</span>
          <span class="font-display-hero text-2xl text-violet leading-tight" id="stats-on-discount">—</span>
        </div>
      </div>
      
      <!-- Right side: Actions & Search -->
      <div class="flex items-center gap-4 flex-wrap">
        <!-- Download Report -->
        <button id="download-report-btn" class="px-5 py-2 bg-white border border-[#F7F3EC] rounded-full text-xs font-bold text-on-surface-variant hover:bg-[#8FAF82]/10 transition-all flex items-center gap-1.5 active:scale-95">
          <span class="material-symbols-outlined text-sm">download</span> Download Report
        </button>
        <!-- New Listing Option -->
        <button id="header-create-listing-btn" class="px-5 py-2 bg-forest text-white rounded-full text-xs font-bold shadow-md hover:bg-forest/90 transition-all flex items-center gap-1 active:scale-95">
          <span class="material-symbols-outlined text-sm">add</span> New Listing
        </button>
        <!-- Search Input -->
        <div class="relative flex items-center bg-white border border-[#F7F3EC] rounded-full px-4 py-1.5 focus-within:border-primary transition-colors w-64">
          <span class="material-symbols-outlined text-on-surface-variant text-lg mr-2">search</span>
          <input id="search-input" class="bg-transparent border-none outline-none text-body-sm w-full focus:ring-0" placeholder="Search entries..." type="text"/>
        </div>
      </div>
    </div>
  </div>

  <!-- Toast notification -->
  <div id="toast" class="hidden fixed top-20 right-6 z-[300] flex items-center gap-3 px-5 py-3 rounded-xl shadow-lg text-sm font-medium transition-all">
      <span id="toast-icon" class="material-symbols-outlined text-lg"></span>
      <span id="toast-msg"></span>
  </div>

  <!-- Main Grid Content (Table on left, Sidebar on right) -->
  <div class="max-w-[1440px] mx-auto px-margin-desktop flex flex-col lg:flex-row gap-xl items-start pb-12">
    <!-- Left Panel (Table) -->
    <div class="flex-1 space-y-8 min-w-0">
      <!-- Filter & Sort Row -->
      <section class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-outline-variant pb-3 mb-6">
        <div class="flex flex-col sm:flex-row items-start sm:items-center gap-lg w-full md:w-auto">
          <!-- Status Filter -->
          <div class="flex items-center gap-sm">
            <span class="font-label-caps text-on-surface-variant text-[11px] font-bold tracking-wider uppercase">Status:</span>
            <select id="status-select" class="bg-transparent border-none font-body-md text-[#3D6B4F] font-semibold focus:ring-0 cursor-pointer pr-8 py-1 rounded hover:bg-[#8FAF82]/10 transition-colors">
              <option value="all">All Statuses</option>
              <option value="active">Active</option>
              <option value="paused">Paused</option>
              <option value="draft">Drafts</option>
            </select>
          </div>

          <!-- Category Filter -->
          <div class="flex items-center gap-sm">
            <span class="font-label-caps text-on-surface-variant text-[11px] font-bold tracking-wider uppercase">Category:</span>
            <select id="category-select" class="bg-transparent border-none font-body-md text-[#3D6B4F] font-semibold focus:ring-0 cursor-pointer pr-8 py-1 rounded hover:bg-[#8FAF82]/10 transition-colors">
              <option value="all">All Categories</option>
            </select>
          </div>
        </div>

        <!-- Sort Filter -->
        <div class="flex items-center gap-sm">
          <span class="font-label-caps text-on-surface-variant text-[11px] font-bold tracking-wider uppercase">Sort By:</span>
          <select id="sort-select" class="bg-transparent border-none font-body-md text-[#3D6B4F] font-semibold focus:ring-0 cursor-pointer pr-8 py-1 rounded hover:bg-[#8FAF82]/10 transition-colors">
            <option value="newest">Newest First</option>
            <option value="best_selling">Best Selling</option>
            <option value="price_high">Price High–Low</option>
            <option value="capacity_low">Capacity Low–High</option>
          </select>
        </div>
      </section>

      <!-- Error State -->
      <div id="error-state" class="hidden flex flex-col items-center justify-center py-24 gap-4 bg-white/60 rounded-xl border border-sage/20">
          <span class="material-symbols-outlined text-5xl text-error">error_outline</span>
          <p id="error-msg" class="text-on-surface-variant text-sm">Failed to load listings.</p>
          <button id="retry-btn" class="bg-primary text-on-primary py-2.5 px-8 rounded-full font-semibold text-sm hover:opacity-90 transition-all">Try Again</button>
      </div>

      <!-- Loading Skeleton -->
      <div id="loading-state" class="bg-white/60 rounded-xl border border-sage/20 p-6 space-y-4">
          <div class="skeleton h-12 w-full"></div>
          <div class="skeleton h-12 w-full"></div>
          <div class="skeleton h-12 w-full"></div>
          <div class="skeleton h-12 w-full"></div>
      </div>

      <!-- Empty State -->
      <div id="empty-state" class="hidden flex flex-col items-center justify-center py-24 gap-4 bg-white/60 rounded-xl border border-sage/20">
          <span class="material-symbols-outlined text-5xl text-outline">storefront</span>
          <p class="text-on-surface-variant font-body-md text-center">No listings found.<br/>Create your first listing to get started.</p>
          <button id="empty-create-btn" class="bg-primary text-on-primary py-2.5 px-8 rounded-full font-semibold text-sm hover:opacity-90 transition-all shadow-md">Create Listing</button>
      </div>

      <!-- Bulk Discount Bar -->
      <div id="bulk-discount-bar" class="hidden w-full mb-4 px-6 py-4 bg-parchment border border-sage rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm fade-in">
        <div class="flex items-center gap-4 flex-wrap">
          <span class="text-xs font-semibold text-on-surface-variant" id="bulk-count-text">Apply discount to N selected items</span>
          <div class="flex items-center gap-2">
            <input type="number" min="1" max="90" placeholder="e.g. 15" id="bulk-discount-input" class="w-16 px-2 py-1 border border-sage/30 rounded text-center text-xs focus:ring-1 focus:ring-forest focus:border-forest"/>
            <span class="text-xs font-semibold text-on-surface-variant">%</span>
          </div>
          <button id="bulk-apply-btn" class="px-4 py-1.5 bg-forest text-white rounded-full text-xs font-bold shadow hover:bg-forest/90 transition-all active:scale-95" onclick="applyBulkDiscount()">
            Apply
          </button>
          <button id="bulk-clear-btn" class="px-4 py-1.5 border border-outline rounded-full text-xs font-bold text-on-surface-variant hover:bg-[#8FAF82]/10 transition-all active:scale-95" onclick="clearBulkDiscount()">
            Clear all discounts
          </button>
        </div>
        <button class="text-on-surface-variant hover:text-on-surface transition-colors flex items-center" onclick="dismissBulkBar()">
          <span class="material-symbols-outlined text-lg">close</span>
        </button>
      </div>

      <!-- Table View -->
      <div id="listings-table-container" class="hidden bg-white/60 rounded-xl border border-sage/20 shadow-sm overflow-x-auto">
        <table class="w-full text-left border-collapse min-w-[800px]">
          <thead>
            <tr class="bg-surface-container-low/40 border-b border-sage/20">
              <th class="py-4 px-3 w-12 text-center">
                <input type="checkbox" id="select-all-listings" class="rounded border-sage/30 text-forest focus:ring-forest bg-background w-4 h-4 cursor-pointer" onclick="toggleSelectAll()"/>
              </th>
              <th class="py-4 px-4 font-label-caps uppercase text-on-surface-variant text-[10px]">Product</th>
              <th class="py-4 px-3 font-label-caps uppercase text-on-surface-variant text-[10px]">Price</th>
              <th class="py-4 px-3 font-label-caps uppercase text-on-surface-variant text-[10px]">
                Discount
                <button id="apply-to-all-link" class="block text-[9px] text-on-surface-variant/60 underline hover:text-violet transition-colors font-sans mt-0.5">Apply to all</button>
              </th>
              <th class="py-4 px-3 font-label-caps uppercase text-on-surface-variant text-[10px]">Stock Units</th>
              <th class="py-4 px-3 font-label-caps uppercase text-on-surface-variant text-[10px]">Status</th>
              <th class="py-4 px-4 text-right font-label-caps uppercase text-on-surface-variant text-[10px]">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-sage/10 font-body-sm" id="listings-table-body">
            <!-- Dynamically Populated -->
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <div id="pagination" class="hidden flex justify-center gap-3 mt-10">
          <button id="prev-btn" class="px-6 py-2 border border-outline rounded-full text-sm font-semibold hover:bg-surface-container transition-colors disabled:opacity-40" disabled>← Prev</button>
          <span id="page-label" class="px-6 py-2 text-sm text-on-surface-variant self-center"></span>
          <button id="next-btn" class="px-6 py-2 border border-outline rounded-full text-sm font-semibold hover:bg-surface-container transition-colors disabled:opacity-40">Next →</button>
      </div>
    </div>

    <!-- Right Sidebar -->
    <aside class="w-full lg:w-80 border border-sage/20 bg-white/60 rounded-xl p-6 flex flex-col gap-6 shrink-0 shadow-sm">
    </aside>
  </div>
</seller-layout>

<!-- Floating Action Button for Support/Help -->
<button class="fixed bottom-lg right-lg w-14 h-14 bg-tertiary text-on-tertiary rounded-full shadow-lg flex items-center justify-center hover:scale-105 active:scale-95 transition-transform z-50">
<span class="material-symbols-outlined">auto_fix</span>
</button>

<script>
const API_BASE = window.location.origin;
let currentPage  = 1;
let searchQuery  = '';
let searchTimer  = null;
let totalListings = 0;
const PAGE_LIMIT = 9;
let allListings = [];
let filteredListings = [];
let editingDiscounts = {}; // listing_id -> true
let selectedListings = {}; // listing_id -> true
let bulkDiscountTrigger = null; // 'checkboxes' or 'apply-to-all'

// ── Discount & Selection Helpers ──────────────────────────────
async function loadStats() {
    const token = sessionStorage.getItem('tohfa_access_token') || sessionStorage.getItem('access_token');
    if (token) {
        try {
            const res = await fetch(`${API_BASE}/api/seller/catalog/summary`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (res.ok) {
                const resp = await res.json();
                if (resp && resp.data) {
                    document.getElementById('stats-total-listings').textContent = resp.data.total_listings;
                    document.getElementById('stats-low-stock').textContent = resp.data.low_stock;
                    document.getElementById('stats-on-discount').textContent = resp.data.on_discount;
                    return;
                }
            }
        } catch (err) {
            console.warn('Failed to fetch stats summary, using client-side fallback:', err);
        }
    }
    // Fallback:
    const totalListings = allListings.length;
    const lowStock = allListings.filter(l => l.stock_count <= 5).length;
    const onDiscount = allListings.filter(l => l.discount_active === true || l.discount_active === 1).length;
    document.getElementById('stats-total-listings').textContent = totalListings;
    document.getElementById('stats-low-stock').textContent = lowStock;
    document.getElementById('stats-on-discount').textContent = onDiscount;
}

function startEditDiscount(id) {
    editingDiscounts[id] = true;
    applyFiltersAndRender();
}

async function saveDiscount(id) {
    const input = document.getElementById(`discount-input-${id}`);
    if (!input) return;
    const val = parseInt(input.value);
    if (isNaN(val) || val < 1 || val > 90) {
        showToast('Discount percentage must be between 1 and 90.', 'error');
        return;
    }
    await applyDiscountAPI(id, val, true);
}

async function toggleDiscount(id, targetActive) {
    if (targetActive) {
        const input = document.getElementById(`discount-input-${id}`);
        const val = input ? parseInt(input.value) : null;
        if (!val || isNaN(val) || val < 1 || val > 90) {
            showToast('Enter a valid discount percentage (1–90) before enabling.', 'error');
            return;
        }
        await applyDiscountAPI(id, val, true);
    } else {
        await applyDiscountAPI(id, null, false);
    }
}

async function applyDiscountAPI(id, percentage, active) {
    const token = sessionStorage.getItem('tohfa_access_token') || sessionStorage.getItem('access_token');
    try {
        const body = { discount_active: active };
        if (active) {
            body.discount_percentage = percentage;
        }
        const res = await fetch(`${API_BASE}/api/seller/listings/${id}/discount`, {
            method: 'PATCH',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(body)
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Failed to update discount');
        
        const listing = allListings.find(l => String(l.listing_id) === String(id) || String(l.id) === String(id));
        if (listing) {
            listing.discount_active = active;
            listing.discount_percentage = active ? percentage : null;
            listing.discounted_price = active ? data.data.discounted_price : null;
        }
        
        delete editingDiscounts[id];
        showToast(active ? 'Discount applied!' : 'Discount removed!', 'success');
        applyFiltersAndRender();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

function toggleRowSelection(id) {
    if (selectedListings[id]) {
        delete selectedListings[id];
    } else {
        selectedListings[id] = true;
    }
    updateBulkBarUI();
}

function toggleSelectAll() {
    const selectAllCheckbox = document.getElementById('select-all-listings');
    if (!selectAllCheckbox) return;
    
    const isChecked = selectAllCheckbox.checked;
    const pageListings = filteredListings.slice((currentPage - 1) * PAGE_LIMIT, currentPage * PAGE_LIMIT);
    
    pageListings.forEach(l => {
        if (isChecked) {
            selectedListings[l.listing_id] = true;
        } else {
            delete selectedListings[l.listing_id];
        }
    });
    
    document.querySelectorAll('.listing-checkbox').forEach(cb => {
        cb.checked = isChecked;
    });
    
    updateBulkBarUI();
}

function updateBulkBarUI() {
    const selectedIds = Object.keys(selectedListings);
    const count = selectedIds.length;
    const bulkBar = document.getElementById('bulk-discount-bar');
    if (!bulkBar) return;
    
    const selectAllCheckbox = document.getElementById('select-all-listings');
    if (selectAllCheckbox) {
        const pageListings = filteredListings.slice((currentPage - 1) * PAGE_LIMIT, currentPage * PAGE_LIMIT);
        const allPageSelected = pageListings.length > 0 && pageListings.every(l => selectedListings[l.listing_id]);
        selectAllCheckbox.checked = allPageSelected;
    }
    
    if (count > 0 || bulkDiscountTrigger === 'apply-to-all') {
        bulkBar.classList.remove('hidden');
        const countText = bulkDiscountTrigger === 'apply-to-all' 
            ? 'all active items' 
            : `${count} selected item${count !== 1 ? 's' : ''}`;
        document.getElementById('bulk-count-text').textContent = `Apply discount to ${countText}`;
    } else {
        bulkBar.classList.add('hidden');
    }
}

async function applyBulkDiscount() {
    const input = document.getElementById('bulk-discount-input');
    if (!input) return;
    const val = parseInt(input.value);
    if (isNaN(val) || val < 1 || val > 90) {
        showToast('Discount percentage must be between 1 and 90.', 'error');
        return;
    }
    
    const token = sessionStorage.getItem('tohfa_access_token') || sessionStorage.getItem('access_token');
    try {
        let res;
        if (bulkDiscountTrigger === 'apply-to-all') {
            res = await fetch(`${API_BASE}/api/seller/listings/bulk-discount-all`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    discount_percentage: val,
                    discount_active: true
                })
            });
        } else {
            const ids = Object.keys(selectedListings);
            res = await fetch(`${API_BASE}/api/seller/listings/bulk-discount`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    product_ids: ids,
                    discount_percentage: val,
                    discount_active: true
                })
            });
        }
        
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Failed to apply bulk discount');
        
        showToast('Bulk discount applied successfully!', 'success');
        dismissBulkBar();
        await loadListings(true);
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function clearBulkDiscount() {
    const token = sessionStorage.getItem('tohfa_access_token') || sessionStorage.getItem('access_token');
    try {
        let res;
        if (bulkDiscountTrigger === 'apply-to-all') {
            res = await fetch(`${API_BASE}/api/seller/listings/bulk-discount-all`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    discount_active: false
                })
            });
        } else {
            const ids = Object.keys(selectedListings);
            res = await fetch(`${API_BASE}/api/seller/listings/bulk-discount`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    product_ids: ids,
                    discount_active: false
                })
            });
        }
        
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Failed to clear discounts');
        
        showToast('Discounts cleared successfully!', 'success');
        dismissBulkBar();
        await loadListings(true);
    } catch (err) {
        showToast(err.message, 'error');
    }
}

function dismissBulkBar() {
    selectedListings = {};
    bulkDiscountTrigger = null;
    const selectAll = document.getElementById('select-all-listings');
    if (selectAll) selectAll.checked = false;
    document.querySelectorAll('.listing-checkbox').forEach(cb => cb.checked = false);
    updateBulkBarUI();
}

// ── Utilities ─────────────────────────────────────────────────
function formatPaise(p) {
    if (p == null) return '₹0';
    return '₹' + (p / 100).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function showToast(msg, type = 'success') {
    const t = document.getElementById('toast');
    document.getElementById('toast-icon').textContent = type === 'success' ? 'check_circle' : 'error';
    document.getElementById('toast-msg').textContent  = msg;
    t.className = `fixed top-20 right-6 z-[300] flex items-center gap-3 px-5 py-3 rounded-xl shadow-lg text-sm font-medium transition-all ${
        type === 'success'
            ? 'bg-secondary-container text-on-secondary-container border border-secondary-container/50'
            : 'bg-error-container text-on-error-container border border-error/30'
    }`;
    t.classList.remove('hidden');
    setTimeout(() => t.classList.add('hidden'), 3500);
}

function statusBadge(status, stock) {
    if (stock === 0 && status === 'active') return '<span class="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-tighter text-error bg-error-container">Out of Stock</span>';
    const m = {
        active: 'bg-primary-container text-on-primary-container',
        draft:  'bg-surface-container-high text-on-surface-variant',
        paused: 'bg-secondary-container text-on-secondary-container'
    };
    const l = { active:'Active', draft:'Draft', paused:'Paused' };
    return `<span class="text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-tighter ${m[status] || 'bg-surface-container text-on-surface-variant'}">${l[status] || status}</span>`;
}

function rowHTML(l) {
    const img = l.cover_photo_url
        ? `<img src="${l.cover_photo_url}" alt="${l.title}" class="w-full h-full object-cover"/>`
        : `<div class="w-full h-full flex items-center justify-center bg-surface-container-high"><span class="material-symbols-outlined text-xl text-outline">image</span></div>`;
    
    // Stock Units — numbers only, red if 0 or ≤5 (skip threshold for custom orders)
    const isCustom = l.listing_type === 'custom';
    let stockColor;
    if (l.stock_count === 0) {
        stockColor = 'text-rose-600 font-bold';
    } else if (!isCustom && l.stock_count <= 5) {
        stockColor = 'text-rose-600 font-semibold';
    } else {
        stockColor = 'text-on-surface';
    }
    const stockHTML = `<span class="font-mono text-sm ${stockColor}">${l.stock_count}</span>`;

    const isPaused = l.status === 'paused';
    const pauseIcon = isPaused ? 'play_arrow' : 'pause';
    const pauseTitle = isPaused ? 'Resume' : 'Pause';

    // Discount active state and rendering
    const discountActive = l.discount_active === true || l.discount_active === 1;
    const isEditing = editingDiscounts[l.listing_id];
    
    let discountCellHTML = '';
    const toggleBgClass = discountActive ? 'bg-forest' : 'bg-gray-300';
    const toggleTranslateClass = discountActive ? 'translate-x-3.5' : 'translate-x-0.5';
    
    if (discountActive && !isEditing) {
        discountCellHTML = `
            <div class="flex items-center gap-2" onclick="event.stopPropagation();">
                <div class="cursor-pointer" onclick="startEditDiscount('${l.listing_id}')">
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold bg-violet/10 text-violet">
                        ${l.discount_percentage}% off
                    </span>
                    <span class="block text-[10px] text-on-surface-variant font-mono mt-0.5">${formatPaise(l.discounted_price)}</span>
                </div>
                <button type="button" class="relative inline-flex h-5 w-8 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none bg-forest" onclick="toggleDiscount('${l.listing_id}', false)">
                    <span class="pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out translate-x-3.5"></span>
                </button>
            </div>
        `;
    } else {
        discountCellHTML = `
            <div class="flex items-center gap-2" onclick="event.stopPropagation();">
                <input type="number" min="1" max="90" placeholder="—%" id="discount-input-${l.listing_id}" 
                    value="${l.discount_percentage || ''}" 
                    class="w-12 px-1 py-0.5 border border-sage/30 rounded text-center text-xs focus:ring-1 focus:ring-forest focus:border-forest"
                    onkeydown="if(event.key==='Enter') saveDiscount('${l.listing_id}')"/>
                <button type="button" class="relative inline-flex h-5 w-8 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${toggleBgClass}" onclick="toggleDiscount('${l.listing_id}', ${!discountActive})">
                    <span class="pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${toggleTranslateClass}"></span>
                </button>
            </div>
        `;
    }

    // Price rendering with strikethrough if discount is active
    let priceHTML = '';
    if (discountActive && l.discounted_price !== null) {
        priceHTML = `
            <div>
                <span class="line-through text-on-surface-variant/60 block">${formatPaise(l.price_paise)}</span>
                <span class="text-forest font-bold block">${formatPaise(l.discounted_price)}</span>
            </div>
        `;
    } else {
        priceHTML = `<span class="text-on-surface block">${formatPaise(l.price_paise)}</span>`;
    }

    const isChecked = selectedListings[l.listing_id] ? 'checked' : '';

    return `
    <tr class="group hover:bg-forest/5 transition-colors">
        <td class="py-4 px-3 w-12 text-center" onclick="event.stopPropagation();">
            <input type="checkbox" data-id="${l.listing_id}" ${isChecked} class="listing-checkbox rounded border-sage/30 text-forest focus:ring-forest bg-background w-4 h-4 cursor-pointer" onchange="toggleRowSelection('${l.listing_id}')"/>
        </td>
        <td class="py-4 px-4">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 rounded-lg overflow-hidden border border-sage/20 shrink-0">
                    ${img}
                </div>
                <div class="min-w-0">
                    <p class="font-semibold text-primary truncate">${l.title}</p>
                    <div class="flex items-center gap-2 mt-0.5">
                        <span class="text-[10px] text-on-surface-variant uppercase tracking-widest">${l.category || 'Uncategorized'}</span>
                        ${l.listing_type === 'custom' || l.isCustomisable ? `<span style="font-family:'Cinzel', serif; font-size:9px; background-color:#D8CBE9; color:#7B5EA7; border-radius:20px; padding:3px 8px;" class="uppercase font-bold">Customisable</span>` : ''}
                    </div>
                </div>
            </div>
        </td>
        <td class="py-4 px-3 font-data-price">${priceHTML}</td>
        <td class="py-4 px-3">${discountCellHTML}</td>
        <td class="py-4 px-3">${stockHTML}</td>
        <td class="py-4 px-3">${statusBadge(l.status, l.stock_count)}</td>
        <td class="py-4 px-4 text-right">
            <div class="flex items-center justify-end gap-3 opacity-60 hover:opacity-100 transition-opacity">
                <button class="edit-btn text-sage hover:text-forest transition-colors" title="Edit" data-id="${l.listing_id}">
                    <span class="material-symbols-outlined text-lg">edit</span>
                </button>
                <button class="pause-btn text-sage hover:text-forest transition-colors" title="${pauseTitle}" data-id="${l.listing_id}" data-status="${l.status}">
                    <span class="material-symbols-outlined text-lg">${pauseIcon}</span>
                </button>
                <button class="delete-btn text-rose-400 hover:text-rose-600 transition-colors" title="Delete" data-id="${l.listing_id}" data-title="${l.title}">
                    <span class="material-symbols-outlined text-lg">delete</span>
                </button>
            </div>
        </td>
    </tr>
    `;
}

// ── Load listings ─────────────────────────────────────────────
const MOCK_LISTINGS = [
    {
        listing_id: "mock-1",
        title: "Golden Fern Study No. 4",
        category: "Art Print",
        price_paise: 850000,
        stock_count: 1,
        status: "active",
        cover_photo_url: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=500&auto=format&fit=crop&q=60"
    },
    {
        listing_id: "mock-2",
        title: "Archival Wildflower Seeds",
        category: "Curated Seeds",
        price_paise: 220000,
        stock_count: 4,
        status: "active",
        cover_photo_url: "https://images.unsplash.com/photo-1544816155-12df9643f363?w=500&auto=format&fit=crop&q=60"
    },
    {
        listing_id: "mock-3",
        title: "Forest Floor Ceramic Bowl",
        category: "Handmade Ceramic",
        price_paise: 1400000,
        stock_count: 12,
        status: "paused",
        cover_photo_url: "https://images.unsplash.com/photo-1612196808214-b8e1d6145a8c?w=500&auto=format&fit=crop&q=60"
    },
    {
        listing_id: "mock-4",
        title: "Linen Studio Apron",
        category: "Textiles",
        price_paise: 350000,
        stock_count: 0,
        status: "active",
        cover_photo_url: "https://images.unsplash.com/photo-1544816155-12df9643f363?w=500&auto=format&fit=crop&q=60"
    },
    {
        listing_id: "mock-5",
        title: "Hand-Woven Willow Tray",
        category: "Home Decor",
        price_paise: 195000,
        stock_count: 8,
        status: "active",
        cover_photo_url: "https://images.unsplash.com/photo-1590736969955-71cb94801758?w=500&auto=format&fit=crop&q=60"
    },
    {
        listing_id: "mock-6",
        title: "Pressed Lavender Soy Candle",
        category: "Aromatherapy",
        price_paise: 75000,
        stock_count: 20,
        status: "active",
        cover_photo_url: "https://images.unsplash.com/photo-1603006905003-be475563bc59?w=500&auto=format&fit=crop&q=60"
    },
    {
        listing_id: "mock-7",
        title: "Eucalyptus Leaf Ceramic Mug",
        category: "Handmade Ceramic",
        price_paise: 95000,
        stock_count: 3,
        status: "draft",
        cover_photo_url: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=500&auto=format&fit=crop&q=60"
    }
];

async function loadListings(forceFetch = false) {
    const tableContainer = document.getElementById('listings-table-container');
    const empty = document.getElementById('empty-state');
    const error = document.getElementById('error-state');
    const load  = document.getElementById('loading-state');
    const pgn   = document.getElementById('pagination');

    if (forceFetch || allListings.length === 0) {
        load.classList.remove('hidden');
        tableContainer.classList.add('hidden');
        empty.classList.add('hidden');
        error.classList.add('hidden');
        pgn.classList.add('hidden');

        const token = sessionStorage.getItem('tohfa_access_token') || sessionStorage.getItem('access_token');

        try {
            if (!token) {
                throw new Error("No token found, using mock data");
            }
            const res  = await fetch(`${API_BASE}/api/seller/listings`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (res.status === 401 || res.status === 403) {
                sessionStorage.clear(); window.location.href = '/auth/login.html'; return;
            }
            if (!res.ok) throw new Error(`HTTP ${res.status}`);

            const resp = await res.json();
            let rawListings = [];
            if (resp && resp.data && Array.isArray(resp.data.listings)) {
                rawListings = resp.data.listings;
            } else if (resp && Array.isArray(resp.data)) {
                rawListings = resp.data;
            } else if (Array.isArray(resp)) {
                rawListings = resp;
            } else if (resp && resp.listings && Array.isArray(resp.listings)) {
                rawListings = resp.listings;
            }

            allListings = rawListings.map(l => {
                return {
                    listing_id: l.id || l.listing_id,
                    title: l.title,
                    category: l.category,
                    price_paise: l.price_paise || (l.price ? Math.round(l.price * 100) : 0) || l.base_price || 0,
                    stock_count: l.stock_count !== undefined ? l.stock_count : (l.stock !== undefined ? l.stock : 0),
                    status: l.status,
                    cover_photo_url: l.cover_photo_url || l.cover_image_url || null,
                    ...l
                };
            });
        } catch (err) {
            console.warn('Failed to load live listings, falling back to mock data:', err);
            allListings = MOCK_LISTINGS;
        }

        // Dynamically update unique categories
        const categorySelect = document.getElementById('category-select');
        const currentCategory = categorySelect?.value || 'all';
        const categories = new Set();
        allListings.forEach(l => {
            if (l.category) categories.add(l.category);
        });

        let categoryOptions = '<option value="all">All Categories</option>';
        categories.forEach(cat => {
            categoryOptions += `<option value="${cat}">${cat}</option>`;
        });
        if (categorySelect) {
            categorySelect.innerHTML = categoryOptions;
            categorySelect.value = currentCategory;
        }
    }

    applyFiltersAndRender();
}

function applyFiltersAndRender() {
    const tableContainer = document.getElementById('listings-table-container');
    const empty = document.getElementById('empty-state');
    const load  = document.getElementById('loading-state');
    const pgn   = document.getElementById('pagination');

    load.classList.add('hidden');

    filteredListings = allListings.filter(l => {
        const matchesStatus = document.getElementById('status-select').value === 'all' || l.status === document.getElementById('status-select').value;
        const matchesCategory = document.getElementById('category-select').value === 'all' || l.category === document.getElementById('category-select').value;
        const matchesSearch = !searchQuery || l.title.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesStatus && matchesCategory && matchesSearch;
    });

    const sortVal = document.getElementById('sort-select')?.value || 'newest';
    if (sortVal === 'newest') {
        filteredListings.sort((a, b) => b.listing_id - a.listing_id || b.id - a.id);
    } else if (sortVal === 'price-high') {
        filteredListings.sort((a, b) => b.price_paise - a.price_paise);
    } else if (sortVal === 'popular') {
        filteredListings.sort((a, b) => (b.sale_count || 0) - (a.sale_count || 0));
    } else if (sortVal === 'low-stock') {
        filteredListings.sort((a, b) => a.stock_count - b.stock_count);
    }

    // Stats
    loadStats();
    updateBulkBarUI();

    // Listings count label
    const countLabel = document.getElementById('listings-count-label');
    if (countLabel) {
        countLabel.textContent = `${filteredListings.length} listing${filteredListings.length !== 1 ? 's' : ''} found`;
    }

    if (filteredListings.length === 0) {
        tableContainer.classList.add('hidden');
        empty.classList.remove('hidden');
        pgn.classList.add('hidden');
    } else {
        empty.classList.add('hidden');
        
        // Paginate client-side
        const totalPages = Math.ceil(filteredListings.length / PAGE_LIMIT);
        if (currentPage > totalPages) currentPage = Math.max(totalPages, 1);

        const startIndex = (currentPage - 1) * PAGE_LIMIT;
        const endIndex = startIndex + PAGE_LIMIT;
        const pageListings = filteredListings.slice(startIndex, endIndex);

        let rowsHtml = pageListings.map(rowHTML).join('');
        document.getElementById('listings-table-body').innerHTML = rowsHtml;
        tableContainer.classList.remove('hidden');
        attachCardListeners();

        // Render Pagination UI
        if (totalPages > 1) {
            document.getElementById('page-label').textContent = `Page ${currentPage} of ${totalPages}`;
            document.getElementById('prev-btn').disabled = currentPage <= 1;
            document.getElementById('next-btn').disabled = currentPage >= totalPages;
            pgn.classList.remove('hidden');
        } else {
            pgn.classList.add('hidden');
        }
    }
}

// ── Card action listeners ─────────────────────────────────────
function attachCardListeners() {
    document.querySelectorAll('#listings-table-body tr').forEach(row => {
        row.addEventListener('click', (e) => {
            if (e.target.closest('input') || e.target.closest('button') || e.target.closest('span.material-symbols-outlined') || e.target.closest('.cursor-pointer')) {
                return;
            }
            const editBtn = row.querySelector('.edit-btn');
            if (editBtn) {
                const id = editBtn.dataset.id;
                const listing = allListings.find(l => String(l.listing_id) === String(id));
                if (listing && listing.status === 'draft') {
                    sessionStorage.setItem('draft_id', id);
                    window.location.href = '/seller/listing-photos.html';
                } else {
                    window.location.href = `/seller/edit-listing.html?id=${id}`;
                }
            }
        });
    });

    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const id = btn.dataset.id;
            const listing = allListings.find(l => String(l.listing_id) === String(id));
            if (listing && listing.status === 'draft') {
                sessionStorage.setItem('draft_id', id);
                window.location.href = '/seller/listing-photos.html';
            } else {
                window.location.href = `/seller/edit-listing.html?id=${id}`;
            }
        });
    });

    document.querySelectorAll('.pause-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const id = btn.dataset.id;
            const status = btn.dataset.status;
            const token = sessionStorage.getItem('tohfa_access_token') || sessionStorage.getItem('access_token');
            const isPaused = status === 'paused';
            
            try {
                let res;
                if (isPaused) {
                    // Resume it
                    res = await fetch(`${API_BASE}/api/seller/listings/${id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                        body: JSON.stringify({ status: 'active' })
                    });
                } else {
                    // Pause it
                    res = await fetch(`${API_BASE}/api/seller/listings/${id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                        body: JSON.stringify({ status: 'paused' })
                    });
                }
                const data = await res.json();
                if (!res.ok) throw new Error(data.message || data.detail || 'Failed to toggle status');
                showToast(isPaused ? 'Listing resumed!' : 'Listing paused!', 'success');
                await loadListings(true);
            } catch (err) {
                showToast(err.message, 'error');
            }
        });
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const id    = btn.dataset.id;
            const title = btn.dataset.title;
            if (!confirm(`Delete "${title}"? This cannot be undone.`)) return;
            await deleteListing(id, title);
        });
    });
}

// ── Delete listing ────────────────────────────────────────────
async function deleteListing(id, title) {
    const token = sessionStorage.getItem('tohfa_access_token') || sessionStorage.getItem('access_token');
    try {
        const res = await fetch(`${API_BASE}/api/seller/listings/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        showToast(`"${title}" deleted.`, 'success');
        await loadListings(true);
    } catch (err) {
        showToast('Delete failed: ' + err.message, 'error');
    }
}

// ── Modal helpers ─────────────────────────────────────────────
function openCreateModal() {
    sessionStorage.removeItem('draft_id');
    window.location.href = '/seller/listing-photos.html';
}

// ── Filter change listeners ───────────────────────────────────
document.getElementById('status-select')?.addEventListener('change', () => {
    currentPage = 1;
    dismissBulkBar();
    applyFiltersAndRender();
});

document.getElementById('category-select')?.addEventListener('change', () => {
    currentPage = 1;
    dismissBulkBar();
    applyFiltersAndRender();
});

// ── Search ────────────────────────────────────────────────────
document.getElementById('search-input').addEventListener('input', (e) => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
        searchQuery  = e.target.value.trim();
        currentPage  = 1;
        dismissBulkBar();
        applyFiltersAndRender();
    }, 400);
});

// ── Sort ──────────────────────────────────────────────────────
document.getElementById('sort-select')?.addEventListener('change', () => {
    currentPage = 1;
    dismissBulkBar();
    applyFiltersAndRender();
});

// ── Pagination ────────────────────────────────────────────────
document.getElementById('prev-btn').addEventListener('click', () => {
    if (currentPage > 1) { currentPage--; applyFiltersAndRender(); }
});
document.getElementById('next-btn').addEventListener('click', () => {
    const totalPages = Math.ceil(filteredListings.length / PAGE_LIMIT);
    if (currentPage < totalPages) { currentPage++; applyFiltersAndRender(); }
});

// ── DOMContentLoaded ──────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
    const token = sessionStorage.getItem('tohfa_access_token') || sessionStorage.getItem('access_token');

    // Role guard (only check if token is present)
    if (token) {
        try {
            const pr = await fetch(`${API_BASE}/api/profile/me`, { headers: { 'Authorization': `Bearer ${token}` } });
            if (pr.status === 401 || pr.status === 403) {
                sessionStorage.clear(); window.location.href = '/auth/login.html'; return;
            }
            if (!pr.ok) throw new Error();
            const pd = await pr.json();
            const u  = pd.data || pd;
            if (u.role !== 'seller') { window.location.href = '/buyer/profile.html'; return; }
        } catch (e) {
            console.warn("Profile check failed, continuing in preview mode:", e);
        }
    } else {
        console.warn("No token found, running in preview mode");
    }

    await loadListings(true);

    // Bind actions
    document.getElementById('header-create-listing-btn')?.addEventListener('click', openCreateModal);
    document.getElementById('empty-create-btn').addEventListener('click', openCreateModal);

    // Apply to all link action
    document.getElementById('apply-to-all-link')?.addEventListener('click', (e) => {
        e.stopPropagation();
        bulkDiscountTrigger = 'apply-to-all';
        selectedListings = {};
        document.querySelectorAll('.listing-checkbox').forEach(cb => cb.checked = false);
        if (document.getElementById('select-all-listings')) {
            document.getElementById('select-all-listings').checked = false;
        }
        updateBulkBarUI();
    });

    // Download Report Action
    document.getElementById('download-report-btn')?.addEventListener('click', () => {
        alert('Analytics report download initiated! The detailed report formatting will be configured in the next step.');
    });

    // ── Logout ────────────────────────────────────────────────────
    document.getElementById('logout-btn')?.addEventListener('click', () => {
        const refresh = sessionStorage.getItem('tohfa_refresh_token');
        if (token && refresh) {
            fetch('/api/auth/logout', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                body: JSON.stringify({ refresh_token: refresh })
            }).catch(() => {});
        }
        sessionStorage.clear();
        window.location.href = '/auth/login.html';
    });
});

document.getElementById('retry-btn')?.addEventListener('click', () => loadListings(true));
</script>

<!-- Mobile Nav Injection -->
<script type="module">
  import { initMobileSellerNav } from '/components/MobileSellerNav.js';
  initMobileSellerNav('catalog');
</script>

</body>
</html>