import { useState, useEffect, useCallback } from "react";
import { MobileHeader } from "./components/MobileHeader";
import { FilterBar } from "./components/FilterBar";
import { ListingCard, type Listing } from "./components/ListingCard";
import { BottomNav, FAB } from "./components/BottomNav";
import { BulkDiscountBar } from "./components/BulkDiscountBar";
import { ChevronLeft, ChevronRight, AlertCircle, Store, RefreshCw } from "lucide-react";

/* MARKER-MAKE-KIT-INVOKED */

const MOCK_LISTINGS: Listing[] = [
  {
    listing_id: "mock-1",
    title: "Golden Fern Study No. 4",
    category: "Art Print",
    price_paise: 850000,
    stock_count: 1,
    status: "active",
    cover_photo_url: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=400&auto=format&fit=crop&q=60",
  },
  {
    listing_id: "mock-2",
    title: "Archival Wildflower Seeds",
    category: "Curated Seeds",
    price_paise: 220000,
    stock_count: 4,
    status: "active",
    cover_photo_url: "https://images.unsplash.com/photo-1544816155-12df9643f363?w=400&auto=format&fit=crop&q=60",
  },
  {
    listing_id: "mock-3",
    title: "Forest Floor Ceramic Bowl",
    category: "Handmade Ceramic",
    price_paise: 1400000,
    stock_count: 12,
    status: "paused",
    cover_photo_url: "https://images.unsplash.com/photo-1612196808214-b8e1d6145a8c?w=400&auto=format&fit=crop&q=60",
  },
  {
    listing_id: "mock-4",
    title: "Linen Studio Apron",
    category: "Textiles",
    price_paise: 350000,
    stock_count: 0,
    status: "active",
    cover_photo_url: "https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?w=400&auto=format&fit=crop&q=60",
  },
  {
    listing_id: "mock-5",
    title: "Hand-Woven Willow Tray",
    category: "Home Decor",
    price_paise: 195000,
    stock_count: 8,
    status: "active",
    cover_photo_url: "https://images.unsplash.com/photo-1590736969955-71cb94801758?w=400&auto=format&fit=crop&q=60",
  },
  {
    listing_id: "mock-6",
    title: "Pressed Lavender Soy Candle",
    category: "Aromatherapy",
    price_paise: 75000,
    stock_count: 20,
    status: "active",
    cover_photo_url: "https://images.unsplash.com/photo-1603006905003-be475563bc59?w=400&auto=format&fit=crop&q=60",
  },
  {
    listing_id: "mock-7",
    title: "Eucalyptus Leaf Ceramic Mug",
    category: "Handmade Ceramic",
    price_paise: 95000,
    stock_count: 3,
    status: "draft",
    cover_photo_url: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&auto=format&fit=crop&q=60",
  },
];

const PAGE_LIMIT = 6;

interface Toast {
  msg: string;
  type: "success" | "error";
}

export default function App() {
  const [listings, setListings] = useState<Listing[]>(MOCK_LISTINGS);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [currentPage, setCurrentPage] = useState(1);

  const [selectedIds, setSelectedIds] = useState<Record<string, boolean>>({});
  const [bulkMode, setBulkMode] = useState<"selection" | "all" | null>(null);

  const [toast, setToast] = useState<Toast | null>(null);

  function showToast(msg: string, type: "success" | "error" = "success") {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  }

  // Derived data
  const categories = [...new Set(listings.map(l => l.category).filter(Boolean))];

  const filtered = listings.filter(l => {
    if (statusFilter !== "all" && l.status !== statusFilter) return false;
    if (categoryFilter !== "all" && l.category !== categoryFilter) return false;
    if (searchQuery && !l.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  }).sort((a, b) => {
    if (sortBy === "price_high") return b.price_paise - a.price_paise;
    if (sortBy === "capacity_low") return a.stock_count - b.stock_count;
    return 0;
  });

  const totalPages = Math.ceil(filtered.length / PAGE_LIMIT);
  const paginated = filtered.slice((currentPage - 1) * PAGE_LIMIT, currentPage * PAGE_LIMIT);

  const stats = {
    total: listings.length,
    lowStock: listings.filter(l => l.stock_count > 0 && l.stock_count <= 5).length,
    onDiscount: listings.filter(l => l.discount_active).length,
  };

  const selectedCount = Object.keys(selectedIds).length;
  const showBulkBar = selectedCount > 0 || bulkMode === "all";

  function toggleSelect(id: string) {
    setSelectedIds(prev => {
      const next = { ...prev };
      if (next[id]) delete next[id];
      else next[id] = true;
      return next;
    });
    setBulkMode("selection");
  }

  function dismissBulk() {
    setSelectedIds({});
    setBulkMode(null);
  }

  function handleToggleDiscount(id: string, active: boolean, pct?: number) {
    setListings(prev => prev.map(l => {
      if (l.listing_id !== id) return l;
      if (!active) return { ...l, discount_active: false, discount_percentage: undefined, discounted_price: undefined };
      const discounted = pct ? Math.round(l.price_paise * (1 - pct / 100)) : l.discounted_price;
      return { ...l, discount_active: true, discount_percentage: pct, discounted_price: discounted };
    }));
    showToast(active ? "Discount applied!" : "Discount removed!");
  }

  function handlePause(id: string, status: string) {
    const next = status === "paused" ? "active" : "paused";
    setListings(prev => prev.map(l => l.listing_id === id ? { ...l, status: next as Listing["status"] } : l));
    showToast(status === "paused" ? "Listing resumed!" : "Listing paused!");
  }

  function handleDelete(id: string, title: string) {
    if (!window.confirm(`Delete "${title}"? This cannot be undone.`)) return;
    setListings(prev => prev.filter(l => l.listing_id !== id));
    showToast(`"${title}" deleted.`);
  }

  function handleEdit(id: string, status: string) {
    showToast(`Opening editor for listing…`);
  }

  function handleBulkApply(pct: number) {
    if (bulkMode === "all") {
      setListings(prev => prev.map(l => ({
        ...l,
        discount_active: true,
        discount_percentage: pct,
        discounted_price: Math.round(l.price_paise * (1 - pct / 100)),
      })));
    } else {
      setListings(prev => prev.map(l => {
        if (!selectedIds[l.listing_id]) return l;
        return { ...l, discount_active: true, discount_percentage: pct, discounted_price: Math.round(l.price_paise * (1 - pct / 100)) };
      }));
    }
    showToast("Bulk discount applied!");
    dismissBulk();
  }

  function handleBulkClear() {
    if (bulkMode === "all") {
      setListings(prev => prev.map(l => ({ ...l, discount_active: false, discount_percentage: undefined, discounted_price: undefined })));
    } else {
      setListings(prev => prev.map(l => {
        if (!selectedIds[l.listing_id]) return l;
        return { ...l, discount_active: false, discount_percentage: undefined, discounted_price: undefined };
      }));
    }
    showToast("Discounts cleared!");
    dismissBulk();
  }

  function handleFilterChange(setter: (v: string) => void) {
    return (v: string) => { setter(v); setCurrentPage(1); dismissBulk(); };
  }

  return (
    <div
      className="min-h-screen bg-[#FFFFFF] max-w-md mx-auto relative"
      style={{ fontFamily: "'DM Sans', sans-serif" }}
    >
      {/* MARKER-MAKE-KIT-INVOKED */}

      {/* Toast */}
      {toast && (
        <div
          className={`fixed top-4 left-1/2 -translate-x-1/2 z-[999] px-5 py-3 rounded-2xl shadow-xl text-sm font-semibold flex items-center gap-2 transition-all ${
            toast.type === "success"
              ? "bg-[#3D6B4F] text-white"
              : "bg-red-600 text-white"
          }`}
        >
          {toast.msg}
        </div>
      )}

      {/* Sticky header */}
      <MobileHeader
        totalListings={stats.total}
        lowStock={stats.lowStock}
        onDiscount={stats.onDiscount}
        searchQuery={searchQuery}
        onSearch={q => { setSearchQuery(q); setCurrentPage(1); }}
        onDownload={() => showToast("Report download initiated!")}
        onNewListing={() => showToast("Opening new listing form…")}
      />

      {/* Filters */}
      <FilterBar
        statusFilter={statusFilter}
        categoryFilter={categoryFilter}
        sortBy={sortBy}
        categories={categories}
        listingCount={filtered.length}
        onStatusChange={handleFilterChange(setStatusFilter)}
        onCategoryChange={handleFilterChange(setCategoryFilter)}
        onSortChange={handleFilterChange(setSortBy)}
      />

      {/* Bulk bar */}
      {showBulkBar && (
        <BulkDiscountBar
          selectedCount={selectedCount}
          mode={bulkMode ?? "selection"}
          onApply={handleBulkApply}
          onClear={handleBulkClear}
          onDismiss={dismissBulk}
        />
      )}

      {/* Content */}
      <div className="px-4 pb-32 space-y-3">
        {loading && (
          <div className="space-y-3 pt-2">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-40 rounded-2xl bg-[#F7F3EC] animate-pulse" />
            ))}
          </div>
        )}

        {error && !loading && (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <AlertCircle size={48} className="text-[#3D6B4F]" />
            <p className="text-[#414942] text-sm text-center">Failed to load listings.</p>
            <button
              onClick={() => setError(false)}
              className="flex items-center gap-2 px-6 py-2.5 bg-[#3D6B4F] text-white rounded-full text-sm font-semibold"
            >
              <RefreshCw size={14} /> Try Again
            </button>
          </div>
        )}

        {!loading && !error && filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <Store size={48} className="text-[#8FAF82]" />
            <p className="text-[#414942] text-sm text-center">
              No listings found.<br />Create your first listing to get started.
            </p>
            <button
              onClick={() => showToast("Opening new listing form…")}
              className="px-6 py-2.5 bg-[#3D6B4F] text-white rounded-full text-sm font-semibold shadow-md"
            >
              Create Listing
            </button>
          </div>
        )}

        {!loading && !error && paginated.map(listing => (
          <ListingCard
            key={listing.listing_id}
            listing={listing}
            selected={!!selectedIds[listing.listing_id]}
            onSelect={toggleSelect}
            onEdit={handleEdit}
            onPause={handlePause}
            onDelete={handleDelete}
            onToggleDiscount={handleToggleDiscount}
          />
        ))}

        {/* Pagination */}
        {!loading && totalPages > 1 && (
          <div className="flex items-center justify-center gap-4 pt-2">
            <button
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage(p => p - 1)}
              className="w-10 h-10 rounded-full border border-[#F7F3EC] flex items-center justify-center disabled:opacity-40"
            >
              <ChevronLeft size={18} className="text-[#414942]" />
            </button>
            <span className="text-xs font-semibold text-[#717972]">
              {currentPage} / {totalPages}
            </span>
            <button
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage(p => p + 1)}
              className="w-10 h-10 rounded-full border border-[#F7F3EC] flex items-center justify-center disabled:opacity-40"
            >
              <ChevronRight size={18} className="text-[#414942]" />
            </button>
          </div>
        )}
      </div>

      {/* Bottom Nav */}
      <BottomNav activeTab="catalog" />

      {/* FAB */}
      <FAB onClick={() => showToast("AI assistant coming soon!")} />
    </div>
  );
}
