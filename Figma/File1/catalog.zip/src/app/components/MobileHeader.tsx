import { Search, Download, Plus, X } from "lucide-react";

interface MobileHeaderProps {
  totalListings: number;
  lowStock: number;
  onDiscount: number;
  searchQuery: string;
  onSearch: (q: string) => void;
  onDownload: () => void;
  onNewListing: () => void;
}

export function MobileHeader({
  totalListings,
  lowStock,
  onDiscount,
  searchQuery,
  onSearch,
  onDownload,
  onNewListing,
}: MobileHeaderProps) {
  return (
    <div className="sticky top-0 z-40 bg-[#FFFFFF]" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      {/* Brand bar */}
      <div className="flex items-center justify-between px-4 pt-5 pb-3 border-b border-[#F7F3EC]">
        <div>
          <p className="text-[10px] font-bold text-[#8FAF82] uppercase tracking-widest">Seller Dashboard</p>
          <h1 className="text-lg leading-tight text-[#3D6B4F]" style={{ fontFamily: "'Playfair Display', serif" }}>
            My Catalog
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onDownload}
            className="w-9 h-9 rounded-full border border-[#F7F3EC] bg-white flex items-center justify-center text-[#414942] active:bg-[#F7F3EC]"
          >
            <Download size={16} />
          </button>
          <button
            onClick={onNewListing}
            className="flex items-center gap-1.5 px-4 py-2 bg-[#3D6B4F] text-white rounded-full text-xs font-bold active:opacity-80"
          >
            <Plus size={14} />
            New
          </button>
        </div>
      </div>

      {/* Stats row */}
      <div className="flex gap-2 px-4 py-3 overflow-x-auto no-scrollbar">
        <StatChip label="Total" value={totalListings} color="text-[#3D6B4F]" bg="bg-[#3D6B4F]/8" />
        <StatChip label="Low Stock" value={lowStock} color="text-amber-600" bg="bg-amber-50" />
        <StatChip label="On Discount" value={onDiscount} color="text-[#7B5EA7]" bg="bg-[#7B5EA7]/10" />
      </div>

      {/* Search */}
      <div className="px-4 pb-3">
        <div className="flex items-center gap-2 bg-[#F7F3EC] rounded-full px-4 py-2.5">
          <Search size={16} className="text-[#717972] flex-shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => onSearch(e.target.value)}
            placeholder="Search listings..."
            className="flex-1 bg-transparent border-none outline-none text-sm text-[#211b11] placeholder-[#717972]"
          />
          {searchQuery && (
            <button onClick={() => onSearch("")}>
              <X size={14} className="text-[#717972]" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function StatChip({ label, value, color, bg }: { label: string; value: number; color: string; bg: string }) {
  return (
    <div className={`flex-shrink-0 flex flex-col items-center px-4 py-2 rounded-xl ${bg}`}>
      <span className={`text-xl font-bold leading-tight ${color}`} style={{ fontFamily: "'Space Mono', monospace" }}>
        {value}
      </span>
      <span className="text-[10px] font-bold text-[#717972] uppercase tracking-widest whitespace-nowrap">{label}</span>
    </div>
  );
}
