import { LayoutGrid, ShoppingBag, BarChart2, User, Sparkles } from "lucide-react";

interface BottomNavProps {
  activeTab: string;
}

const NAV_ITEMS = [
  { id: "catalog", label: "Catalog", Icon: LayoutGrid },
  { id: "orders", label: "Orders", Icon: ShoppingBag },
  { id: "analytics", label: "Analytics", Icon: BarChart2 },
  { id: "profile", label: "Profile", Icon: User },
];

export function BottomNav({ activeTab }: BottomNavProps) {
  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#F7F3EC] flex items-center"
      style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)", fontFamily: "'DM Sans', sans-serif" }}
    >
      {NAV_ITEMS.map(({ id, label, Icon }) => {
        const active = activeTab === id;
        return (
          <button
            key={id}
            className={`flex-1 flex flex-col items-center justify-center py-2.5 gap-0.5 transition-colors ${
              active ? "text-[#3D6B4F]" : "text-[#717972]"
            }`}
          >
            <Icon size={22} strokeWidth={active ? 2.5 : 1.8} />
            <span className={`text-[10px] font-bold uppercase tracking-wide ${active ? "text-[#3D6B4F]" : "text-[#717972]"}`}>
              {label}
            </span>
            {active && <span className="absolute bottom-0 w-6 h-0.5 bg-[#3D6B4F] rounded-full" />}
          </button>
        );
      })}
    </div>
  );
}

export function FAB({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="fixed bottom-20 right-4 z-50 w-14 h-14 bg-[#7B5EA7] text-white rounded-full shadow-lg flex items-center justify-center active:scale-95 transition-transform"
    >
      <Sparkles size={22} />
    </button>
  );
}
