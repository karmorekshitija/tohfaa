import { useState } from "react";
import { Edit2, Pause, Play, Trash2, ChevronDown, Check } from "lucide-react";

export interface Listing {
  listing_id: string;
  title: string;
  category: string;
  price_paise: number;
  stock_count: number;
  status: "active" | "paused" | "draft";
  cover_photo_url?: string;
  discount_active?: boolean;
  discount_percentage?: number;
  discounted_price?: number;
  listing_type?: string;
  isCustomisable?: boolean;
}

interface ListingCardProps {
  listing: Listing;
  selected: boolean;
  onSelect: (id: string) => void;
  onEdit: (id: string, status: string) => void;
  onPause: (id: string, status: string) => void;
  onDelete: (id: string, title: string) => void;
  onToggleDiscount: (id: string, active: boolean, pct?: number) => void;
}

function formatPaise(p: number | null | undefined) {
  if (p == null) return "₹0";
  return "₹" + (p / 100).toLocaleString("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function statusColors(status: string, stock: number) {
  if (stock === 0 && status === "active") return { bg: "bg-red-100", text: "text-red-700", label: "Out of Stock" };
  const map: Record<string, { bg: string; text: string; label: string }> = {
    active: { bg: "bg-[#b7e9c6]/40", text: "text-[#3D6B4F]", label: "Active" },
    paused: { bg: "bg-[#8FAF82]/20", text: "text-[#49663f]", label: "Paused" },
    draft: { bg: "bg-[#F7F3EC]", text: "text-[#414942]", label: "Draft" },
  };
  return map[status] || { bg: "bg-gray-100", text: "text-gray-600", label: status };
}

export function ListingCard({ listing, selected, onSelect, onEdit, onPause, onDelete, onToggleDiscount }: ListingCardProps) {
  const [showDiscount, setShowDiscount] = useState(false);
  const [discountInput, setDiscountInput] = useState(listing.discount_percentage?.toString() || "");

  const { bg, text, label } = statusColors(listing.status, listing.stock_count);
  const discountActive = listing.discount_active === true;
  const isLowStock = listing.stock_count <= 5 && listing.stock_count > 0;
  const isOutOfStock = listing.stock_count === 0;

  function handleDiscountSave() {
    const val = parseInt(discountInput);
    if (!isNaN(val) && val >= 1 && val <= 90) {
      onToggleDiscount(listing.listing_id, true, val);
      setShowDiscount(false);
    }
  }

  return (
    <div
      className={`bg-white rounded-2xl border transition-all ${selected ? "border-[#3D6B4F] shadow-md" : "border-[#F7F3EC] shadow-sm"}`}
      style={{ fontFamily: "'DM Sans', sans-serif" }}
    >
      {/* Top Row: image + info */}
      <div className="flex gap-3 p-4">
        {/* Checkbox */}
        <button
          onClick={() => onSelect(listing.listing_id)}
          className={`mt-0.5 flex-shrink-0 w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${selected ? "bg-[#3D6B4F] border-[#3D6B4F]" : "border-[#8FAF82] bg-white"}`}
        >
          {selected && <Check size={12} color="white" strokeWidth={3} />}
        </button>

        {/* Image */}
        <div className="w-16 h-16 rounded-xl overflow-hidden border border-[#F7F3EC] flex-shrink-0 bg-[#F7F3EC]">
          {listing.cover_photo_url ? (
            <img src={listing.cover_photo_url} alt={listing.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-[#8FAF82]">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <p
              className="font-semibold text-[#3D6B4F] text-sm leading-tight truncate"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              {listing.title}
            </p>
            <span className={`flex-shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide ${bg} ${text}`}>
              {label}
            </span>
          </div>

          <p className="text-[11px] text-[#717972] uppercase tracking-widest mt-0.5 truncate">{listing.category || "Uncategorized"}</p>

          {/* Price */}
          <div className="flex items-baseline gap-2 mt-1.5">
            {discountActive && listing.discounted_price != null ? (
              <>
                <span className="text-[#3D6B4F] font-bold text-sm" style={{ fontFamily: "'Space Mono', monospace" }}>
                  {formatPaise(listing.discounted_price)}
                </span>
                <span className="line-through text-[#717972] text-xs" style={{ fontFamily: "'Space Mono', monospace" }}>
                  {formatPaise(listing.price_paise)}
                </span>
                <span className="text-[10px] font-bold text-[#7B5EA7] bg-[#7B5EA7]/10 px-1.5 py-0.5 rounded-full">
                  {listing.discount_percentage}% off
                </span>
              </>
            ) : (
              <span className="text-[#211b11] font-semibold text-sm" style={{ fontFamily: "'Space Mono', monospace" }}>
                {formatPaise(listing.price_paise)}
              </span>
            )}
          </div>

          {/* Stock */}
          <div className="flex items-center gap-1 mt-1">
            <span className={`text-xs font-semibold ${isOutOfStock ? "text-red-600" : isLowStock ? "text-amber-600" : "text-[#414942]"}`}>
              {isOutOfStock ? "Out of stock" : isLowStock ? `${listing.stock_count} left — low` : `${listing.stock_count} in stock`}
            </span>
            {(listing.listing_type === "custom" || listing.isCustomisable) && (
              <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-[#D8CBE9] text-[#7B5EA7] uppercase tracking-wide" style={{ fontFamily: "'Cinzel', serif" }}>
                Custom
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Discount row */}
      <div className="px-4 pb-3">
        <button
          onClick={() => setShowDiscount(v => !v)}
          className="w-full flex items-center justify-between text-xs text-[#414942] bg-[#F7F3EC] rounded-lg px-3 py-2"
        >
          <span>{discountActive ? `Discount: ${listing.discount_percentage}% off` : "Add discount"}</span>
          <ChevronDown size={14} className={`transition-transform ${showDiscount ? "rotate-180" : ""}`} />
        </button>

        {showDiscount && (
          <div className="mt-2 flex items-center gap-2">
            <input
              type="number"
              min={1}
              max={90}
              placeholder="e.g. 15"
              value={discountInput}
              onChange={e => setDiscountInput(e.target.value)}
              className="w-20 px-2 py-1.5 border border-[#8FAF82]/40 rounded-lg text-center text-xs focus:outline-none focus:ring-1 focus:ring-[#3D6B4F]"
            />
            <span className="text-xs text-[#414942]">%</span>
            <button
              onClick={handleDiscountSave}
              className="px-3 py-1.5 bg-[#3D6B4F] text-white text-xs font-bold rounded-full"
            >
              Apply
            </button>
            {discountActive && (
              <button
                onClick={() => { onToggleDiscount(listing.listing_id, false); setShowDiscount(false); }}
                className="px-3 py-1.5 border border-[#717972]/30 text-[#414942] text-xs font-bold rounded-full"
              >
                Remove
              </button>
            )}
          </div>
        )}
      </div>

      {/* Action bar */}
      <div className="flex border-t border-[#F7F3EC]">
        <button
          onClick={() => onEdit(listing.listing_id, listing.status)}
          className="flex-1 flex items-center justify-center gap-1.5 py-3 text-xs font-semibold text-[#414942] hover:bg-[#F7F3EC] transition-colors"
        >
          <Edit2 size={14} className="text-[#8FAF82]" />
          Edit
        </button>
        <div className="w-px bg-[#F7F3EC]" />
        <button
          onClick={() => onPause(listing.listing_id, listing.status)}
          className="flex-1 flex items-center justify-center gap-1.5 py-3 text-xs font-semibold text-[#414942] hover:bg-[#F7F3EC] transition-colors"
        >
          {listing.status === "paused" ? (
            <><Play size={14} className="text-[#3D6B4F]" /> Resume</>
          ) : (
            <><Pause size={14} className="text-[#8FAF82]" /> Pause</>
          )}
        </button>
        <div className="w-px bg-[#F7F3EC]" />
        <button
          onClick={() => onDelete(listing.listing_id, listing.title)}
          className="flex-1 flex items-center justify-center gap-1.5 py-3 text-xs font-semibold text-red-400 hover:bg-red-50 transition-colors"
        >
          <Trash2 size={14} />
          Delete
        </button>
      </div>
    </div>
  );
}
