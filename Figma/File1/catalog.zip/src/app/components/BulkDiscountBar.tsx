import { useState } from "react";
import { X, Tag } from "lucide-react";

interface BulkDiscountBarProps {
  selectedCount: number;
  mode: "selection" | "all";
  onApply: (pct: number) => void;
  onClear: () => void;
  onDismiss: () => void;
}

export function BulkDiscountBar({ selectedCount, mode, onApply, onClear, onDismiss }: BulkDiscountBarProps) {
  const [pct, setPct] = useState("");
  const label = mode === "all" ? "all active items" : `${selectedCount} item${selectedCount !== 1 ? "s" : ""}`;

  function handleApply() {
    const val = parseInt(pct);
    if (!isNaN(val) && val >= 1 && val <= 90) onApply(val);
  }

  return (
    <div
      className="mx-4 mb-3 p-4 bg-[#F7F3EC] border border-[#8FAF82]/40 rounded-2xl shadow-sm"
      style={{ fontFamily: "'DM Sans', sans-serif" }}
    >
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <Tag size={15} className="text-[#3D6B4F] flex-shrink-0" />
          <p className="text-xs font-semibold text-[#211b11]">
            Apply discount to <span className="text-[#3D6B4F]">{label}</span>
          </p>
        </div>
        <button onClick={onDismiss}>
          <X size={16} className="text-[#717972]" />
        </button>
      </div>

      <div className="flex items-center gap-2">
        <input
          type="number"
          min={1}
          max={90}
          placeholder="e.g. 15"
          value={pct}
          onChange={e => setPct(e.target.value)}
          className="w-20 px-3 py-2 border border-[#8FAF82]/40 rounded-xl text-center text-sm focus:outline-none focus:ring-1 focus:ring-[#3D6B4F] bg-white"
        />
        <span className="text-sm font-semibold text-[#414942]">%</span>
        <button
          onClick={handleApply}
          className="px-4 py-2 bg-[#3D6B4F] text-white rounded-full text-xs font-bold active:opacity-80"
        >
          Apply
        </button>
        <button
          onClick={onClear}
          className="px-4 py-2 border border-[#717972]/30 text-[#414942] rounded-full text-xs font-bold"
        >
          Clear all
        </button>
      </div>
    </div>
  );
}
