import { SlidersHorizontal } from "lucide-react";
import { useState } from "react";

interface FilterBarProps {
  statusFilter: string;
  categoryFilter: string;
  sortBy: string;
  categories: string[];
  listingCount: number;
  onStatusChange: (v: string) => void;
  onCategoryChange: (v: string) => void;
  onSortChange: (v: string) => void;
}

const STATUS_OPTIONS = [
  { value: "all", label: "All" },
  { value: "active", label: "Active" },
  { value: "paused", label: "Paused" },
  { value: "draft", label: "Drafts" },
];

const SORT_OPTIONS = [
  { value: "newest", label: "Newest" },
  { value: "best_selling", label: "Best Selling" },
  { value: "price_high", label: "Price ↓" },
  { value: "capacity_low", label: "Low Stock" },
];

export function FilterBar({
  statusFilter,
  categoryFilter,
  sortBy,
  categories,
  listingCount,
  onStatusChange,
  onCategoryChange,
  onSortChange,
}: FilterBarProps) {
  const [showSort, setShowSort] = useState(false);

  return (
    <div className="px-4 py-2 space-y-2" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      {/* Status chips */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {STATUS_OPTIONS.map(opt => (
          <button
            key={opt.value}
            onClick={() => onStatusChange(opt.value)}
            className={`flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
              statusFilter === opt.value
                ? "bg-[#3D6B4F] text-white"
                : "bg-[#F7F3EC] text-[#414942]"
            }`}
          >
            {opt.label}
          </button>
        ))}
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => onCategoryChange(categoryFilter === cat ? "all" : cat)}
            className={`flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
              categoryFilter === cat
                ? "bg-[#7B5EA7] text-white"
                : "bg-[#F7F3EC] text-[#414942]"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Count + Sort */}
      <div className="flex items-center justify-between">
        <span className="text-xs text-[#717972]">
          {listingCount} listing{listingCount !== 1 ? "s" : ""}
        </span>
        <div className="relative">
          <button
            onClick={() => setShowSort(v => !v)}
            className="flex items-center gap-1.5 text-xs font-semibold text-[#3D6B4F] bg-[#3D6B4F]/8 px-3 py-1.5 rounded-full"
          >
            <SlidersHorizontal size={13} />
            {SORT_OPTIONS.find(s => s.value === sortBy)?.label || "Sort"}
          </button>
          {showSort && (
            <div className="absolute right-0 top-8 z-50 bg-white border border-[#F7F3EC] rounded-2xl shadow-xl overflow-hidden w-44">
              {SORT_OPTIONS.map(opt => (
                <button
                  key={opt.value}
                  onClick={() => { onSortChange(opt.value); setShowSort(false); }}
                  className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                    sortBy === opt.value
                      ? "bg-[#3D6B4F]/8 text-[#3D6B4F] font-semibold"
                      : "text-[#211b11] hover:bg-[#F7F3EC]"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
