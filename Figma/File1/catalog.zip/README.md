
  # Mobile UI Design Conversion

  This is a code bundle for Mobile UI Design Conversion. The original project is available at https://www.figma.com/design/GYDdDQeWDvF4WILMcMwn1V/Mobile-UI-Design-Conversion.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  