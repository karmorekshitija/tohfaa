import React, { useState, useMemo } from "react";
import { Drawer } from "vaul";
import { X, Search, Settings2, Star, CheckCircle, AlertCircle, CornerDownRight, Minus, Plus } from "lucide-react";

const C = {
  primary: "#3D6B4F",
  gold: "#C8973A",
  sage: "#8FAF82",
  surface: "#FFFFFF",
  surfaceVariant: "#F7F3EC",
  surfaceContainer: "#f9ecdc",
  onSurface: "#211b11",
  onSurfaceVariant: "#414942",
  outlineVariant: "rgba(113,121,114,0.15)",
  outline: "rgba(113,121,114,0.3)",
};

// ── Types ─────────────────────────────────────────────────────────────────────
interface Review {
  id: number;
  reviewer_handle: string;
  listing_title: string;
  rating: number;
  body: string;
  created_at: string;
  reply?: string;
}

type FilterKey = "all" | "unreplied" | "critical";

// ── Mock data ─────────────────────────────────────────────────────────────────
const MOCK_REVIEWS: Review[] = [
  {
    id: 1, reviewer_handle: "priya_p", listing_title: "Handwoven Wall Hanging",
    rating: 5, created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    body: "Absolutely stunning piece! The craftsmanship is extraordinary — you can feel the love and patience in every single thread. Will definitely order again.",
    reply: "Thank you so much, Priya! It truly warms my heart to hear this. Each piece takes days to weave and I'm glad it arrived safely.",
  },
  {
    id: 2, reviewer_handle: "aarav_homes", listing_title: "Terracotta Coffee Mug Set",
    rating: 4, created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
    body: "Beautiful mugs with great earthy texture. Shipping took a bit longer than expected but packaging was excellent and everything arrived intact.",
  },
  {
    id: 3, reviewer_handle: "meera_n", listing_title: "Soy Wax Lavender Candle",
    rating: 2, created_at: new Date(Date.now() - 86400000 * 8).toISOString(),
    body: "The scent was much fainter than I expected from the photos. The candle itself looks beautiful but didn't fill the room with fragrance at all.",
  },
  {
    id: 4, reviewer_handle: "kabir_sen", listing_title: "Walnut Wood Coasters (Set of 4)",
    rating: 5, created_at: new Date(Date.now() - 86400000 * 12).toISOString(),
    body: "Premium quality! These coasters look like they belong in a design magazine. Perfect gift for my parents.",
  },
  {
    id: 5, reviewer_handle: "riya_crafts", listing_title: "Jute Tote Bag",
    rating: 3, created_at: new Date(Date.now() - 86400000 * 15).toISOString(),
    body: "Nice product but the handle stitching came loose after a week. Reached out to the seller who was very responsive and helpful.",
    reply: "Dear Riya, so sorry to hear about the stitching issue! I've already sent you a replacement. Quality is something I take very seriously.",
  },
  {
    id: 6, reviewer_handle: "dev_arts", listing_title: "Indigo Block Print Cushion",
    rating: 1, created_at: new Date(Date.now() - 86400000 * 20).toISOString(),
    body: "Product looked very different from the photos. The colours were much more faded and size was smaller than described. Disappointed.",
  },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatDate(dt: string) {
  return new Date(dt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function StarRow({ rating, size = 14 }: { rating: number; size?: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <Star
          key={i}
          size={size}
          fill={i <= Math.round(rating) ? C.gold : "transparent"}
          color={i <= Math.round(rating) ? C.gold : C.outline}
          strokeWidth={1.5}
        />
      ))}
    </div>
  );
}

function Toast({ msg, type }: { msg: string; type: "success" | "error" }) {
  return (
    <div style={{ background: type === "success" ? C.primary : "#FEE2E2", color: type === "success" ? "#fff" : "#991B1B" }}
         className="fixed top-4 left-4 right-4 z-[300] flex items-center gap-2 px-4 py-3 rounded-2xl shadow-lg text-sm font-medium max-w-[430px] mx-auto">
      {type === "success" ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
      {msg}
    </div>
  );
}

// ── Summary strip ─────────────────────────────────────────────────────────────
function SummaryStrip({ reviews }: { reviews: Review[] }) {
  const total = reviews.length;
  const avg = total > 0 ? (reviews.reduce((s, r) => s + r.rating, 0) / total) : 0;
  const pending = reviews.filter(r => !r.reply).length;
  const responseRate = total > 0 ? Math.round(((total - pending) / total) * 100) : 100;
  const dist: Record<number, number> = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  reviews.forEach(r => { dist[r.rating] = (dist[r.rating] || 0) + 1; });

  return (
    <div className="flex flex-col gap-3 px-4 mb-4">
      {/* Overall + Distribution side by side */}
      <div className="grid grid-cols-2 gap-3">
        {/* Overall Rating */}
        <div style={{ background: C.surface, borderColor: C.outline }}
             className="border rounded-2xl p-4 flex flex-col items-center justify-center shadow-sm">
          <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
             className="text-[9px] uppercase tracking-widest opacity-70 mb-1">Rating</p>
          <p style={{ color: C.primary, fontFamily: "'Space Mono', monospace" }}
             className="text-4xl font-bold leading-none">{avg.toFixed(1)}</p>
          <div className="mt-2">
            <StarRow rating={avg} size={12} />
          </div>
          <p style={{ color: C.onSurfaceVariant }} className="text-[10px] mt-1.5 opacity-60">
            {total} review{total !== 1 ? "s" : ""}
          </p>
        </div>

        {/* Pending replies */}
        <div style={{ background: C.surface, borderColor: C.outline }}
             className="border rounded-2xl p-4 flex flex-col justify-between shadow-sm">
          <div>
            <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
               className="text-[9px] uppercase tracking-widest opacity-70 mb-1">Needs Reply</p>
            <p style={{ color: pending > 0 ? "#D97706" : C.primary, fontFamily: "'Space Mono', monospace" }}
               className="text-4xl font-bold leading-none">{pending}</p>
            <p style={{ color: C.onSurfaceVariant }} className="text-xs italic mt-1">Awaiting response</p>
          </div>
          <div className="flex items-center gap-1.5 mt-3">
            <span style={{ background: C.primary }} className="w-2 h-2 rounded-full flex-shrink-0" />
            <p style={{ color: C.onSurfaceVariant }} className="text-[10px]">
              Response rate: <strong style={{ color: C.primary }}>{responseRate}%</strong>
            </p>
          </div>
        </div>
      </div>

      {/* Rating Distribution */}
      <div style={{ background: C.surface, borderColor: C.outline }}
           className="border rounded-2xl p-4 shadow-sm">
        <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
           className="text-[9px] uppercase tracking-widest opacity-70 mb-3">Rating Distribution</p>
        <div className="space-y-2">
          {[5, 4, 3, 2, 1].map(stars => {
            const count = dist[stars] || 0;
            const pct = total > 0 ? Math.round((count / total) * 100) : 0;
            return (
              <div key={stars} className="flex items-center gap-2">
                <span style={{ color: C.onSurfaceVariant, fontFamily: "'Space Mono', monospace" }}
                      className="text-[10px] w-5 flex-shrink-0">{stars}★</span>
                <div style={{ background: C.surfaceVariant }} className="flex-1 h-1.5 rounded-full overflow-hidden">
                  <div style={{ width: `${pct}%`, background: C.primary, transition: "width 0.6s ease" }}
                       className="h-full rounded-full" />
                </div>
                <span style={{ color: C.onSurfaceVariant, fontFamily: "'Space Mono', monospace" }}
                      className="text-[10px] w-4 text-right">{count}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── Filter tabs ───────────────────────────────────────────────────────────────
const FILTERS: { key: FilterKey; label: string }[] = [
  { key: "all",       label: "All Reviews" },
  { key: "unreplied", label: "Needs Reply" },
  { key: "critical",  label: "Critical (1-2★)" },
];

function FilterTabs({ active, onChange }: { active: FilterKey; onChange: (k: FilterKey) => void }) {
  return (
    <div style={{ borderBottom: `2px solid ${C.outlineVariant}` }}
         className="flex gap-5 overflow-x-auto px-4" style={{ scrollbarWidth: "none" as const }}>
      {FILTERS.map(f => {
        const on = f.key === active;
        return (
          <button key={f.key} onClick={() => onChange(f.key)}
                  style={{
                    color: on ? C.primary : C.onSurfaceVariant,
                    borderBottom: on ? `2px solid ${C.primary}` : "2px solid transparent",
                    fontFamily: "'Cinzel', serif",
                    marginBottom: "-2px",
                  }}
                  className="flex-shrink-0 text-[10px] uppercase tracking-widest font-bold pb-2 px-1 transition-colors">
            {f.label}
          </button>
        );
      })}
    </div>
  );
}

// ── Inline Reply Form ─────────────────────────────────────────────────────────
function ReplyForm({ reviewId, onSubmit, onCancel }: {
  reviewId: number; onSubmit: (text: string) => void; onCancel: () => void;
}) {
  const [text, setText] = useState("");
  return (
    <div className="mt-3 space-y-2">
      <textarea
        rows={3}
        value={text}
        onChange={e => setText(e.target.value)}
        placeholder="Write a thoughtful response..."
        style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem", color: C.onSurface, resize: "none" }}
        className="w-full px-3 py-2.5 text-sm bg-white focus:outline-none"
      />
      <div className="flex gap-2">
        <button onClick={() => { if (text.trim()) onSubmit(text.trim()); }}
                style={{ background: C.primary }}
                className="text-white text-xs font-bold px-4 py-2 rounded-lg active:opacity-80 flex-shrink-0">
          Send Response
        </button>
        <button onClick={onCancel}
                style={{ border: `1px solid ${C.outline}`, color: C.onSurfaceVariant }}
                className="text-xs font-bold px-4 py-2 rounded-lg active:opacity-70 flex-shrink-0">
          Cancel
        </button>
      </div>
    </div>
  );
}

// ── Review Card ───────────────────────────────────────────────────────────────
function ReviewCard({ review, onReply }: {
  review: Review;
  onReply: (id: number, text: string) => void;
}) {
  const [showForm, setShowForm] = useState(false);
  const initials = review.reviewer_handle.charAt(0).toUpperCase();

  return (
    <div style={{ background: C.surface, borderColor: C.outline }}
         className="mx-4 border rounded-2xl p-4 shadow-sm">
      {/* Header row */}
      <div className="flex items-start gap-3 mb-3">
        <div style={{ background: C.surfaceVariant, color: C.primary }}
             className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-base flex-shrink-0">
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p style={{ color: C.onSurface }} className="text-sm font-bold leading-tight">{review.reviewer_handle}</p>
              <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
                 className="text-[9px] uppercase tracking-wider opacity-70 mt-0.5 truncate">{review.listing_title}</p>
            </div>
            <p style={{ color: C.onSurfaceVariant, fontFamily: "'Space Mono', monospace" }}
               className="text-[10px] flex-shrink-0">{formatDate(review.created_at)}</p>
          </div>
          <div className="mt-1.5">
            <StarRow rating={review.rating} size={13} />
          </div>
        </div>
      </div>

      {/* Review body */}
      <p style={{ color: C.onSurfaceVariant }} className="text-sm italic leading-relaxed mb-3">
        "{review.body}"
      </p>

      {/* Verified badge */}
      <div className="flex items-center gap-1.5 mb-3">
        <span style={{ background: C.primary }}
              className="flex items-center gap-1 text-white text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full">
          <CheckCircle size={9} strokeWidth={2.5} />
          Verified Purchase
        </span>
      </div>

      {/* Reply block or CTA */}
      {review.reply ? (
        <div style={{ background: C.surfaceContainer, borderLeft: `2px solid ${C.primary}` }}
             className="p-3 rounded-lg">
          <p style={{ color: C.primary }} className="text-xs font-bold italic mb-1">Response from Studio</p>
          <p style={{ color: C.onSurfaceVariant }} className="text-xs leading-relaxed">{review.reply}</p>
        </div>
      ) : showForm ? (
        <ReplyForm
          reviewId={review.id}
          onSubmit={(text) => { onReply(review.id, text); setShowForm(false); }}
          onCancel={() => setShowForm(false)}
        />
      ) : (
        <button onClick={() => setShowForm(true)}
                style={{ border: `1px solid ${C.primary}`, color: C.primary }}
                className="flex items-center gap-1.5 text-xs font-bold px-3 py-2 rounded-xl active:opacity-70">
          <CornerDownRight size={12} />
          Reply to review
        </button>
      )}
    </div>
  );
}

// ── Auto-Request Settings Drawer ──────────────────────────────────────────────
function AutoRequestDrawer({ open, onClose, onSave }: {
  open: boolean; onClose: () => void; onSave: () => void;
}) {
  const [enabled, setEnabled] = useState(true);
  const [days, setDays] = useState(3);

  return (
    <Drawer.Root open={open} onOpenChange={v => { if (!v) onClose(); }}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 z-50 bg-black/30" />
        <Drawer.Content style={{ background: C.surface }}
                        className="fixed bottom-0 left-0 right-0 z-50 rounded-t-3xl flex flex-col max-w-[430px] mx-auto">
          <div className="flex justify-center pt-3 pb-1">
            <div style={{ background: C.outlineVariant }} className="w-10 h-1 rounded-full" />
          </div>
          <div style={{ borderBottom: `1px solid ${C.outlineVariant}` }}
               className="flex items-center justify-between px-5 py-4">
            <h2 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
                className="text-xl font-bold italic">Auto-Request Settings</h2>
            <button onClick={onClose} style={{ color: C.onSurfaceVariant }} className="p-2 rounded-full hover:bg-gray-100">
              <X size={20} />
            </button>
          </div>
          <div className="px-5 py-5 space-y-6">
            {/* Enable toggle */}
            <div className="flex items-center justify-between">
              <span style={{ color: C.onSurface }} className="text-sm font-bold">Enable Auto-Requests</span>
              <button onClick={() => setEnabled(!enabled)}
                      style={{ background: enabled ? C.primary : C.surfaceVariant }}
                      className="relative w-11 h-6 rounded-full transition-colors flex-shrink-0">
                <span style={{ transform: enabled ? "translateX(20px)" : "translateX(2px)" }}
                      className="absolute top-[3px] left-0 w-[18px] h-[18px] bg-white rounded-full shadow transition-transform" />
              </button>
            </div>

            {/* Days stepper */}
            <div>
              <label style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
                     className="text-[9px] uppercase tracking-widest font-bold block mb-2">
                Send request after delivery
              </label>
              <div style={{ border: `1px solid ${C.outline}`, borderRadius: "0.75rem" }}
                   className="flex items-center overflow-hidden w-36">
                <button onClick={() => setDays(d => Math.max(1, d - 1))}
                        style={{ color: C.primary }} className="p-2.5 hover:bg-gray-50">
                  <Minus size={16} />
                </button>
                <span style={{ color: C.onSurface, fontFamily: "'Space Mono', monospace" }}
                      className="flex-1 text-center text-sm font-bold">
                  {days} Day{days > 1 ? "s" : ""}
                </span>
                <button onClick={() => setDays(d => Math.min(30, d + 1))}
                        style={{ color: C.primary }} className="p-2.5 hover:bg-gray-50">
                  <Plus size={16} />
                </button>
              </div>
            </div>

            {/* Message preview */}
            <div>
              <label style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
                     className="text-[9px] uppercase tracking-widest font-bold block mb-2">
                Message Template Preview
              </label>
              <div style={{ background: C.surfaceVariant, borderColor: C.outline }}
                   className="border rounded-xl p-4">
                <p style={{ color: C.onSurfaceVariant }} className="text-xs italic leading-relaxed">
                  "Hi [Name], your studio find has arrived! If it brings you joy, would you share a quick review? Your feedback helps my small studio thrive."
                </p>
              </div>
            </div>

            {/* Feature bullets */}
            <ul className="space-y-1.5">
              {["Automatically filtered for successful deliveries.", "Includes direct link to photo upload."].map(t => (
                <li key={t} className="flex items-start gap-2 text-xs" style={{ color: C.onSurfaceVariant }}>
                  <span style={{ color: C.gold }} className="flex-shrink-0 mt-0.5">✦</span>
                  {t}
                </li>
              ))}
            </ul>

            <button onClick={onSave} style={{ background: C.primary }}
                    className="w-full text-white font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2 active:opacity-80">
              Save Settings
            </button>
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

// ── Main ReviewsPage ──────────────────────────────────────────────────────────
export function ReviewsPage() {
  const [reviews, setReviews] = useState<Review[]>(MOCK_REVIEWS);
  const [filter, setFilter] = useState<FilterKey>("all");
  const [search, setSearch] = useState("");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: "success" | "error" } | null>(null);

  function showToast(msg: string, type: "success" | "error" = "success") {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3200);
  }

  function handleReply(id: number, text: string) {
    setReviews(prev => prev.map(r => r.id === id ? { ...r, reply: text } : r));
    showToast("Reply submitted successfully!");
  }

  const filtered = useMemo(() => {
    let list = reviews;
    if (filter === "unreplied") list = list.filter(r => !r.reply);
    if (filter === "critical")  list = list.filter(r => r.rating <= 2);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(r =>
        r.body.toLowerCase().includes(q) ||
        r.reviewer_handle.toLowerCase().includes(q) ||
        r.listing_title.toLowerCase().includes(q)
      );
    }
    return list;
  }, [reviews, filter, search]);

  return (
    <div style={{ background: "#FAF7F2", fontFamily: "'DM Sans', sans-serif" }} className="min-h-full flex flex-col">
      {toast && <Toast msg={toast.msg} type={toast.type} />}

      {/* Header */}
      <header style={{ background: C.surface, borderBottom: `1px solid ${C.outlineVariant}` }}
              className="sticky top-0 z-40 px-4 pt-10 pb-3">
        <div className="flex items-end justify-between mb-3">
          <div>
            <p style={{ color: C.gold, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest font-bold">Seller Studio</p>
            <h1 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }} className="text-2xl italic font-bold mt-0.5">Studio Reviews</h1>
            <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5 opacity-70">Feedback from your buyers</p>
          </div>
          <button onClick={() => setDrawerOpen(true)}
                  style={{ border: `1px solid ${C.sage}`, color: C.primary }}
                  className="flex items-center gap-1.5 text-xs font-bold px-3 py-2 rounded-xl bg-white">
            <Settings2 size={14} />
            Auto-Request
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search size={14} color={C.onSurfaceVariant}
                  className="absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search reviews…"
            style={{ border: `1px solid ${C.outline}`, borderRadius: "999px", color: C.onSurface }}
            className="w-full pl-8 pr-4 py-2 text-sm bg-white focus:outline-none"
          />
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto pb-6 pt-4">
        <SummaryStrip reviews={reviews} />

        {/* Filter tabs */}
        <div className="mb-4">
          <FilterTabs active={filter} onChange={setFilter} />
        </div>

        {/* Reviews */}
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center py-16 gap-3 text-center px-8">
            <Star size={48} color={C.sage} fill={C.sage} />
            <h3 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }} className="text-xl italic font-bold">No reviews found</h3>
            <p style={{ color: C.onSurfaceVariant }} className="text-sm opacity-70">No reviews match the current filter.</p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {filtered.map(r => (
              <ReviewCard key={r.id} review={r} onReply={handleReply} />
            ))}
          </div>
        )}
      </main>

      <AutoRequestDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        onSave={() => { setDrawerOpen(false); showToast("Auto-request settings saved!"); }}
      />
    </div>
  );
}
