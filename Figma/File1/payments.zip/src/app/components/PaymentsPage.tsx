import React, { useState } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Drawer } from "vaul";
import {
  ArrowLeft, Download, CreditCard, Smartphone, FileText,
  Filter, ChevronRight, X, AlertTriangle, Receipt,
  CheckCircle, AlertCircle, TrendingUp, Calendar,
} from "lucide-react";

const C = {
  primary: "#3D6B4F", gold: "#C8973A", sage: "#8FAF82",
  violet: "#7B5EA7", surface: "#FFFFFF", surfaceVariant: "#F7F3EC",
  surfaceContainer: "#f9ecdc", onSurface: "#211b11",
  onSurfaceVariant: "#414942", outlineVariant: "rgba(113,121,114,0.15)",
  outline: "rgba(113,121,114,0.3)",
};

type SubPage = "main" | "settlements" | "transactions" | "disputes";
type BankTab = "bank" | "upi";
type TrendPeriod = "7d" | "30d" | "90d";

// ── Mock data ──────────────────────────────────────────────────────────────────
const TREND: Record<TrendPeriod, { l: string; v: number }[]> = {
  "7d":  [{ l:"Jun 4",v:4200},{l:"Jun 5",v:3100},{l:"Jun 6",v:5600},{l:"Jun 7",v:7200},{l:"Jun 8",v:4800},{l:"Jun 9",v:6100},{l:"Jun 10",v:7900}],
  "30d": [{ l:"May 12",v:15000},{l:"May 17",v:18500},{l:"May 22",v:14200},{l:"May 27",v:22000},{l:"May 31",v:19800},{l:"Jun 5",v:24500},{l:"Jun 10",v:29000}],
  "90d": [{ l:"Mar 15",v:55000},{l:"Mar 30",v:62000},{l:"Apr 15",v:68000},{l:"Apr 30",v:75000},{l:"May 15",v:71000},{l:"May 30",v:80000},{l:"Jun 10",v:84000}],
};

const SETTLEMENTS = [
  { date: "12 Jun 2026", buyer: "Kavitha S.", product: "Hand-woven Silk Shawl", method: "UPI", amount: "₹1,274.00" },
  { date: "09 Jun 2026", buyer: "Priya P.",   product: "Terracotta Vase Set",    method: "Card", amount: "₹850.00"  },
  { date: "05 Jun 2026", buyer: "Aarav S.",   product: "Brass Incense Holder",  method: "UPI", amount: "₹620.00"  },
];

const TRANSACTIONS = [
  { date: "12 Jun", ref: "TXN-0412", type: "SALE",        gross: "₹1,400", fee: "₹112", tds: "₹14",  net: "₹1,274", typeColor: C.primary },
  { date: "09 Jun", ref: "TXN-0389", type: "SALE",        gross: "₹920",   fee: "₹74",  tds: "₹9",   net: "₹837",   typeColor: C.primary },
  { date: "04 Jun", ref: "TXN-0351", type: "REFUND",      gross: "₹200",   fee: "₹0",   tds: "₹0",   net: "-₹200",  typeColor: "#DC2626" },
  { date: "01 Jun", ref: "TXN-0320", type: "PLATFORM FEE",gross: "₹50",    fee: "₹0",   tds: "₹0",   net: "-₹50",   typeColor: "#D97706" },
];

const DISPUTES = [
  { id: "DSP-001", orderId: "TF-0042", buyer: "Kavitha S.", amount: "₹1,400", date: "10 Jun 2026", status: "OPEN",      reason: "Item received had loose stitching and quality was not as described in the listing photos." },
  { id: "DSP-002", orderId: "TF-0038", buyer: "Riya M.",    amount: "₹650",   date: "05 Jun 2026", status: "CONTESTED", reason: "Product colour was significantly different from what was shown online." },
];

const INVOICES = [
  { month: "June 2026" },
  { month: "May 2026" },
  { month: "April 2026" },
];

// ── Shared helpers ─────────────────────────────────────────────────────────────
function Toast({ msg, type }: { msg: string; type: "success" | "error" }) {
  return (
    <div style={{ background: type === "success" ? C.primary : "#FEE2E2", color: type === "success" ? "#fff" : "#991B1B" }}
         className="fixed top-4 left-4 right-4 z-[300] flex items-center gap-2 px-4 py-3 rounded-2xl shadow-lg text-sm font-medium max-w-[430px] mx-auto">
      {type === "success" ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
      {msg}
    </div>
  );
}

function PageHeader({ title, subtitle, onBack }: { title: string; subtitle?: string; onBack?: () => void }) {
  return (
    <header style={{ background: C.surface, borderBottom: `1px solid ${C.outlineVariant}` }}
            className="sticky top-0 z-40 px-4 pt-10 pb-4">
      <div className="flex items-start gap-3">
        {onBack && (
          <button onClick={onBack} style={{ color: C.primary }} className="mt-1 flex-shrink-0">
            <ArrowLeft size={20} />
          </button>
        )}
        <div>
          <p style={{ color: C.gold, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest font-bold">Seller Studio</p>
          <h1 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }} className="text-2xl italic font-bold mt-0.5 leading-tight">{title}</h1>
          {subtitle && <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5 opacity-70">{subtitle}</p>}
        </div>
      </div>
    </header>
  );
}

function SectionCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div style={{ background: C.surface, borderColor: C.outline }}
         className={`mx-4 border rounded-2xl overflow-hidden shadow-sm ${className}`}>
      {children}
    </div>
  );
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return <label style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
                className="text-[9px] uppercase tracking-widest font-bold block mb-1.5">{children}</label>;
}

function Field({ label, value, onChange, placeholder, type = "text", masked }: {
  label: string; value: string; onChange: (v: string) => void;
  placeholder?: string; type?: string; masked?: boolean;
}) {
  return (
    <div>
      <FieldLabel>{label}</FieldLabel>
      <input type={masked ? "password" : type} value={value} onChange={e => onChange(e.target.value)}
             placeholder={placeholder}
             style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem", color: C.onSurface }}
             className="w-full px-3 py-2.5 text-sm bg-white focus:outline-none" />
    </div>
  );
}

function SaveBtn({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} style={{ background: C.primary }}
            className="w-full text-white font-bold py-3 rounded-xl text-sm active:opacity-80">
      {label}
    </button>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: () => void }) {
  return (
    <button onClick={onChange} style={{ background: on ? C.primary : C.surfaceVariant }}
            className="relative w-11 h-6 rounded-full transition-colors flex-shrink-0">
      <span style={{ transform: on ? "translateX(20px)" : "translateX(2px)" }}
            className="absolute top-[3px] left-0 w-[18px] h-[18px] bg-white rounded-full shadow transition-transform" />
    </button>
  );
}

function StatusChip({ status }: { status: string }) {
  const map: Record<string, { bg: string; text: string }> = {
    OPEN:      { bg: "#FEF3C7", text: "#92400E" },
    CONTESTED: { bg: "#EDE9FE", text: "#5B21B6" },
    ACCEPTED:  { bg: "#D1FAE5", text: "#065F46" },
    CLOSED:    { bg: "#F3F4F6", text: "#374151" },
  };
  const s = map[status] || map.CLOSED;
  return (
    <span style={{ background: s.bg, color: s.text }}
          className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full">{status}</span>
  );
}

// ── Tooltip ───────────────────────────────────────────────────────────────────
function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: C.surface, border: `1px solid ${C.outline}`, borderRadius: "0.75rem" }}
         className="px-3 py-2 shadow-lg">
      <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest mb-1">{label}</p>
      <p style={{ color: C.primary, fontFamily: "'Space Mono', monospace" }} className="text-sm font-bold">
        ₹{(payload[0].value / 100).toLocaleString("en-IN")}
      </p>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ── MAIN OVERVIEW ─────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
function MainView({ onNav }: { onNav: (s: SubPage) => void }) {
  const [trendPeriod, setTrendPeriod] = useState<TrendPeriod>("30d");
  const [bankTab, setBankTab]         = useState<BankTab>("bank");
  const [toast, setToast]             = useState<{ msg: string; type: "success"|"error" } | null>(null);

  // Bank form
  const [holderName, setHolderName] = useState("Amit Sharma");
  const [bankName, setBankNameVal]  = useState("State Bank of India");
  const [accNum, setAccNum]         = useState("••••••••");
  const [confirmAcc, setConfirmAcc] = useState("");
  const [ifsc, setIfsc]             = useState("SBIN0001234");
  const [upiId, setUpiId]           = useState("");

  // Tax & GST
  const [gstEnabled, setGstEnabled] = useState(false);
  const [panNum, setPanNum]         = useState("ABCDE1234F");
  const [tdsEnabled, setTdsEnabled] = useState(false);

  function showToast(msg: string, type: "success"|"error" = "success") {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  }

  const kpis = [
    { label: "Total Earnings", value: "₹1,43,200" },
    { label: "This Month",     value: "₹18,400"   },
    { label: "This Week",      value: "₹4,800"    },
    { label: "Settled Directly",value: "₹1,31,000" },
  ];

  return (
    <div className="flex flex-col">
      {toast && <Toast msg={toast.msg} type={toast.type} />}
      <PageHeader title="Settlements & Payments" subtitle="Manage direct-to-bank earnings, tax config & transaction logs" />

      <main className="flex-1 overflow-y-auto pb-6 pt-4 space-y-4">

        {/* KPI cards */}
        <div className="grid grid-cols-2 gap-3 px-4">
          {kpis.map(k => (
            <div key={k.label} style={{ background: C.surface, borderColor: C.outlineVariant }}
                 className="border rounded-2xl p-4 shadow-sm">
              <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
                 className="text-[8px] uppercase tracking-widest opacity-70 leading-none">{k.label}</p>
              <p style={{ color: C.primary, fontFamily: "'Space Mono', monospace" }}
                 className="text-xl font-bold mt-2 leading-none">{k.value}</p>
            </div>
          ))}
        </div>

        {/* Earnings Trend */}
        <SectionCard>
          <div className="flex items-center justify-between px-4 pt-4 pb-2">
            <h2 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
                className="text-base italic font-bold">Earnings Trend</h2>
            <div className="flex gap-1">
              {(["7d","30d","90d"] as TrendPeriod[]).map(p => (
                <button key={p} onClick={() => setTrendPeriod(p)}
                        style={{ background: p === trendPeriod ? C.primary : "transparent", color: p === trendPeriod ? "#fff" : C.onSurfaceVariant, border: `1px solid ${p === trendPeriod ? C.primary : C.outline}` }}
                        className="text-[9px] font-bold px-2.5 py-1 rounded-lg transition-all">
                  {p === "7d" ? "7 Days" : p === "30d" ? "30 Days" : "3 Months"}
                </button>
              ))}
            </div>
          </div>
          <div className="px-2 pb-4">
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={TREND[trendPeriod]} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id="earningsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor={C.primary} stopOpacity={0.15} />
                    <stop offset="95%" stopColor={C.primary} stopOpacity={0.01} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(113,121,114,0.08)" vertical={false} />
                <XAxis dataKey="l" tick={{ fontSize: 9, fontFamily: "Space Mono", fill: C.onSurfaceVariant }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 9, fontFamily: "Space Mono", fill: C.onSurfaceVariant }} axisLine={false} tickLine={false}
                       tickFormatter={v => "₹" + (v >= 1000 ? Math.round(v/1000) + "k" : v)} />
                <Tooltip content={<ChartTooltip />} />
                <Area type="monotone" dataKey="v" stroke={C.primary} strokeWidth={2} fill="url(#earningsGrad)"
                      dot={{ r: 3, fill: C.primary, strokeWidth: 0 }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>

        {/* Receiving Bank Details */}
        <SectionCard>
          <div className="px-4 pt-4 pb-2">
            <h2 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
                className="text-base italic font-bold">Receiving Bank Details</h2>
            <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5 opacity-70">Configure where you receive direct settlements (minus commissions/fees).</p>
          </div>
          {/* Tabs */}
          <div style={{ borderBottom: `1px solid ${C.outlineVariant}` }} className="flex mx-4">
            {([["bank","Bank Account"],["upi","UPI VPA"]] as [BankTab,string][]).map(([k,l]) => (
              <button key={k} onClick={() => setBankTab(k)}
                      style={{ color: bankTab===k ? C.primary : C.onSurfaceVariant, borderBottom: bankTab===k ? `2px solid ${C.primary}` : "2px solid transparent", marginBottom: "-1px" }}
                      className="flex items-center gap-1.5 text-sm font-bold pb-2.5 pr-6 transition-colors">
                {k === "bank" ? <CreditCard size={13} /> : <Smartphone size={13} />}
                {l}
              </button>
            ))}
          </div>
          <div className="px-4 py-4 space-y-3">
            {bankTab === "bank" ? (
              <>
                <Field label="Account Holder Name" value={holderName} onChange={setHolderName} placeholder="Full name" />
                <Field label="Bank Name"            value={bankName}   onChange={setBankNameVal} placeholder="e.g. State Bank of India" />
                <Field label="Account Number"       value={accNum}     onChange={setAccNum}      placeholder="Account number" masked />
                <Field label="Confirm Account Number" value={confirmAcc} onChange={setConfirmAcc} placeholder="Re-enter account number" masked />
                <Field label="IFSC Code"            value={ifsc}       onChange={setIfsc}        placeholder="e.g. SBIN0001234" />
                <SaveBtn label="Save Settlement Details" onClick={() => showToast("Bank details saved!")} />
              </>
            ) : (
              <>
                <Field label="UPI VPA / ID" value={upiId} onChange={setUpiId} placeholder="yourname@upi" />
                <SaveBtn label="Save UPI Details" onClick={() => showToast("UPI details saved!")} />
              </>
            )}
          </div>
        </SectionCard>

        {/* Recent Settlements */}
        <SectionCard>
          <div style={{ borderBottom: `1px solid ${C.outlineVariant}` }}
               className="flex items-center justify-between px-4 py-4">
            <h2 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
                className="text-base italic font-bold">Recent Settlements</h2>
            <button onClick={() => onNav("settlements")}
                    style={{ color: C.violet }} className="text-xs font-bold flex items-center gap-1">
              View Payments <ChevronRight size={13} />
            </button>
          </div>
          <div className="divide-y" style={{ borderColor: C.outlineVariant }}>
            {SETTLEMENTS.map((s, i) => (
              <div key={i} className="flex items-center justify-between px-4 py-3 gap-3">
                <div className="flex-1 min-w-0">
                  <p style={{ color: C.onSurface }} className="text-sm font-semibold truncate">{s.buyer}</p>
                  <p style={{ color: C.onSurfaceVariant }} className="text-xs truncate opacity-70">{s.product}</p>
                  <p style={{ color: C.onSurfaceVariant, fontFamily: "'Space Mono', monospace" }} className="text-[10px] mt-0.5">{s.date} · {s.method}</p>
                </div>
                <p style={{ color: C.primary, fontFamily: "'Space Mono', monospace" }}
                   className="text-sm font-bold flex-shrink-0">{s.amount}</p>
              </div>
            ))}
          </div>
        </SectionCard>

        {/* Recent Transaction Ledger */}
        <SectionCard>
          <div style={{ borderBottom: `1px solid ${C.outlineVariant}` }}
               className="flex items-center justify-between px-4 py-4 gap-2 flex-wrap">
            <div>
              <h2 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
                  className="text-base italic font-bold">Recent Transaction Ledger</h2>
              <p style={{ color: C.onSurfaceVariant }} className="text-xs opacity-70">Sales, refunds, and adjustments</p>
            </div>
            <div className="flex gap-2">
              <button style={{ border: `1px solid ${C.outline}`, color: C.primary }}
                      className="flex items-center gap-1 text-xs font-bold px-2.5 py-1.5 rounded-lg">
                <Download size={11} /> Export
              </button>
              <button onClick={() => onNav("transactions")}
                      style={{ background: C.violet }}
                      className="text-white text-xs font-bold px-3 py-1.5 rounded-lg">
                View All
              </button>
            </div>
          </div>
          <div className="divide-y" style={{ borderColor: C.outlineVariant }}>
            {TRANSACTIONS.slice(0, 3).map((t, i) => (
              <div key={i} className="px-4 py-3">
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span style={{ background: t.typeColor + "18", color: t.typeColor }}
                          className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full">{t.type}</span>
                    <span style={{ color: C.onSurfaceVariant, fontFamily: "'Space Mono', monospace" }}
                          className="text-[10px]">{t.ref}</span>
                  </div>
                  <p style={{ color: C.onSurfaceVariant }} className="text-[10px] flex-shrink-0">{t.date}</p>
                </div>
                <div className="grid grid-cols-4 gap-1">
                  {[["Gross", t.gross], ["Fee", t.fee], ["TDS", t.tds], ["Net", t.net]].map(([l, v]) => (
                    <div key={l}>
                      <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }} className="text-[8px] uppercase tracking-wider opacity-60">{l}</p>
                      <p style={{ color: l === "Net" ? C.primary : C.onSurface, fontFamily: "'Space Mono', monospace" }} className="text-xs font-bold">{v}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </SectionCard>

        {/* Tax & GST Settings */}
        <SectionCard>
          <div className="px-4 pt-4 pb-2">
            <h2 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
                className="text-base italic font-bold">Tax &amp; GST Settings</h2>
            <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5 opacity-70">Configure your business taxes and download TDS sheets.</p>
          </div>
          <div className="px-4 py-3 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p style={{ color: C.onSurface }} className="text-sm font-bold">GST Registered?</p>
                <p style={{ color: C.onSurfaceVariant }} className="text-xs opacity-70">Toggle if you possess a valid GSTIN.</p>
              </div>
              <Toggle on={gstEnabled} onChange={() => setGstEnabled(!gstEnabled)} />
            </div>
            <Field label="PAN Number" value={panNum} onChange={setPanNum} placeholder="e.g. ABCDE1234F" />
            <div className="flex items-center justify-between">
              <div>
                <p style={{ color: C.onSurface }} className="text-sm font-bold">TDS Applicable</p>
                <p style={{ color: C.onSurfaceVariant }} className="text-xs opacity-70">Select if standard government TDS is deducted.</p>
              </div>
              <Toggle on={tdsEnabled} onChange={() => setTdsEnabled(!tdsEnabled)} />
            </div>
            <SaveBtn label="Save Tax Settings" onClick={() => showToast("Tax settings saved!")} />
            <div>
              <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
                 className="text-[9px] uppercase tracking-widest font-bold mb-2">Tax Documents</p>
              <div className="grid grid-cols-3 gap-2">
                {["GST Invoices", "Tax Summary", "TDS Certificate"].map(d => (
                  <button key={d} style={{ border: `1px solid ${C.outline}`, color: C.onSurface }}
                          className="text-[10px] font-bold py-2 rounded-xl active:opacity-70 text-center">
                    {d}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </SectionCard>

        {/* Invoices & Statements */}
        <SectionCard>
          <div className="px-4 pt-4 pb-2">
            <h2 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
                className="text-base italic font-bold">Invoices &amp; Statements</h2>
            <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5 opacity-70">Download past order invoices and monthly summary sheets.</p>
          </div>
          <div className="px-4 pb-4 space-y-3">
            {INVOICES.map(inv => (
              <div key={inv.month} style={{ borderColor: C.outlineVariant }}
                   className="flex items-center justify-between border rounded-xl px-3 py-3 gap-2">
                <div className="flex items-center gap-2">
                  <FileText size={15} color={C.primary} />
                  <p style={{ color: C.onSurface }} className="text-sm font-semibold">{inv.month} Settlements</p>
                </div>
                <div className="flex gap-1.5">
                  <button style={{ border: `1px solid ${C.outline}`, color: C.primary }}
                          className="text-[9px] font-bold px-2 py-1 rounded-lg flex items-center gap-1">
                    <Download size={9} /> PDF
                  </button>
                  <button style={{ border: `1px solid ${C.outline}`, color: C.primary }}
                          className="text-[9px] font-bold px-2 py-1 rounded-lg flex items-center gap-1">
                    <Download size={9} /> TDS
                  </button>
                </div>
              </div>
            ))}
            <div style={{ borderTop: `1px solid ${C.outlineVariant}` }} className="pt-3">
              <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
                 className="text-[9px] uppercase tracking-widest font-bold mb-2">Generate Monthly Statement</p>
              <div className="flex gap-2">
                <input type="month" style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem", color: C.onSurface }}
                       className="flex-1 px-3 py-2 text-sm bg-white focus:outline-none" />
                <button style={{ background: C.primary }}
                        className="text-white text-xs font-bold px-3 py-2 rounded-xl active:opacity-80 flex-shrink-0">
                  Download PDF
                </button>
              </div>
            </div>
          </div>
        </SectionCard>

        {/* Refunds & Disputes */}
        <SectionCard>
          <div className="flex items-center justify-between px-4 py-4">
            <div>
              <h2 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
                  className="text-base italic font-bold">Refunds &amp; Disputes</h2>
              <p style={{ color: C.onSurfaceVariant }} className="text-xs opacity-70">Review recent claims or issues flagged by buyers.</p>
            </div>
            <button onClick={() => onNav("disputes")}
                    style={{ background: C.violet }}
                    className="text-white text-xs font-bold px-3 py-2 rounded-xl active:opacity-80 flex items-center gap-1">
              View Disputes <ChevronRight size={12} />
            </button>
          </div>
          {DISPUTES.slice(0, 1).map(d => (
            <div key={d.id} style={{ borderTop: `1px solid ${C.outlineVariant}` }}
                 className="flex items-center justify-between px-4 py-3 gap-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <StatusChip status={d.status} />
                  <span style={{ color: C.onSurfaceVariant, fontFamily: "'Space Mono', monospace" }}
                        className="text-[10px]">{d.id}</span>
                </div>
                <p style={{ color: C.onSurface }} className="text-sm font-semibold">{d.buyer} · {d.amount}</p>
                <p style={{ color: C.onSurfaceVariant }} className="text-xs opacity-70 mt-0.5">{d.orderId}</p>
              </div>
              <ChevronRight size={16} color={C.onSurfaceVariant} />
            </div>
          ))}
        </SectionCard>
      </main>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ── SETTLEMENT HISTORY ────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
function SettlementsView({ onBack }: { onBack: () => void }) {
  return (
    <div className="flex flex-col">
      <PageHeader title="Settlement History" subtitle="Direct payout records for completed orders" onBack={onBack} />
      <main className="flex-1 overflow-y-auto pb-6 pt-4 px-4 space-y-3">
        {SETTLEMENTS.map((s, i) => (
          <div key={i} style={{ background: C.surface, borderColor: C.outline }}
               className="border rounded-2xl p-4 shadow-sm">
            <div className="flex items-start justify-between gap-2 mb-2">
              <p style={{ color: C.primary }} className="text-sm font-bold">{s.buyer}</p>
              <p style={{ color: C.primary, fontFamily: "'Space Mono', monospace" }}
                 className="text-base font-bold">{s.amount}</p>
            </div>
            <p style={{ color: C.onSurfaceVariant }} className="text-xs truncate">{s.product}</p>
            <div className="flex items-center justify-between mt-2">
              <p style={{ color: C.onSurfaceVariant, fontFamily: "'Space Mono', monospace" }} className="text-[10px]">{s.date}</p>
              <span style={{ background: C.surfaceVariant, color: C.onSurfaceVariant }}
                    className="text-[9px] font-bold px-2 py-0.5 rounded-full uppercase">{s.method}</span>
            </div>
          </div>
        ))}
        <p style={{ color: C.onSurfaceVariant }} className="text-xs text-center opacity-60 pt-2">Showing 3 of 3 settlements</p>
      </main>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ── TRANSACTION LEDGER ───────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
function TransactionsView({ onBack }: { onBack: () => void }) {
  const [typeFilter, setTypeFilter] = useState("all");
  const [startDate, setStartDate]   = useState("");
  const [endDate, setEndDate]       = useState("");

  const filtered = TRANSACTIONS.filter(t =>
    typeFilter === "all" || t.type.toLowerCase() === typeFilter
  );

  return (
    <div className="flex flex-col">
      <PageHeader title="Transaction Ledger" subtitle="A summary of sales, refunds, and adjustments" onBack={onBack} />
      <main className="flex-1 overflow-y-auto pb-6 pt-4">
        {/* Filters */}
        <div style={{ background: C.surface, borderColor: C.outlineVariant }}
             className="mx-4 border rounded-2xl p-4 mb-4 shadow-sm space-y-3">
          <div className="flex items-center gap-2">
            <Filter size={14} color={C.primary} />
            <p style={{ color: C.primary }} className="text-sm font-bold">Filters</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <FieldLabel>Start Date</FieldLabel>
              <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)}
                     style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem" }}
                     className="w-full px-2.5 py-2 text-xs bg-white focus:outline-none" />
            </div>
            <div>
              <FieldLabel>End Date</FieldLabel>
              <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)}
                     style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem" }}
                     className="w-full px-2.5 py-2 text-xs bg-white focus:outline-none" />
            </div>
          </div>
          <div>
            <FieldLabel>Type</FieldLabel>
            <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)}
                    style={{ border: `1px solid ${C.outline}`, borderRadius: "0.625rem", color: C.onSurface }}
                    className="w-full px-3 py-2 text-sm bg-white focus:outline-none">
              <option value="all">All Types</option>
              <option value="sale">Sales</option>
              <option value="refund">Refunds</option>
              <option value="platform fee">Platform Fees</option>
            </select>
          </div>
          <div className="flex gap-2">
            <button onClick={() => { setTypeFilter("all"); setStartDate(""); setEndDate(""); }}
                    style={{ border: `1px solid ${C.outline}`, color: C.onSurfaceVariant }}
                    className="flex-1 text-xs font-bold py-2 rounded-xl">Clear Filters</button>
            <button style={{ background: C.primary }}
                    className="flex-1 text-white text-xs font-bold py-2 rounded-xl flex items-center justify-center gap-1">
              <Download size={12} /> Export Ledger
            </button>
          </div>
        </div>

        {/* Transactions */}
        <div className="px-4 space-y-3">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center py-16 gap-3">
              <Receipt size={40} color={C.sage} />
              <p style={{ color: C.onSurfaceVariant }} className="text-sm opacity-60">No transactions match the selected criteria.</p>
            </div>
          ) : filtered.map((t, i) => (
            <div key={i} style={{ background: C.surface, borderColor: C.outline }}
                 className="border rounded-2xl p-4 shadow-sm">
              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <span style={{ background: t.typeColor + "18", color: t.typeColor }}
                        className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full">{t.type}</span>
                  <span style={{ color: C.onSurfaceVariant, fontFamily: "'Space Mono', monospace" }}
                        className="text-[10px]">{t.ref}</span>
                </div>
                <p style={{ color: C.onSurfaceVariant }} className="text-[10px]">{t.date}</p>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[["Gross", t.gross, false], ["Fee", t.fee, false], ["TDS", t.tds, false], ["Net", t.net, true]].map(([l, v, highlight]) => (
                  <div key={l as string}>
                    <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }} className="text-[8px] uppercase tracking-wider opacity-60">{l}</p>
                    <p style={{ color: highlight ? C.primary : C.onSurface, fontFamily: "'Space Mono', monospace" }}
                       className="text-xs font-bold mt-0.5">{v}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ── DISPUTES ──────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
function DisputesView({ onBack }: { onBack: () => void }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selected, setSelected]     = useState<typeof DISPUTES[0] | null>(null);
  const [contestText, setContestText] = useState("");
  const [toast, setToast] = useState<{ msg: string; type: "success"|"error" } | null>(null);

  function showToast(msg: string, type: "success"|"error" = "success") {
    setToast({ msg, type }); setTimeout(() => setToast(null), 3000);
  }

  return (
    <div className="flex flex-col">
      {toast && <Toast msg={toast.msg} type={toast.type} />}
      <PageHeader title="Disputes & Claims" subtitle="Review and respond to buyer claims" onBack={onBack} />
      <main className="flex-1 overflow-y-auto pb-6 pt-4 px-4 space-y-3">
        {DISPUTES.length === 0 ? (
          <div className="flex flex-col items-center py-20 gap-3">
            <AlertTriangle size={48} color={C.sage} />
            <p style={{ color: C.onSurfaceVariant }} className="text-sm opacity-60">No disputes found.</p>
          </div>
        ) : DISPUTES.map(d => (
          <button key={d.id} onClick={() => { setSelected(d); setContestText(""); setDrawerOpen(true); }}
                  style={{ background: C.surface, borderColor: C.outline }}
                  className="w-full border rounded-2xl p-4 shadow-sm text-left active:opacity-80">
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex items-center gap-2 flex-wrap">
                <StatusChip status={d.status} />
                <span style={{ color: C.onSurfaceVariant, fontFamily: "'Space Mono', monospace" }}
                      className="text-[10px]">{d.id}</span>
              </div>
              <ChevronRight size={16} color={C.onSurfaceVariant} />
            </div>
            <p style={{ color: C.onSurface }} className="text-sm font-bold">{d.buyer}</p>
            <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5">{d.orderId} · {d.date}</p>
            <p style={{ color: C.primary, fontFamily: "'Space Mono', monospace" }}
               className="text-base font-bold mt-1">{d.amount}</p>
            <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-2 line-clamp-2 italic">"{d.reason}"</p>
          </button>
        ))}
      </main>

      {/* Dispute detail drawer */}
      <Drawer.Root open={drawerOpen} onOpenChange={v => { if (!v) setDrawerOpen(false); }}>
        <Drawer.Portal>
          <Drawer.Overlay className="fixed inset-0 z-50 bg-black/30" />
          <Drawer.Content style={{ background: C.surface }}
                          className="fixed bottom-0 left-0 right-0 z-50 max-h-[92dvh] rounded-t-3xl flex flex-col max-w-[430px] mx-auto">
            <div className="flex justify-center pt-3 pb-1">
              <div style={{ background: C.outlineVariant }} className="w-10 h-1 rounded-full" />
            </div>
            {selected && (
              <>
                <div style={{ borderBottom: `1px solid ${C.outlineVariant}` }}
                     className="flex items-start justify-between px-5 py-4">
                  <div>
                    <p style={{ color: C.gold, fontFamily: "'Cinzel', serif" }} className="text-[9px] uppercase tracking-widest font-bold">{selected.id} · {selected.orderId}</p>
                    <h2 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
                        className="text-xl font-bold italic mt-0.5">Dispute Details</h2>
                  </div>
                  <button onClick={() => setDrawerOpen(false)} style={{ color: C.onSurfaceVariant }}>
                    <X size={20} />
                  </button>
                </div>
                <div className="overflow-y-auto px-5 py-5 flex-1 space-y-4">
                  {/* Info grid */}
                  <div style={{ background: C.surfaceVariant, borderColor: C.outlineVariant }}
                       className="border rounded-xl p-4 grid grid-cols-2 gap-3">
                    {[
                      ["Buyer",   selected.buyer],
                      ["Amount",  selected.amount],
                      ["Date",    selected.date],
                      ["Status",  selected.status],
                    ].map(([l, v]) => (
                      <div key={l}>
                        <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
                           className="text-[9px] uppercase tracking-widest opacity-70">{l}</p>
                        {l === "Status"
                          ? <div className="mt-1"><StatusChip status={v} /></div>
                          : <p style={{ color: C.onSurface }} className="text-sm font-semibold mt-0.5">{v}</p>}
                      </div>
                    ))}
                  </div>
                  {/* Buyer claim */}
                  <div>
                    <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
                       className="text-[9px] uppercase tracking-widest font-bold mb-2">Buyer's Claim</p>
                    <div style={{ background: "#FEF3C7", borderColor: "#FCD34D" }}
                         className="border rounded-xl p-4">
                      <p style={{ color: "#92400E" }} className="text-sm italic">"{selected.reason}"</p>
                    </div>
                  </div>
                  {/* Contest form */}
                  <div>
                    <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
                       className="text-[9px] uppercase tracking-widest font-bold mb-2">Your Response</p>
                    <textarea rows={4} value={contestText} onChange={e => setContestText(e.target.value)}
                              placeholder="Provide evidence or your side of the story…"
                              style={{ border: `1px solid ${C.outline}`, borderRadius: "0.75rem", resize: "none", color: C.onSurface }}
                              className="w-full px-3 py-2.5 text-sm bg-white focus:outline-none" />
                  </div>
                  <button onClick={() => { if (contestText.trim()) { showToast("Response submitted!"); setDrawerOpen(false); } else showToast("Please enter your response.", "error"); }}
                          style={{ background: C.primary }}
                          className="w-full text-white font-bold py-3 rounded-xl text-sm active:opacity-80">
                    Submit Response
                  </button>
                </div>
              </>
            )}
          </Drawer.Content>
        </Drawer.Portal>
      </Drawer.Root>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ── ROOT ──────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
export function PaymentsPage() {
  const [subPage, setSubPage] = useState<SubPage>("main");

  return (
    <div style={{ background: "#FAF7F2", fontFamily: "'DM Sans', sans-serif" }} className="min-h-full flex flex-col">
      {subPage === "main"         && <MainView        onNav={setSubPage} />}
      {subPage === "settlements"  && <SettlementsView onBack={() => setSubPage("main")} />}
      {subPage === "transactions" && <TransactionsView onBack={() => setSubPage("main")} />}
      {subPage === "disputes"     && <DisputesView    onBack={() => setSubPage("main")} />}
    </div>
  );
}
