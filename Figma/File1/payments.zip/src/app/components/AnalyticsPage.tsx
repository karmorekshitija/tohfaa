import React, { useState, useMemo } from "react";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Area, AreaChart,
} from "recharts";
import { Download, TrendingUp, ShoppingBag, Users, Percent, AlertCircle, Clock, Star, Zap } from "lucide-react";

const C = {
  primary: "#3D6B4F",
  gold: "#C8973A",
  sage: "#8FAF82",
  violet: "#7B5EA7",
  surface: "#FFFFFF",
  surfaceVariant: "#F7F3EC",
  surfaceContainer: "#f9ecdc",
  onSurface: "#211b11",
  onSurfaceVariant: "#414942",
  outlineVariant: "rgba(113,121,114,0.15)",
  outline: "rgba(113,121,114,0.3)",
};

// ── Mock data (mirrors HTML mock) ─────────────────────────────────────────────
const MOCK: Record<string, {
  kpis: { revenue: string; orders: string; aov: string; visitors: string; conversion: string; cancellations: number };
  revenue: { labels: string[]; data: number[] };
  orders:  { labels: string[]; data: number[] };
  topProducts: { labels: string[]; data: number[] };
  conversion: { labels: string[]; data: number[] };
  products: { name: string; units: number; revenue: number; stock: number; rating: number }[];
  custom: { count: number; revenue: string };
  premade: { count: number; revenue: string };
}> = {
  "7d": {
    kpis: { revenue: "₹38,900", orders: "111", aov: "₹350", visitors: "2,220", conversion: "5.0%", cancellations: 1 },
    revenue:    { labels: ["Jun 4","Jun 5","Jun 6","Jun 7","Jun 8","Jun 9","Jun 10"], data: [4200,3100,5600,7200,4800,6100,7900] },
    orders:     { labels: ["Jun 4","Jun 5","Jun 6","Jun 7","Jun 8","Jun 9","Jun 10"], data: [12,9,16,20,14,18,22] },
    topProducts:{ labels: ["Terracotta Vase","Handwoven Shawl","Brass Incense","Phulkari Dupatta","Clay Diya Set"], data: [25,18,15,12,10] },
    conversion: { labels: ["Jun 4","Jun 5","Jun 6","Jun 7","Jun 8","Jun 9","Jun 10"], data: [2.1,1.8,2.5,3.1,2.3,2.7,3.2] },
    products: [
      { name: "Terracotta Vase",    units: 25, revenue: 125000, stock: 18, rating: 4.8 },
      { name: "Handwoven Shawl",    units: 18, revenue: 90000,  stock: 12, rating: 4.6 },
      { name: "Brass Incense",      units: 15, revenue: 75000,  stock: 25, rating: 4.7 },
      { name: "Phulkari Dupatta",   units: 12, revenue: 60000,  stock: 8,  rating: 4.5 },
      { name: "Clay Diya Set",      units: 10, revenue: 50000,  stock: 30, rating: 4.9 },
    ],
    custom:  { count: 28, revenue: "₹14,800" },
    premade: { count: 83, revenue: "₹24,100" },
  },
  "30d": {
    kpis: { revenue: "₹1,43,000", orders: "442", aov: "₹323", visitors: "8,840", conversion: "5.0%", cancellations: 3 },
    revenue:    { labels: ["May 12","May 17","May 22","May 27","May 31","Jun 5","Jun 10"], data: [15000,18500,14200,22000,19800,24500,29000] },
    orders:     { labels: ["May 12","May 17","May 22","May 27","May 31","Jun 5","Jun 10"], data: [45,52,40,65,58,70,82] },
    topProducts:{ labels: ["Terracotta Vase","Handwoven Shawl","Brass Incense","Phulkari Dupatta","Clay Diya Set"], data: [110,85,70,60,45] },
    conversion: { labels: ["May 12","May 17","May 22","May 27","May 31","Jun 5","Jun 10"], data: [2.3,2.4,2.1,2.8,2.5,2.9,3.0] },
    products: [
      { name: "Terracotta Vase",    units: 110, revenue: 550000, stock: 18, rating: 4.8 },
      { name: "Handwoven Shawl",    units: 85,  revenue: 425000, stock: 12, rating: 4.6 },
      { name: "Brass Incense",      units: 70,  revenue: 350000, stock: 25, rating: 4.7 },
      { name: "Phulkari Dupatta",   units: 60,  revenue: 300000, stock: 8,  rating: 4.5 },
      { name: "Clay Diya Set",      units: 45,  revenue: 225000, stock: 30, rating: 4.9 },
    ],
    custom:  { count: 110, revenue: "₹55,000" },
    premade: { count: 332, revenue: "₹88,000" },
  },
  "90d": {
    kpis: { revenue: "₹4,95,000", orders: "1,515", aov: "₹326", visitors: "30,300", conversion: "5.0%", cancellations: 9 },
    revenue:    { labels: ["Mar 15","Mar 30","Apr 15","Apr 30","May 15","May 30","Jun 10"], data: [55000,62000,68000,75000,71000,80000,84000] },
    orders:     { labels: ["Mar 15","Mar 30","Apr 15","Apr 30","May 15","May 30","Jun 10"], data: [170,190,210,230,220,245,250] },
    topProducts:{ labels: ["Terracotta Vase","Handwoven Shawl","Brass Incense","Phulkari Dupatta","Clay Diya Set"], data: [340,280,220,190,150] },
    conversion: { labels: ["Mar 15","Mar 30","Apr 15","Apr 30","May 15","May 30","Jun 10"], data: [2.1,2.2,2.4,2.5,2.3,2.6,2.8] },
    products: [
      { name: "Terracotta Vase",    units: 340, revenue: 1700000, stock: 18, rating: 4.8 },
      { name: "Handwoven Shawl",    units: 280, revenue: 1400000, stock: 12, rating: 4.6 },
      { name: "Brass Incense",      units: 220, revenue: 1100000, stock: 25, rating: 4.7 },
      { name: "Phulkari Dupatta",   units: 190, revenue: 950000,  stock: 8,  rating: 4.5 },
      { name: "Clay Diya Set",      units: 150, revenue: 750000,  stock: 30, rating: 4.9 },
    ],
    custom:  { count: 380, revenue: "₹1,90,000" },
    premade: { count: 1135, revenue: "₹3,05,000" },
  },
};

type Period = "today" | "7d" | "30d" | "90d" | "custom";

const PERIODS: { key: Period; label: string }[] = [
  { key: "today",  label: "Today" },
  { key: "7d",     label: "This Week" },
  { key: "30d",    label: "This Month" },
  { key: "90d",    label: "Last 3 Months" },
  { key: "custom", label: "Custom" },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt = (n: number) => "₹" + (n / 100).toLocaleString("en-IN", { maximumFractionDigits: 0 });

function ChartCard({ title, bg = C.surface, children }: { title: string; bg?: string; children: React.ReactNode }) {
  return (
    <div style={{ background: bg, borderColor: C.outline }} className="border rounded-2xl p-4 shadow-sm">
      <h3 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
          className="text-base italic font-bold mb-3">{title}</h3>
      {children}
    </div>
  );
}

// Custom tooltip shared style
function TooltipBox({ active, payload, label, formatter }: {
  active?: boolean; payload?: { value: number }[]; label?: string;
  formatter: (v: number) => string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: C.surface, border: `1px solid ${C.outline}`, borderRadius: "0.75rem" }}
         className="px-3 py-2 shadow-lg">
      <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
         className="text-[9px] uppercase tracking-widest mb-1">{label}</p>
      <p style={{ color: C.primary, fontFamily: "'Space Mono', monospace" }}
         className="text-sm font-bold">{formatter(payload[0].value)}</p>
    </div>
  );
}

// ── KPI strip ─────────────────────────────────────────────────────────────────
function KpiStrip({ d }: { d: typeof MOCK["30d"] }) {
  const tiles = [
    { label: "Revenue",     value: d.kpis.revenue,       Icon: TrendingUp,   color: C.primary },
    { label: "Orders",      value: d.kpis.orders,        Icon: ShoppingBag,  color: C.primary },
    { label: "Avg Value",   value: d.kpis.aov,           Icon: Zap,          color: C.gold },
    { label: "Visitors",    value: d.kpis.visitors,      Icon: Users,        color: "#2563EB" },
    { label: "Conversion",  value: d.kpis.conversion,    Icon: Percent,      color: C.violet },
    { label: "Cancels",     value: String(d.kpis.cancellations), Icon: AlertCircle, color: "#DC2626" },
  ];
  return (
    <div className="grid grid-cols-3 gap-2 px-4 mb-4">
      {tiles.map(t => (
        <div key={t.label}
             style={{ background: C.surface, borderColor: C.outlineVariant }}
             className="border rounded-2xl p-3 shadow-sm flex flex-col gap-1">
          <div className="flex items-center gap-1">
            <t.Icon size={11} color={t.color} />
            <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
               className="text-[8px] uppercase tracking-wider opacity-70 leading-none">{t.label}</p>
          </div>
          <p style={{ color: t.color, fontFamily: "'Space Mono', monospace" }}
             className="text-base font-bold leading-none">{t.value}</p>
        </div>
      ))}
    </div>
  );
}

// ── Product card (mobile replaces table row) ──────────────────────────────────
function ProductCard({ p }: { p: { name: string; units: number; revenue: number; stock: number; rating: number } }) {
  return (
    <div style={{ background: C.surfaceVariant, borderColor: C.outlineVariant }}
         className="border rounded-xl p-3">
      <div className="flex items-start justify-between gap-2 mb-2">
        <p style={{ color: C.primary }} className="text-sm font-bold leading-snug flex-1 min-w-0">{p.name}</p>
        <span style={{ color: C.gold, fontFamily: "'Space Mono', monospace" }}
              className="text-xs font-bold flex-shrink-0">{p.rating}★</span>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {[
          { l: "Units Sold", v: String(p.units) },
          { l: "Revenue",    v: fmt(p.revenue) },
          { l: "In Stock",   v: String(p.stock) },
        ].map(x => (
          <div key={x.l}>
            <p style={{ color: C.onSurfaceVariant, fontFamily: "'Cinzel', serif" }}
               className="text-[8px] uppercase tracking-wider opacity-60">{x.l}</p>
            <p style={{ color: C.onSurface, fontFamily: "'Space Mono', monospace" }}
               className="text-xs font-bold mt-0.5">{x.v}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Insight card ──────────────────────────────────────────────────────────────
function InsightCard({ icon: Icon, text }: { icon: React.ElementType; text: React.ReactNode }) {
  return (
    <div style={{ background: C.surfaceVariant, borderLeft: `3px solid ${C.gold}` }}
         className="rounded-r-2xl p-4 shadow-sm flex items-start gap-3">
      <Icon size={18} color={C.gold} className="flex-shrink-0 mt-0.5" />
      <p style={{ color: C.onSurface }} className="text-sm leading-relaxed">{text}</p>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export function AnalyticsPage() {
  const [period, setPeriod] = useState<Period>("30d");
  const [customStart, setCustomStart] = useState("");
  const [customEnd, setCustomEnd]     = useState("");
  const [showCustom, setShowCustom]   = useState(false);

  const d = useMemo(() => {
    const key = period === "today" || period === "custom" ? "7d" : period;
    return MOCK[key];
  }, [period]);

  // Build recharts-friendly arrays
  const revenueData  = d.revenue.labels.map((l, i)  => ({ l, v: d.revenue.data[i] }));
  const ordersData   = d.orders.labels.map((l, i)   => ({ l, v: d.orders.data[i] }));
  const convData     = d.conversion.labels.map((l, i) => ({ l, v: d.conversion.data[i] }));
  const topProdData  = d.topProducts.labels.map((l, i) => ({ l, v: d.topProducts.data[i] }));

  function handlePeriod(key: Period) {
    setPeriod(key);
    setShowCustom(key === "custom");
  }

  return (
    <div style={{ background: "#FAF7F2", fontFamily: "'DM Sans', sans-serif" }} className="min-h-full flex flex-col">

      {/* Header */}
      <header style={{ background: C.surface, borderBottom: `1px solid ${C.outlineVariant}` }}
              className="sticky top-0 z-40 px-4 pt-10 pb-3">
        <div className="flex items-end justify-between mb-3">
          <div>
            <p style={{ color: C.gold, fontFamily: "'Cinzel', serif" }}
               className="text-[9px] uppercase tracking-widest font-bold">Seller Studio</p>
            <h1 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
                className="text-2xl italic font-bold mt-0.5">Studio Analytics</h1>
            <p style={{ color: C.onSurfaceVariant }} className="text-xs mt-0.5 opacity-70">
              Traffic, conversions &amp; revenue
            </p>
          </div>
          <button style={{ background: C.primary }}
                  className="flex items-center gap-1.5 text-white text-xs font-bold px-3 py-2 rounded-xl active:opacity-80">
            <Download size={13} />
            Export
          </button>
        </div>

        {/* Period chips */}
        <div className="flex gap-2 overflow-x-auto pb-0.5" style={{ scrollbarWidth: "none" as const }}>
          {PERIODS.map(p => {
            const on = p.key === period;
            return (
              <button key={p.key} onClick={() => handlePeriod(p.key)}
                      style={{
                        fontFamily: "'Cinzel', serif",
                        background: on ? C.primary : "transparent",
                        color: on ? "#fff" : C.onSurfaceVariant,
                        border: `1px solid ${on ? C.primary : C.outline}`,
                      }}
                      className="flex-shrink-0 text-[9px] uppercase tracking-widest font-bold px-3 py-1.5 rounded-full transition-all">
                {p.label}
              </button>
            );
          })}
        </div>

        {/* Custom date row */}
        {showCustom && (
          <div className="flex items-center gap-2 mt-2 flex-wrap">
            <input type="date" value={customStart} onChange={e => setCustomStart(e.target.value)}
                   style={{ border: `1px solid ${C.outline}`, borderRadius: "0.5rem" }}
                   className="text-xs px-2 py-1.5 bg-white focus:outline-none" />
            <span style={{ color: C.onSurfaceVariant }} className="text-xs">to</span>
            <input type="date" value={customEnd} onChange={e => setCustomEnd(e.target.value)}
                   style={{ border: `1px solid ${C.outline}`, borderRadius: "0.5rem" }}
                   className="text-xs px-2 py-1.5 bg-white focus:outline-none" />
            <button style={{ background: C.primary }}
                    className="text-white text-[9px] uppercase tracking-widest font-bold px-3 py-1.5 rounded-lg active:opacity-80">
              Apply
            </button>
          </div>
        )}
      </header>

      {/* Body */}
      <main className="flex-1 overflow-y-auto pb-6 pt-4 space-y-4">

        {/* KPIs */}
        <KpiStrip d={d} />

        {/* Revenue chart */}
        <div className="px-4">
          <ChartCard title="Revenue Over Time" bg={C.surfaceVariant}>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={revenueData} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor={C.primary} stopOpacity={0.15} />
                    <stop offset="95%" stopColor={C.primary} stopOpacity={0.01} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(113,121,114,0.08)" vertical={false} />
                <XAxis dataKey="l" tick={{ fontSize: 9, fontFamily: "Space Mono", fill: C.onSurfaceVariant }}
                       axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 9, fontFamily: "Space Mono", fill: C.onSurfaceVariant }}
                       axisLine={false} tickLine={false}
                       tickFormatter={v => "₹" + (v >= 1000 ? Math.round(v / 1000) + "k" : v)} />
                <Tooltip content={<TooltipBox formatter={v => "₹" + v.toLocaleString("en-IN")} />} />
                <Area type="monotone" dataKey="v" stroke={C.primary} strokeWidth={2}
                      fill="url(#revGrad)" dot={{ r: 3, fill: C.primary, strokeWidth: 0 }} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Orders chart */}
        <div className="px-4">
          <ChartCard title="Orders Per Day">
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={ordersData} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(113,121,114,0.08)" vertical={false} />
                <XAxis dataKey="l" tick={{ fontSize: 9, fontFamily: "Space Mono", fill: C.onSurfaceVariant }}
                       axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 9, fontFamily: "Space Mono", fill: C.onSurfaceVariant }}
                       axisLine={false} tickLine={false} />
                <Tooltip content={<TooltipBox formatter={v => v + " orders"} />} />
                <Bar dataKey="v" fill="#49663f" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Top Products horizontal bar */}
        <div className="px-4">
          <ChartCard title="Top Products" bg={C.surfaceVariant}>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={topProdData} layout="vertical"
                        margin={{ top: 4, right: 4, left: 4, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(113,121,114,0.08)" horizontal={false} />
                <XAxis type="number"
                       tick={{ fontSize: 9, fontFamily: "Space Mono", fill: C.onSurfaceVariant }}
                       axisLine={false} tickLine={false} />
                <YAxis dataKey="l" type="category" width={90}
                       tick={{ fontSize: 9, fontFamily: "DM Sans", fill: C.onSurfaceVariant }}
                       axisLine={false} tickLine={false} />
                <Tooltip content={<TooltipBox formatter={v => v + " units"} />} />
                <Bar dataKey="v" radius={[0, 4, 4, 0]}
                     fill={C.gold}
                     // alternate gold/sage per bar via cell isn't trivial in recharts without Cell — use gold for all
                />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Conversion rate chart */}
        <div className="px-4">
          <ChartCard title="Conversion Rate">
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart data={convData} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id="convGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor={C.violet} stopOpacity={0.15} />
                    <stop offset="95%" stopColor={C.violet} stopOpacity={0.01} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(113,121,114,0.08)" vertical={false} />
                <XAxis dataKey="l" tick={{ fontSize: 9, fontFamily: "Space Mono", fill: C.onSurfaceVariant }}
                       axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 9, fontFamily: "Space Mono", fill: C.onSurfaceVariant }}
                       axisLine={false} tickLine={false}
                       tickFormatter={v => v + "%"} />
                <Tooltip content={<TooltipBox formatter={v => v + "%"} />} />
                <Area type="monotone" dataKey="v" stroke={C.violet} strokeWidth={2}
                      fill="url(#convGrad)" dot={{ r: 3, fill: C.violet, strokeWidth: 0 }} />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Product Performance */}
        <div className="px-4 space-y-3">
          <h3 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
              className="text-base italic font-bold">Product Performance</h3>
          {d.products.map(p => <ProductCard key={p.name} p={p} />)}
        </div>

        {/* Custom vs Pre-made */}
        <div className="px-4">
          <h3 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
              className="text-base italic font-bold mb-3">Custom vs Pre-made Orders</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { tag: "Custom",   tagBg: C.violet, count: d.custom.count,  rev: d.custom.revenue },
              { tag: "Pre-made", tagBg: "#49663f", count: d.premade.count, rev: d.premade.revenue },
            ].map(x => (
              <div key={x.tag}
                   style={{ background: C.surfaceContainer, borderColor: C.outlineVariant }}
                   className="border rounded-2xl p-4 flex flex-col gap-3">
                <span style={{ background: x.tagBg }}
                      className="self-start text-white text-[8px] uppercase tracking-widest font-bold px-2 py-0.5 rounded-full">
                  {x.tag}
                </span>
                <div>
                  <p style={{ color: C.onSurfaceVariant }} className="text-[9px] uppercase tracking-wider">Orders</p>
                  <p style={{ color: C.onSurface, fontFamily: "'Space Mono', monospace" }}
                     className="text-lg font-bold">{x.count}</p>
                </div>
                <div>
                  <p style={{ color: C.onSurfaceVariant }} className="text-[9px] uppercase tracking-wider">Revenue</p>
                  <p style={{ color: C.primary, fontFamily: "'Space Mono', monospace" }}
                     className="text-lg font-bold">{x.rev}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Insights */}
        <div className="px-4 space-y-3">
          <h3 style={{ color: C.primary, fontFamily: "'Playfair Display', serif" }}
              className="text-base italic font-bold">Studio Insights</h3>
          <InsightCard icon={Clock}
            text={<>Your avg production time is <strong>2.3 days</strong> vs stated 2 days.</>} />
          <InsightCard icon={Star}
            text={<><strong>Custom kits</strong> have your highest satisfaction rating (4.9★). Keep up the great work!</>} />
          <InsightCard icon={TrendingUp}
            text={<>This season: <strong>2.4× revenue increase</strong> in Home Decor items.</>} />
        </div>

        {/* Footer */}
        <div style={{ borderTop: `1px solid ${C.outlineVariant}` }} className="mx-4 pt-4 text-center pb-2">
          <p style={{ color: C.onSurfaceVariant, fontFamily: "'Playfair Display', serif" }}
             className="text-sm italic">Handcrafted insights for your studio.</p>
          <div className="flex justify-center gap-2 mt-2">
            {["✦", "✦", "✦"].map((s, i) => (
              <span key={i} style={{ color: C.gold }}>{s}</span>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
